import json,collections as C,math,sys
k=json.load(open(sys.argv[1]))['keys']
b=json.loads(k['eud_btsig'])
def st(L):
  n=len(L)
  if n<2: return (n, sum(L)/n if n else 0, 0)
  m=sum(L)/n; sd=math.sqrt(sum((x-m)**2 for x in L)/(n-1)); return (n,m,1.96*sd/math.sqrt(n))
NM={'short':'Богино','mid':'Дунд','long':'Урт','pat':'Загвар','scen':'Ant','scenN':'AntN','bo':'BO','boN':'BON','aad':'Cont','aadN':'ContN','scan':'Скан'}
rows=C.defaultdict(list)
for kk,v in b.items():
  sym,iv=kk.split('|')
  v=sorted([x for x in v if x['sh']==0 and x['R'] is not None],key=lambda x:x['t'])
  cut=v[int(len(v)*0.6)]['t'] if v else 0
  for x in v: rows[(x['p'],iv)].append((x['R'],x['t']>=cut,sym,x))
print('method   iv     n    meanR  ±95%   | first60%  last40%  | per-symbol')
for p in NM:
  for iv in ['15min','1h','4h']:
    L=rows.get((p,iv),[])
    if not L: continue
    n,m,e=st([r for r,_,_,_ in L]); a=st([r for r,o,_,_ in L if not o]); bb=st([r for r,o,_,_ in L if o])
    ps=C.defaultdict(list)
    for r,_,s,_ in L: ps[s[:3]].append(r)
    sig='✓+' if m-e>0 else ('✗-' if m+e<0 else '')
    print(f'{NM[p]:6} {iv:5} {n:4} {m:+.2f} ±{e:.2f} {sig:3}| {a[1]:+.2f}({a[0]}) {bb[1]:+.2f}({bb[0]}) | '+' '.join(f'{s}{sum(v)/len(v):+.2f}' for s,v in sorted(ps.items())))
print()
for thr in [0.0,0.1,0.2]:
  sel=[];tot=[]
  for key,L in rows.items():
    a=[r for r,o,_,_ in L if not o]; bb=[r for r,o,_,_ in L if o]
    if len(a)>=20 and sum(a)/len(a)>thr: sel.append(key); tot+=bb
  allb=[r for L in rows.values() for r,o,_,_ in L if o]
  n,m,e=st(tot); n2,m2,e2=st(allb)
  print(f'thr {thr}: chosen {sorted(sel)}\n   last40% of chosen: n{n} {m:+.3f}±{e:.3f}  | all methods last40%: n{n2} {m2:+.3f}')
print()
for iv in ['15min','1h','4h']:
  for nm,f in [('trend-aligned',lambda x:x['x'] and x['x'][1]==x['d']),('counter',lambda x:x['x'] and x['x'][1]==-x['d']),('flat',lambda x:x['x'] and x['x'][1]==0),
               ('vol lo',lambda x:x['x'] and x['x'][2]=='lo'),('vol mid',lambda x:x['x'] and x['x'][2]=='mid'),('vol hi',lambda x:x['x'] and x['x'][2]=='hi')]+[('se '+s,(lambda s: lambda x:x['x'] and x['x'][0]==s)(s)) for s in 'alyo']:
    for half in [False,True]:
      pass
    A=[x['R'] for key,L in rows.items() if key[1]==iv for r,o,_,x in L if not o and f(x)]
    B=[x['R'] for key,L in rows.items() if key[1]==iv for r,o,_,x in L if o and f(x)]
    if len(A)<15: continue
    a=st(A);bb=st(B); print(f'{iv:5} {nm:14} first {a[1]:+.2f}({a[0]}) last {bb[1]:+.2f}±{bb[2]:.2f}({bb[0]})')
