import json,math,collections as C,datetime as D,sys
A='/mnt/user-data/attachments/6952a704-ad3d-5be2-a859-39e5f9b1700e/'
F=['8226a13e-station-2026-10-20_4.json','a8854923-station-2026-10-21.json','eb3dfb93-station-2026-10-22.json']
def st(L):
  n=len(L)
  if not n: return '—'
  m=sum(L)/n; e=1.96*math.sqrt(sum((x-m)**2 for x in L)/(n-1))/math.sqrt(n) if n>1 else 0
  return f'n{n} {m:+.2f}R ±{e:.2f} wr{sum(1 for x in L if x>0)/n:.0%}'
for f in F:
  k=json.load(open(A+f))['keys']; J=json.loads(k['eud_journal_v1'])
  cl=[j for j in J if j['res'] in('win','loss') and not j.get('shadow')]
  print(f[9:], 'total',len(J),'closed',st([j['R'] for j in cl]), C.Counter(j['res'] for j in J))
k=json.load(open(A+F[2]))['keys']; J=json.loads(k['eud_journal_v1'])
day=lambda j:D.datetime.utcfromtimestamp(j['rec']/1000).strftime('%m-%d')
cl=[j for j in J if j['res'] in('win','loss')]
print('shadow split', C.Counter(j.get('shadow') for j in cl))
cl=[j for j in cl if not j.get('shadow')]
print('by day'); bd=C.defaultdict(list)
for j in cl: bd[day(j)].append(j['R'])
for d_ in sorted(bd): print(' ',d_,st(bd[d_]))
for lab,cut in [('since 10-18',D.datetime(2026,10,18).timestamp()*1000),('since 10-20',D.datetime(2026,10,20).timestamp()*1000)]:
  L=[j for j in cl if j['rec']>=cut]; print(lab,st([j['R'] for j in L]))
  for key in ['plan','sym','iv']:
    g=C.defaultdict(list)
    for j in L: g[j[key]].append(j['R'])
    print('   ',key,' | '.join(f'{a}: {st(b)}' for a,b in sorted(g.items(),key=lambda x:-len(x[1]))))
g=C.defaultdict(list)
for j in cl: g[j['plan']].append(j['R'])
print('ALL by plan'); [print('  ',a,st(b)) for a,b in sorted(g.items(),key=lambda x:-len(x[1]))]
print('open now:',[(j['sym'],j['plan'],j['dir'],j['t0']) for j in J if j['res']=='open'])
