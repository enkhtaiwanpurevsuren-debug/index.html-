'use strict';
// =====================================================================
//  Market Pattern — NOTEBOOK СЕРВЕР (mp-server)
//
//  Notebook дээр 24/7 ажиллана:
//   1. Станц  — dashboard-ыг (app/index.html) нүдэнд үл харагдах Chromium-д
//               яг утсан дээрхтэй адил ажиллуулж, бодит туршилтыг (скан,
//               журнал, таамгийн хэмжилт) зогсолтгүй явуулна.
//   2. Telegram — станцын мэдэгдэл, өдрийн тайлан, үнийн сэрүүлэг; ботод
//               /status /shot /report командаар асууж болно.
//   3. Өгөгдөл — Twelve Data-аас ирсэн лаа бүрийг data/candles-д хуримтлуулна.
//   4. Нөөц    — станцын бүх өгөгдлийг 30 мин тутам data/backups-д хадгална.
//   5. Утаснаас — Tailscale-ээр https://<нэр>.ts.net хаягаар апп, /status
//               хуудас, станцын өгөгдлийг татах.
//
//  Нууц мэдээлэл (API түлхүүр, Telegram token, нууц үг) зөвхөн .env файлд.
// =====================================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const DIRS = {big: path.join(DATA, 'big'), profile: path.join(DATA, 'profile'), candles: path.join(DATA, 'candles'), backups: path.join(DATA, 'backups'), logs: path.join(DATA, 'logs'), history: path.join(DATA, 'history')};
const APP_FILE = path.join(ROOT, 'app', 'index.html');
const ENV_FILE = path.join(ROOT, '.env');
const STATE_FILE = path.join(DATA, 'state.json');
const VERSION = 'mp-server 1.8.2';
const RESTART_HINT = process.platform === 'win32' ? '.env засаад restart.bat' : 'sudo mpctl edit';

// ---------------------------------------------------------------- .env
function parseEnv(txt){
  const out = {};
  String(txt).replace(/^﻿/, '').split(/\r?\n/).forEach(line => {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line); if(!m || /^\s*#/.test(line)) return;
    let v = m[2]; if(/^".*"$/.test(v) || /^'.*'$/.test(v)) v = v.slice(1, -1);
    out[m[1]] = v;
  });
  return out;
}
function initEnv(){
  const ex = path.join(ROOT, 'config.example.env');
  if(fs.existsSync(ENV_FILE)){ console.log('.env аль хэдийн байна — өөрчлөөгүй.'); return; }
  const tok = crypto.randomBytes(18).toString('base64url');
  let txt = fs.readFileSync(ex, 'utf8').replace(/^STATION_TOKEN=.*$/m, 'STATION_TOKEN=' + tok);
  if(process.platform !== 'win32') txt = txt.replace(/\r\n/g, '\n');
  fs.writeFileSync(ENV_FILE, txt, {mode: 0o600});
  console.log('.env үүслээ. STATION_TOKEN автоматаар үүсгэгдсэн: ' + tok);
  console.log(process.platform === 'win32' ? 'Одоо .env-ийг Notepad-аар нээж TD_API_KEY, TG_TOKEN-оо бичнэ үү.' : 'Одоо sudo mpctl edit гэж .env-д TD_API_KEY, TG_TOKEN-оо бичнэ үү.');
}
if(process.argv.includes('--init-env')){ initEnv(); process.exit(0); }

const ENV = Object.assign({}, fs.existsSync(ENV_FILE) ? parseEnv(fs.readFileSync(ENV_FILE, 'utf8')) : {}, process.env.MP_TEST ? process.env : {});
const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
const CFG = {
  port: num(ENV.PORT, 8787), host: ENV.HOST || '127.0.0.1',
  tdKey: (ENV.TD_API_KEY || '').trim(), token: (ENV.STATION_TOKEN || '').trim(),
  tgToken: (ENV.TG_TOKEN || '').trim(), tgChat: (ENV.TG_CHAT || '').trim(),
  sym: ENV.CHART_SYMBOL || 'XAU/USD', iv: ENV.CHART_INTERVAL || '15min',
  refreshSec: String(num(ENV.CHART_REFRESH_SEC, 900)),
  autoStation: ENV.AUTO_START_STATION !== '0',
  creditCap: num(ENV.CREDIT_CAP, 600), alarmEvery: Math.max(2, num(ENV.ALARM_EVERY_MIN, 5)),
  history: ENV.HISTORY !== '0', histYears: Math.max(1, Math.min(15, num(ENV.HISTORY_YEARS, 5))),
  histSymbols: String(ENV.HISTORY_SYMBOLS || 'XAU/USD,EUR/USD,GBP/USD,USD/JPY,BTC/USD').split(',').map(x => x.trim()).filter(Boolean),
  // v1.8 trend system: daily bars of many markets (diversification is what makes trend-following work)
  trendSymbols: String(ENV.TREND_SYMBOLS || 'EUR/USD,GBP/USD,USD/JPY,AUD/USD,USD/CAD,USD/CHF,NZD/USD,EUR/JPY,GBP/JPY,EUR/GBP,AUD/JPY,XAU/USD,XAG/USD,BTC/USD').split(',').map(x => x.trim()).filter(Boolean),
  trendYears: Math.max(3, Math.min(15, num(ENV.TREND_YEARS, 10))), trendAcct: num(ENV.TREND_ACCOUNT, 10000), trendOn: ENV.TREND !== '0',
  histTestIvs: String(ENV.HISTORY_TEST_INTERVALS || '15min,1h,4h').split(',').map(x => x.trim()).filter(Boolean),
  dukaBase: (ENV.DUKA_BASE || 'https://datafeed.dukascopy.com/datafeed').replace(/\/+$/, ''),
  reportHour: num(ENV.REPORT_HOUR, 21), backupKeep: num(ENV.BACKUP_KEEP_DAYS, 30),
  backupCopy: (ENV.BACKUP_COPY_DIR || '').trim(), backupTg: ENV.BACKUP_TELEGRAM !== '0',
  tdBase: (ENV.TD_BASE || 'https://api.twelvedata.com').replace(/\/+$/, ''),
  tgBase: (ENV.TG_BASE || 'https://api.telegram.org').replace(/\/+$/, ''),
};
const DAY = 864e5;
// rewrite chosen keys of .env in place (other lines and comments stay)
function envSet(vals){
  let txt = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8') : '';
  const nl = /\r\n/.test(txt) ? '\r\n' : '\n';
  Object.entries(vals).forEach(([k, v]) => {
    v = String(v).replace(/[\r\n]/g, '').trim();
    const re = new RegExp('^' + k + '=.*$', 'm');
    txt = re.test(txt) ? txt.replace(re, k + '=' + v) : txt.replace(/\s*$/, '') + nl + k + '=' + v + nl;
  });
  fs.writeFileSync(ENV_FILE, txt, {mode: 0o600});
}
const PAIR_CODE = String(crypto.randomInt(100000, 1000000));

// ---------------------------------------------------------------- logging
Object.values(DIRS).forEach(d => fs.mkdirSync(d, {recursive: true}));
const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function log(...a){
  const line = `[${new Date().toLocaleString('sv-SE')}] ` + a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ');
  console.log(line);
  try{ fs.appendFileSync(path.join(DIRS.logs, `server-${ymd()}.log`), line + '\n'); }catch(e){}
}
function pruneDir(dir, re, keepDays){
  try{ fs.readdirSync(dir).forEach(f => { if(!re.test(f)) return; const p = path.join(dir, f); if(Date.now() - fs.statSync(p).mtimeMs > keepDays*DAY) fs.unlinkSync(p); }); }catch(e){}
}
function writeAtomic(file, data){ const tmp = file + '.tmp'; fs.writeFileSync(tmp, data); fs.renameSync(tmp, file); }
// v1.7 «big store»: the research stores (history-test signals, forecast audit, pattern lifecycle,
// test summaries) outgrew the browser's 5 MB localStorage — writes failed silently and new test
// results were lost. On the station they live in data/big/*.json instead (no size limit).
const BIG_KEYS = ['eud_fq_v1', 'eud_btsig', 'eud_lc_hist', 'eud_bt'];
const bigFile = k => path.join(DIRS.big, k + '.json');
function bigSave(key, val){
  if(!BIG_KEYS.includes(key) || typeof val !== 'string' || val.length > 200*1024*1024) return false;
  try{ JSON.parse(val); writeAtomic(bigFile(key), val); return true; }catch(e){ log('Том өгөгдөл хадгалж чадсангүй:', key, e.message); return false; }
}
function bigAll(){ const o = {}; BIG_KEYS.forEach(k => { try{ o[k] = fs.readFileSync(bigFile(k), 'utf8'); }catch(e){} }); return o; }

if(process.argv.includes('--check')){ check().then(ok => process.exit(ok ? 0 : 1)); }
else{
  const miss = [];
  if(!CFG.tdKey) miss.push('TD_API_KEY'); if(CFG.token.length < 16) miss.push('STATION_TOKEN (16+ тэмдэгт)');
  if(miss.length){ log('❌ .env дутуу байна: ' + miss.join(', ') + '. install.bat-ийг ажиллуулж .env-ээ бөглөнө үү.'); process.exit(2); }
  if(!fs.existsSync(APP_FILE)){ log('❌ app/index.html олдсонгүй.'); process.exit(2); }
  main().catch(e => { log('❌ Эхлэхэд алдаа:', String(e && e.stack || e)); process.exit(1); });
}

// ---------------------------------------------------------------- persistent state
const ST = (() => { try{ return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }catch(e){ return {}; } })();
const ST_FRESH = !Object.keys(ST).length;
ST.credits = ST.credits || {day: '', used: 0}; ST.alarms = ST.alarms || []; ST.fired = ST.fired || [];
ST.tgOffset = ST.tgOffset || 0; ST.lastReport = ST.lastReport || ''; ST.lastJr = ST.lastJr || null;
let stTimer = null;
function stSave(){ clearTimeout(stTimer); stTimer = setTimeout(() => { try{ writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){ log('state.json хадгалж чадсангүй', e.message); } }, 500); }

// Twelve Data resets the daily credits at 00:00 UTC
function credits(){ const d = new Date().toISOString().slice(0, 10); if(ST.credits.day !== d){ ST.credits = {day: d, used: 0, capped: false}; stSave(); } return ST.credits; }
function creditUse(n){ const C = credits(); C.used += n; if(!C.capped && C.used >= CFG.creditCap){ C.capped = true; tgSend(`⛔ Серверийн өнөөдрийн API хязгаар (${CFG.creditCap}) хүрлээ — 08:00 цагт (UTC 00:00) шинэчлэгдэнэ. Станц тэр болтол хүлээнэ.`); log('API cap reached', C.used); } stSave(); }

// ---------------------------------------------------------------- Telegram
const tgQueue = []; let tgBusy = false; const tgSeen = new Map();
function tgSend(text, opt = {}){
  if(!CFG.tgToken || !CFG.tgChat) return;
  if(opt.dedupe){ const last = tgSeen.get(opt.dedupe); if(last && Date.now() - last < (opt.every || 10*60e3)) return; tgSeen.set(opt.dedupe, Date.now()); }
  if(!opt.photo && !opt.doc && String(text).length > 4000){ const t = String(text); let cut = t.lastIndexOf('\n', 3900); if(cut < 2000) cut = 3900; const o2 = Object.assign({}, opt, {dedupe: null}); tgSend(t.slice(0, cut), opt); tgSend(t.slice(cut + 1), o2); return; }
  tgQueue.push({text: String(text).slice(0, 4000), photo: opt.photo || null, doc: opt.doc || null, docName: opt.docName || 'file.json'}); tgPump();
}
async function tgPump(){
  if(tgBusy) return; tgBusy = true;
  while(tgQueue.length){
    const m = tgQueue.shift();
    try{
      if(m.doc){
        const fd = new FormData(); fd.append('chat_id', CFG.tgChat); fd.append('caption', m.text.slice(0, 1000)); fd.append('document', new Blob([m.doc], {type: 'application/json'}), m.docName);
        const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendDocument`, {method: 'POST', body: fd}); if(!r.ok) log('Telegram файл илгээж чадсангүй:', r.status);
      }else if(m.photo){
        const fd = new FormData(); fd.append('chat_id', CFG.tgChat); fd.append('caption', m.text.slice(0, 1000)); fd.append('photo', new Blob([m.photo], {type: 'image/png'}), 'chart.png');
        await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendPhoto`, {method: 'POST', body: fd});
      }else{
        await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendMessage`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({chat_id: CFG.tgChat, text: m.text, disable_web_page_preview: true})});
      }
    }catch(e){ log('Telegram илгээж чадсангүй:', e.message); }
    await sleep(1100);   // Telegram: ≤ 1 msg/sec to a chat
  }
  tgBusy = false;
}
// bot commands — long polling; only the owner's chat is answered
async function tgPoll(){
  if(!CFG.tgToken) return;
  for(;;){
    try{
      const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/getUpdates?timeout=50&offset=${ST.tgOffset}`, {signal: AbortSignal.timeout(65000)});
      const j = await r.json();
      if(j && j.ok) for(const u of j.result){
        ST.tgOffset = u.update_id + 1; stSave();
        const msg = u.message || u.edited_message; if(!msg || !msg.text) continue;
        const chat = String(msg.chat.id), cmd = msg.text.trim().split(/\s+/)[0].replace(/@.*$/, '').toLowerCase();
        if(!CFG.tgChat){
          // pairing: the 6-digit code shown on the /status page (only the owner sees it) binds this chat
          const say = text => fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendMessage`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({chat_id: chat, text})});
          const code = (/(\d{6})/.exec(msg.text) || [])[1];
          if(code === PAIR_CODE){
            CFG.tgChat = chat; try{ envSet({TG_CHAT: chat}); }catch(e){ log('.env бичиж чадсангүй:', e.message); }
            log('Telegram холбогдлоо, chat:', chat);
            await say('✅ Холбогдлоо! Одооноос станцын мэдэгдэл, өдрийн тайлан, нөөц энд ирнэ. /status гэж бичээд туршаарай.');
          }else{
            await say(`Энэ ботыг холбохын тулд серверийн /status хуудсанд харагдах 6 оронтой кодыг энд бичнэ үү.\n(Эсвэл .env-д TG_CHAT=${chat} гэж бичээд серверийг дахин эхлүүлнэ: ${RESTART_HINT})`);
            log('Telegram: холбох код хүлээж байна, chat:', chat);
          }
          continue;
        }
        if(chat !== CFG.tgChat){ log('Танихгүй chat-аас мессеж ирсэн — хариулаагүй:', chat); continue; }
        await tgCommand(cmd, msg.text);
      }
      else await sleep(5000);
    }catch(e){ await sleep(10000); }
  }
}
async function tgCommand(cmd, text){
  const arg = String(text || '').trim().split(/\s+/).slice(1).join(' ').trim();
  if(cmd === '/status' || cmd === '/start'){ tgSend(await reportText(false)); }
  else if(cmd === '/report'){ tgSend(await reportText(true)); }
  else if(cmd === '/chart'){ await chartCmd(arg); }
  else if(cmd === '/trend'){ const a = parseFloat(String(arg).replace(/[$,\s]/g, ''));
    if(isFinite(a) && a >= 100){ ST.trendAcct = Math.round(a); stSave(); tgSend(`✓ Тренд системийн дансны хэмжээ $${ST.trendAcct} болгож тохирууллаа.`); }
    const R = trendGet(); tgSend(R ? TR.text(R, trendAcct(), (ST.trendLast || {}).now) + trendLiveText() : 'Тренд систем хараахан тооцогдоогүй — урт түүх татагдаж дуусах хүртэл хүлээнэ үү (/history).'); }
  else if(cmd === '/shot'){ const png = await shot(); if(png) tgSend('📷 Станцын одоогийн дэлгэц', {photo: png}); else tgSend('Станц одоогоор ачаалагдаагүй байна.'); }
  else if(cmd === '/restart'){ tgSend('🔄 Станцыг дахин ачаалж байна…'); await station.restart('Telegram /restart'); }
  else if(cmd === '/backup'){ const ok = await backupNow(true); if(ok) backupToTelegram('💾 Станцын нөөц (одоогийн)'); else tgSend('Нөөц хадгалж чадсангүй.'); }
  else if(cmd === '/history'){ tgSend(histText()); }
  else if(cmd === '/histtest'){ if(histTestBusy) tgSend('Түүхэн тест аль хэдийн явж байна.'); else histTest('Telegram', histPick(arg)); }
  else if(cmd === '/lifecycle' || cmd === '/lc'){ const t = await station.eval(() => window.__MP.lcText && window.__MP.lcText()); tgSend(t || 'Станц хариу өгөхгүй байна (эсвэл апп v77-оос хуучин).'); }
  else if(cmd === '/diag'){ const t = await station.eval(() => window.__MP.diagText && window.__MP.diagText()); tgSend(t || 'Станц одоогоор хариу өгөхгүй байна (эсвэл апп v74-өөс хуучин).'); }
  else tgSend('Командууд:\n/status — товч байдал\n/report — дэлгэрэнгүй тайлан\n/shot — станцын дэлгэцийн зураг\n/backup — одоо нөөцлөөд файлыг энд илгээх\n/restart — станцыг дахин ачаалах\n/history — урт түүхийн хамрах хүрээ\n/histtest — шалгагдсан бүх хослолыг урт түүхээр тестлэх (/histtest XAU — нэгийг)\n/diag — нөхцөлийн онош (аль нөхцөлд ажилладаг)\n/lifecycle — паттерны амьдралын мөчлөг (таамаглалууд H1–H6)\n/chart — графикийн зураг (/chart XAU 1h — өөр хослол, цаг)\n/trend — тренд системийн одоогийн байршил (/trend 5000 — дансны хэмжээ тохируулах)');
}

// ---------------------------------------------------------------- candle store
const CS = new Map();   // key → {meta, rows: Map(datetime → [o,h,l,c,v]), dirty}
const csKey = (sym, iv) => `${String(sym).replace(/[^A-Za-z0-9]+/g, '_')}__${iv}`;
const csFile = k => path.join(DIRS.candles, k + '.json');
// v1.3: every stored time is UTC. Twelve Data answers forex/metals in
// Australia/Sydney time unless asked for timezone=UTC (crypto is UTC), so the
// station's requests always ask for UTC and candles stored by 1.2 or older are
// shifted once when their file is first read.
const TZ_RE = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?$/;
function tzOldOf(sym){ const s = String(sym || '').toUpperCase().split(':')[0];
  if(/^(BTC|ETH|LTC|XRP|SOL|ADA|DOGE|BNB|DOT|LINK|AVAX|TRX|XLM|BCH)\b/.test(s)) return null;
  return /^[A-Z]{3}\/[A-Z]{3}$/.test(s) ? 'Australia/Sydney' : null; }
const tzFmt = {};
function tzOffMin(tz, ms){ const F = tzFmt[tz] || (tzFmt[tz] = new Intl.DateTimeFormat('en-US', {timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'}));
  const p = {}; F.formatToParts(new Date(ms)).forEach(x => { p[x.type] = x.value; }); return (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second) - ms)/60000; }
function tzToUtc(str, tz){ const m = TZ_RE.exec(str); if(!m || !tz) return str;
  const wall = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)); let ms = wall - tzOffMin(tz, wall)*60000; ms = wall - tzOffMin(tz, ms)*60000;
  const d = new Date(ms), z = v => String(v).padStart(2, '0');
  return `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())} ${z(d.getUTCHours())}:${z(d.getUTCMinutes())}${m[6] !== undefined ? ':' + z(d.getUTCSeconds()) : ''}`; }
function csGet(k){
  if(CS.has(k)) return CS.get(k);
  let e = {meta: null, rows: new Map(), dirty: false};
  try{ const j = JSON.parse(fs.readFileSync(csFile(k), 'utf8')); e.meta = j.meta; (j.bars || []).forEach(b => e.rows.set(b[0], b.slice(1)));
    const tz = e.meta && !e.meta.utc ? tzOldOf(e.meta.symbol) : null;
    if(e.meta && !e.meta.utc){ if(tz){ const R = new Map(); for(const [d, r] of e.rows) R.set(tzToUtc(d, tz), r); e.rows = R; log('Лааны санг UTC руу шилжүүллээ:', k, e.rows.size, 'лаа'); } e.meta.utc = true; e.dirty = true; }
  }catch(x){}
  CS.set(k, e); return e;
}
function csPut(txt, url){
  let j; try{ j = JSON.parse(txt); }catch(e){ return; }
  if(!j || j.status === 'error' || !j.meta || !Array.isArray(j.values) || !j.values.length) return;
  if(!/[?&]timezone=UTC\b/i.test(url || '') && tzOldOf(j.meta.symbol)) return;   // not UTC — never mixed into the store
  const k = csKey(j.meta.symbol, j.meta.interval);
  const e = csGet(k); e.meta = {symbol: j.meta.symbol, interval: j.meta.interval, tz: j.meta.exchange_timezone || null, type: j.meta.type || null, utc: true};
  j.values.forEach(v => { if(v && v.datetime) e.rows.set(v.datetime, [+v.open, +v.high, +v.low, +v.close, +(v.volume || 0)]); });
  e.dirty = true;
}
function csFlush(){
  for(const [k, e] of CS){ if(!e.dirty) continue;
    const bars = [...e.rows.entries()].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0).slice(-250000).map(([d, r]) => [d, ...r]);
    try{ writeAtomic(csFile(k), JSON.stringify({meta: e.meta, n: bars.length, bars})); e.dirty = false; }catch(x){ log('Лаа хадгалж чадсангүй', k, x.message); }
  }
}
// Twelve Data closes of one symbol/interval from the candle store, as [{t: epoch s (datetime read as UTC), c}]
function tdStoreRows(sym, iv){
  const e = csGet(csKey(sym, iv)); if(!e || !e.rows.size) return [];
  return [...e.rows.entries()].map(([d, r]) => ({t: Math.round(Date.parse(d.replace(' ', 'T') + 'Z')/1000), c: r[3]})).filter(x => isFinite(x.t) && x.c > 0).slice(-3000);
}
let HIST = null;
function hist(){
  if(!HIST && CFG.history){ const {makeHist} = require('./hist'); HIST = makeHist({dir: DIRS.history, base: CFG.dukaBase, years: CFG.trendOn ? Math.max(CFG.histYears, CFG.trendYears) : CFG.histYears, symbols: CFG.trendOn ? [...new Set(CFG.histSymbols.concat(CFG.trendSymbols))] : CFG.histSymbols, log, tdStore: tdStoreRows, onEvent: t => tgSend(t), pauseMs: num(ENV.HIST_PAUSE_MS, 250)}); }
  return HIST;
}
function histText(){
  const Hh = hist(); if(!Hh) return 'Урт түүх унтраалттай (.env: HISTORY=0).';
  const L = ['📚 Урт түүх (Dukascopy)' + (Hh.busy && Hh.prog ? ` · татаж байна: ${Hh.prog.sym} ${Hh.prog.i}/${Hh.prog.n} өдөр` : '')];
  Hh.coverage().forEach(c => L.push(` • ${c.symbol}: ${c.days ? `${c.from} → ${c.to} (${c.days} өдөр)` : 'хараахан алга'} · ${c.verified ? '✓ шалгагдсан' : '… ' + (c.note || 'шалгагдаагүй')}${c.failing ? ` · ${c.failing} өдөр амжилтгүй${c.gaveUp ? ` (${c.gaveUp} нь 7 хоног хүлээж байна)` : ''}${c.lastErr ? `: ${c.lastErr}` : ''}` : ''}`));
  return L.join('\n');
}
// history test + forecast audit on the station, for every interval in HISTORY_TEST_INTERVALS
let histTestBusy = false;
// symbols for a history test: «/histtest» = every symbol whose long history is verified; «/histtest XAU» = matching ones
// ---------------------------------------------------------------- trend system (v1.8)
// the trend module lives inside server.js: an updater of 1.7 or older copies only its known files
const TR = (() => {
// =====================================================================
//  TREND SYSTEM — time-series momentum, the trading rule with the longest
//  published record (Moskowitz, Ooi & Pedersen 2012; Hurst, Ooi & Pedersen
//  "A Century of Evidence on Trend-Following Investing").
//
//  Rules (fixed in advance, nothing fitted to the data):
//   • signal of an instrument = average of the signs of its 1-, 3- and
//     12-month returns  → −1, −⅓, +⅓ or +1;
//   • size = signal × (risk budget ÷ the instrument's own volatility), so a
//     calm and a wild market carry the same risk (volatility targeting);
//     volatility = exponentially weighted daily returns (≈ 60-day centre);
//   • rebalanced once a week on the week's last close, a position is only
//     changed when its size moves by more than 20 % (fewer trading costs);
//   • every instrument gets the same risk budget; the whole portfolio is
//     scaled to 10 % annual volatility (a long-only portfolio is scaled the
//     same way as the benchmark);
//   • costs: spread on every change of size + a 1 %/yr financing mark-up
//     on the notional held (the interest-rate differential itself — "carry"
//     — is not modelled: it can add or subtract).
//  Daily bars come from the station's long history (Dukascopy, UTC days).
// =====================================================================
const LB = [21, 63, 252];                 // 1, 3, 12 months of trading days
const LAM = 60/61;                        // EWMA weight (centre of mass ≈ 60 days)
const TAU = 0.40;                         // per-instrument risk budget before the portfolio scale (AQR convention)
const TARGET = 0.10;                      // portfolio annual volatility
const BAND = 0.20;                        // trade only if size changes > 20 %
const FIN = 0.01;                         // financing (swap) mark-up per year on the notional held
const MAXLEV = 4;                         // cap on one instrument's notional ÷ account
// typical retail spread (price units) — the same scale the app uses, a little wider for crosses
const SPREAD = {XAU: 0.35, XAG: 0.035, BTC: 20, JPYX: 0.025, JPY: 0.015, X: 0.00015, CROSS: 0.0002};
function spreadOf(sym){ const s = String(sym).toUpperCase();
  if(s.startsWith('XAU')) return SPREAD.XAU; if(s.startsWith('XAG')) return SPREAD.XAG; if(s.startsWith('BTC')) return SPREAD.BTC;
  const [b, q] = s.split('/'); if(q === 'JPY') return b === 'USD' ? SPREAD.JPY : SPREAD.JPYX;
  return b === 'USD' || q === 'USD' ? SPREAD.X : SPREAD.CROSS; }
const isCrypto = s => /^(BTC|ETH)/.test(String(s).toUpperCase());
// contract size of 1 lot (MT4/MT5 convention)
const CONTRACT = s => { const u = String(s).toUpperCase(); return u.startsWith('XAU') ? 100 : u.startsWith('XAG') ? 5000 : isCrypto(u) ? 1 : 100000; };

// daily closes from the history module ('1day' in Twelve-Data shape, newest first)
function dailyOf(H, sym){
  const j = H.bars(sym, '1day', 0); if(!j || j.error || !Array.isArray(j.values)) return null;
  const B = j.values.map(v => ({t: Date.parse(v.datetime.replace(' ', 'T') + 'Z'), c: +v.close})).filter(b => isFinite(b.t) && b.c > 0).reverse();
  // a weekday bar with almost no trading (holiday stub) is dropped
  return B.length > 300 ? B : null;
}
const wk = t => { const d = new Date(t), day = (d.getUTCDay() + 6) % 7; return Math.floor((t - day*864e5)/(7*864e5)); };   // ISO-week id

// one instrument through time: daily return, ex-ante vol, signal, weekly target size (before the portfolio scale)
function instSeries(sym, B){
  const n = B.length, per = isCrypto(sym) ? 365 : 261, L = isCrypto(sym) ? LB.map(x => Math.round(x*365/261)) : LB;
  const out = []; let v = null;
  for(let i = 1; i < n; i++){
    const r = B[i].c/B[i-1].c - 1;
    v = v == null ? r*r : LAM*v + (1 - LAM)*r*r;
    const ok = i >= L[2] && i >= 60, sig = ok ? L.reduce((a, l) => a + Math.sign(B[i].c - B[i - l].c), 0)/L.length : 0;
    const vol = Math.sqrt(v*per);
    out.push({t: B[i].t, c: B[i].c, r, vol, sig, ok, last: i === n - 1 || wk(B[i+1].t) !== wk(B[i].t), comp: ok ? L.map(l => Math.sign(B[i].c - B[i - l].c)) : null, per});
  }
  return out;
}
// simulate: positions set on the week's last close, earning the following days' returns
function simulate(series, longOnly){
  const days = new Map();                 // date → {pnl, gross, n}
  const inst = {};
  Object.entries(series).forEach(([sym, S]) => {
    const sp = spreadOf(sym), per = S.length ? S[0].per : 261; let w = 0; const R = [];
    for(let i = 0; i < S.length; i++){
      const x = S[i];
      // today's return on yesterday's position
      const g = w*x.r, fin = Math.abs(w)*FIN/per;
      let cost = 0;
      if(x.last && x.ok && x.vol > 0){
        const tgt = Math.max(-MAXLEV, Math.min(MAXLEV, (longOnly ? 1 : x.sig)*TAU/x.vol));
        if(Math.abs(tgt - w) > BAND*Math.max(Math.abs(w), Math.abs(tgt)) || (tgt === 0) !== (w === 0)){ cost = Math.abs(tgt - w)*sp/x.c; w = tgt; }
      }
      const net = g - fin - cost, k = Math.floor(x.t/864e5);
      const D = days.get(k) || {pnl: 0, gross: 0, n: 0}; D.pnl += net; D.gross += g; D.n++; days.set(k, D);
      R.push({t: x.t, net, g});
    }
    inst[sym] = R;
  });
  return {days, inst};
}
function stats(P, per){
  const n = P.length; if(n < 50) return null;
  const m = P.reduce((a, b) => a + b, 0)/n, sd = Math.sqrt(P.reduce((a, b) => a + (b - m)*(b - m), 0)/(n - 1));
  let eq = 1, peak = 1, dd = 0; P.forEach(p => { eq *= 1 + p; peak = Math.max(peak, eq); dd = Math.max(dd, 1 - eq/peak); });
  const years = n/per, sr = sd > 0 ? m/sd*Math.sqrt(per) : 0;
  return {n, years: +years.toFixed(1), ann: +(m*per).toFixed(4), vol: +(sd*Math.sqrt(per)).toFixed(4), sharpe: +sr.toFixed(2), t: +(sr*Math.sqrt(years)).toFixed(2), maxDD: +dd.toFixed(4), total: +(eq - 1).toFixed(4)};
}
function run(H, syms, opt = {}){
  const series = {}, skipped = [];
  syms.forEach(s => { let B = null; try{ B = dailyOf(H, s); }catch(e){} if(!B){ skipped.push(s); return; } series[s] = instSeries(s, B); });
  const names = Object.keys(series); if(names.length < 2) return {error: 'хангалттай өдрийн түүх алга (2+ хэрэгсэл хэрэгтэй)', skipped};
  const simAndScale = longOnly => {
    const {days, inst} = simulate(series, longOnly);
    const keys = [...days.keys()].sort((a, b) => a - b);
    // the first day every instrument may hold a position (after its 12-month warm-up)
    const start = Math.max(...names.map(s => { const f = series[s].find(x => x.ok); return f ? Math.floor(f.t/864e5) : Infinity; }));
    const ks = keys.filter(k => k > start);
    const raw = ks.map(k => days.get(k).pnl/names.length), rawG = ks.map(k => days.get(k).gross/names.length);
    // observations per year from the calendar (crypto trades at weekends, so it is not 261)
    const per = ks.length > 1 ? ks.length/((ks[ks.length - 1] - ks[0] + 1)/365.25) : 261;
    const st0 = stats(raw, per), scale = st0 && st0.vol > 0 ? TARGET/st0.vol : 1;
    const P = raw.map(p => p*scale), G = rawG.map(p => p*scale);
    return {ks, P, G, scale, start, per};
  };
  const T = simAndScale(false), Bm = simAndScale(true);
  if(!T.P.length) return {error: 'тест хийх хугацаа хэт богино', skipped};
  const pp = T.per, all = stats(T.P, pp), gross = stats(T.G, pp), cut = Math.floor(T.P.length*0.6);
  const yearly = {}; T.ks.forEach((k, i) => { const y = new Date(k*864e5).getUTCFullYear(); yearly[y] = (yearly[y] || 1)*(1 + T.P[i]); });
  const years = Object.entries(yearly).map(([y, e]) => ({y: +y, r: +(e - 1).toFixed(4)}));
  // per-instrument Sharpe of its own (unscaled) trend P/L
  const perInst = names.map(s => { const S = series[s], first = S.findIndex(x => x.ok); const {inst} = simulate({[s]: S}, false); const P = inst[s].slice(first + 1).map(x => x.net); const st = stats(P, S[0].per); return {sym: s, sharpe: st ? st.sharpe : null, years: st ? st.years : 0}; });
  // equity curve (weekly points) for the chart
  const curve = []; let e = 1, eb = 1; T.ks.forEach((k, i) => { e *= 1 + T.P[i]; eb *= 1 + (Bm.P[i] || 0); if(i % 5 === 0 || i === T.ks.length - 1) curve.push([k, +e.toFixed(4), +eb.toFixed(4)]); });
  // ---- current positions: the last week's target, in "notional ÷ account" ----
  const now = names.map(s => {
    const S = series[s], x = S[S.length - 1];
    // the size held now = the target set on the last completed week's close
    // the newest bar counts as a week's end once its week is over (Friday close for FX, Sunday for crypto, or a later week has begun)
    const ended = q => { const dw = new Date(q.t).getUTCDay(); return wk(Date.now()) > wk(q.t) || (isCrypto(s) ? dw === 0 : dw === 5); };
    let j = S.length - 1; if(!ended(x)){ j--; while(j > 0 && !S[j].last) j--; }
    const y = S[j], w = y.ok && y.vol > 0 ? Math.max(-MAXLEV, Math.min(MAXLEV, y.sig*TAU/y.vol))*T.scale/names.length : 0;
    return {sym: s, t: y.t, price: y.c, sig: +y.sig.toFixed(3), comp: y.comp, vol: +y.vol.toFixed(4), w: +w.toFixed(4), contract: CONTRACT(s), spread: spreadOf(s), lastBar: x.t};
  });
  return {at: Date.now(), asOf: Math.max(...names.map(s => series[s][series[s].length - 1].t)), syms: names, skipped, scale: +T.scale.toFixed(4),
    rules: {LB, TARGET, BAND, FIN, TAU, MAXLEV},
    stats: all, gross, first: stats(T.P.slice(0, cut), pp), second: stats(T.P.slice(cut), pp), bench: stats(Bm.P, Bm.per),
    from: T.ks[0]*864e5, to: T.ks[T.ks.length - 1]*864e5, years, perInst, curve, now};
}
// USD value of one unit of the base currency (for lot sizes of crosses)
function baseUsd(sym, now){
  const [b, q] = String(sym).toUpperCase().split('/'); const px = s => (now.find(x => x.sym === s) || {}).price;
  if(q === 'USD') return px(sym); if(b === 'USD') return 1;
  if(px(b + '/USD')) return px(b + '/USD'); if(px('USD/' + b)) return 1/px('USD/' + b);
  return null;
}
// lots for an account (USD) — weight = notional ÷ account
function lotsFor(R, acct){
  return R.now.map(x => { const bu = baseUsd(x.sym, R.now), notional = x.w*acct, units = bu ? notional/bu : null, lots = units != null ? units/x.contract : null;
    return Object.assign({}, x, {notional: +notional.toFixed(0), lots: lots != null ? +lots.toFixed(2) : null, tooSmall: lots != null && Math.abs(lots) < 0.01 && x.w !== 0}); });
}
// smallest account at which every non-zero position is at least 0.01 lot
function minAccount(R){ let m = 0; R.now.forEach(x => { const bu = baseUsd(x.sym, R.now); if(!bu || !x.w) return; const need = 0.01*x.contract*bu/Math.abs(x.w); m = Math.max(m, need); }); return Math.ceil(m/100)*100; }

const pc = x => x == null ? '—' : (x >= 0 ? '+' : '') + (x*100).toFixed(1) + '%';
const arrow = s => s > 0.5 ? '▲▲' : s > 0 ? '▲' : s < -0.5 ? '▼▼' : s < 0 ? '▼' : '·';
function verdict(R){
  const s = R.stats, a = R.first, b = R.second; if(!s) return 'тест хийгдсэнгүй';
  if(s.sharpe > 0 && a && b && a.sharpe > 0 && b.sharpe > 0 && s.t >= 2) return '✓ эерэг — хоёр хугацааны хэсэгт ижил, статистикийн хувьд итгэлтэй (t ≥ 2)';
  if(s.sharpe > 0 && a && b && a.sharpe > 0 && b.sharpe > 0) return '≈ эерэг, хоёр хэсэгт ижил — гэхдээ статистикийн хувьд итгэл хангалтгүй (t < 2)';
  if(s.sharpe > 0) return '≈ эерэг ч хугацааны хэсэг бүрт биш';
  return '✕ энэ хугацаа, хэрэгслүүд дээр алдагдалтай';
}
function text(R, acct, prev){
  if(!R || R.error) return '📈 Тренд систем: ' + (R ? R.error : 'тооцоо хийгдээгүй');
  const s = R.stats, d = t => new Date(t).toISOString().slice(0, 10);
  const L = [`📈 Тренд систем (time-series momentum) · ${R.syms.length} хэрэгсэл`,
    `Түүхэн тест ${d(R.from)} → ${d(R.to)} (${s.years} жил), зардал хассан, 10%-ийн хэлбэлзэлд тааруулсан:`,
    ` жилд ${pc(s.ann)} · Sharpe ${s.sharpe} (t=${s.t}) · хамгийн их уналт −${(s.maxDD*100).toFixed(1)}%`,
    ` эхний 60% / сүүлийн 40%: Sharpe ${R.first ? R.first.sharpe : '—'} / ${R.second ? R.second.sharpe : '—'} · зөвхөн LONG барьсан бол Sharpe ${R.bench ? R.bench.sharpe : '—'}`,
    ` зардалгүй бол жилд ${pc(R.gross ? R.gross.ann : null)} — спред ба swap-ийн нөлөө жилд ${pc(R.gross ? s.ann - R.gross.ann : null)}`,
    ` → ${verdict(R)}`,
    '', `Одоогийн байршил (${d(R.asOf)} хаалтаар, данс $${acct}):`];
  lotsFor(R, acct).sort((a, b) => Math.abs(b.w) - Math.abs(a.w)).forEach(x => {
    const p = prev && prev.find(y => y.sym === x.sym), ch = !p ? '' : Math.sign(p.w) !== Math.sign(x.w) ? (x.w === 0 ? ' ⟵ ХААХ' : p.w === 0 ? ' ⟵ ШИНЭ' : ' ⟵ ЭРГҮҮЛЭХ') : Math.abs(x.w - p.w) > BAND*Math.max(Math.abs(x.w), Math.abs(p.w)) ? ' ⟵ хэмжээ өөрчлөх' : '';
    L.push(` ${arrow(x.sig)} ${x.sym}: ${x.w === 0 ? 'байршилгүй' : (x.w > 0 ? 'LONG ' : 'SHORT ') + (x.tooSmall ? '<0.01 лот — данс бага тул алгас' : x.lots != null ? Math.abs(x.lots).toFixed(2) + ' лот' : '')}${ch}`); });
  const ma = minAccount(R); L.push('', `Бүх байршлыг 0.01 лотоор нээх хамгийн бага данс ≈ $${ma}. Шинэчлэх: даваа гаригт зах нээгдэхэд. Гарын авлага: апп → 📈 Тренд систем.`, 'Санхүүгийн зөвлөгөө биш — түүхэн үр дүн ирээдүйг баталгаажуулахгүй.');
  return L.join('\n');
}
return {run, text, lotsFor, minAccount, verdict};
})();
const TREND_FILE = path.join(DATA, 'trend.json'), TREND_LIVE = path.join(DATA, 'trend-live.json');
let TREND = null;
const trendAcct = () => ST.trendAcct || CFG.trendAcct;
function trendGet(){ if(!TREND){ try{ TREND = JSON.parse(fs.readFileSync(TREND_FILE, 'utf8')); }catch(e){} } return TREND; }
function trendLive(){ try{ return JSON.parse(fs.readFileSync(TREND_LIVE, 'utf8')); }catch(e){ return []; } }
// forward test: every weekly snapshot is kept; the P/L from one snapshot to the next is the system's real out-of-sample result
function trendLiveText(){ const L = trendLive(); if(L.length < 2) return '\n\nБодит (ирээдүйн) туршилт: ' + (L.length ? `${new Date(L[0].asOf).toISOString().slice(0, 10)}-нээс эхэлсэн, эхний долоо хоног дуусаагүй.` : 'долоо хоногийн анхны тайлангаас эхэлнэ.');
  let eq = 1; for(let i = 1; i < L.length; i++){ const a = L[i-1], b = L[i]; let p = 0; a.now.forEach(x => { const y = b.now.find(z => z.sym === x.sym); if(y && x.price > 0) p += x.w*(y.price/x.price - 1); }); eq *= 1 + p; }
  return `\n\nБодит (ирээдүйн) туршилт: ${L.length - 1} долоо хоног · ${eq >= 1 ? '+' : ''}${((eq - 1)*100).toFixed(1)}% (зардалгүй, ${new Date(L[0].asOf).toISOString().slice(0, 10)}-нээс).`; }
// TD candles to verify a symbol's long history against (1 credit, only for symbols the scan never loads)
async function tdPrime(){
  const Hh = hist(); if(!Hh || !CFG.tdKey) return;
  for(const s of CFG.trendSymbols){
    const c = Hh.coverage().find(x => x.symbol === s); if(c && c.verified) continue;
    if(tdStoreRows(s, '1h').length >= 60 || tdStoreRows(s, '15min').length >= 60) continue;
    if(credits().used >= CFG.creditCap*0.8) return;
    try{ creditUse(1);
      const r = await fetch(`${CFG.tdBase}/time_series?timezone=UTC&symbol=${encodeURIComponent(s)}&interval=1h&outputsize=2000&apikey=${encodeURIComponent(CFG.tdKey)}`, {signal: AbortSignal.timeout(45000)});
      const t = await r.text(); let j = null; try{ j = JSON.parse(t); }catch(e){}
      if(j && j.status === 'error'){ log('Тренд: Twelve Data', s, j.message); ST.trendNoTd = Object.assign(ST.trendNoTd || {}, {[s]: String(j.message).slice(0, 120)}); stSave(); }
      else csPut(t, '?timezone=UTC&'); }catch(e){ log('Тренд: Twelve Data-аас лаа авч чадсангүй', s, e.message); }
    await sleep(9000); }
  csFlush();
}
let trendBusy = false;
async function trendCompute(why){
  if(!CFG.trendOn || trendBusy) return null; const Hh = hist(); if(!Hh) return null; trendBusy = true;
  try{ const ok = Hh.coverage().filter(c => c.verified && CFG.trendSymbols.includes(c.symbol)).map(c => c.symbol);
    if(ok.length < 2) return null;
    const R = TR.run(Hh, ok); if(!R || R.error){ log('Тренд систем:', R && R.error); return null; }
    writeAtomic(TREND_FILE, JSON.stringify(R)); TREND = R; log(`Тренд систем тооцогдлоо (${why}): ${R.syms.length} хэрэгсэл, Sharpe ${R.stats.sharpe}`); return R;
  }catch(e){ log('Тренд системийн алдаа:', e.message); return null; } finally{ trendBusy = false; }
}
// weekly signal: Sunday after the night's history update — the positions to hold from Monday's open
async function trendWeekly(){
  const R = await trendCompute('долоо хоногийн тайлан') || trendGet(); if(!R || R.error) return;
  const prev = (ST.trendLast || {}).now || null;
  tgSend(TR.text(R, trendAcct(), prev) + trendLiveText());
  const L = trendLive(); if(!L.length || L[L.length - 1].asOf !== R.asOf){ L.push({asOf: R.asOf, now: R.now.map(x => ({sym: x.sym, w: x.w, price: x.price}))}); writeAtomic(TREND_LIVE, JSON.stringify(L.slice(-520))); }
  ST.trendLast = {asOf: R.asOf, now: R.now.map(x => ({sym: x.sym, w: x.w}))}; ST.trendWeek = ymd(); stSave();
}
// v1.5 «/chart [XAU] [1h]» — a picture of a symbol's chart with its most advanced entry setup
let chartBusy = false;
async function chartCmd(arg){
  if(histTestBusy) return tgSend('Түүхэн тест явж байгаа үед график солихгүй — дууссаны дараа дахин оролдоорой.');
  if(chartBusy) return; chartBusy = true;
  try{
    const parts = String(arg || '').toUpperCase().split(/\s+/).filter(Boolean);
    const ivA = parts.find(p => /^(\d+)(MIN|M|H|D)$/.test(p)), symA = parts.find(p => p !== ivA);
    const ivMap = x => { const m = /^(\d+)(MIN|M|H|D)$/.exec(x); if(!m) return null; return m[2] === 'H' ? m[1] + 'h' : m[2] === 'D' ? m[1] + 'day' : m[1] + 'min'; };
    const syms = (CFG.histSymbols && CFG.histSymbols.length ? CFG.histSymbols : [CFG.sym]);
    const sym = symA ? (syms.find(s => s.replace(/[^A-Z]/g, '').includes(symA.replace(/[^A-Z]/g, ''))) || null) : CFG.sym;
    const iv = ivA ? ivMap(ivA) : CFG.iv;
    if(!sym) return tgSend(`«${symA}» хослол олдсонгүй. Жишээ: /chart XAU 1h`);
    const moved = sym !== CFG.sym || iv !== CFG.iv;
    if(moved){ await station.eval(([s, i]) => window.__MP.select(s, i), [sym, iv]); await sleep(9000); }
    const P = await station.eval(() => window.__MP.chartPic && window.__MP.chartPic());
    if(moved) await station.eval(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]);
    if(!P || !P.img){ tgSend('График зурж чадсангүй' + (P && P.error ? ': ' + P.error : '.')); return; }
    tgSend(P.caption, {photo: Buffer.from(P.img.slice(P.img.indexOf(',') + 1), 'base64')});
  }finally{ chartBusy = false; }
}
function histPick(arg){
  const Hh = hist(), cov = Hh ? Hh.coverage() : [], ok = cov.filter(c => c.verified && CFG.histSymbols.includes(c.symbol)).map(c => c.symbol);
  const a = String(arg || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if(a && a !== 'ALL'){ const m = cov.filter(c => c.code.includes(a)).map(c => c.symbol); return m.length ? m : [CFG.sym]; }
  return ok.length ? ok : [CFG.sym];
}
async function histTest(reason, syms){
  if(histTestBusy || !station.alive) return null; histTestBusy = true;
  const out = []; syms = (syms && syms.length ? syms : [CFG.sym]);
  const Hh = hist(), cov = Hh ? Hh.coverage() : [], unver = syms.filter(s => { const c = cov.find(x => x.symbol === s); return c && !c.verified; });
  try{
    tgSend(`🧪 Түүхэн тест эхэллээ (${reason}) — ${syms.join(', ')} · ${CFG.histTestIvs.join(', ')}. ${syms.length*CFG.histTestIvs.length} тест, ойролцоогоор ${Math.round(syms.length*20)} мин.${unver.length ? `\n⚠ ${unver.join(', ')}: урт түүх хараахан шалгагдаагүй тул Twelve Data-гийн богино түүхээр тестлэнэ.` : ''}`);
    for(const sym of syms) for(const iv of CFG.histTestIvs){
      await station.eval(([s, i]) => window.__MP.select(s, i), [sym, iv]);
      let ok = false; for(let k = 0; k < 36 && !ok; k++){ await sleep(5000); const p = await station.eval(() => window.__MP.ping()); ok = !!(p && p.sym === sym && p.iv === iv && p.n > 300); }
      if(!ok){ log('Түүхэн тест: график ачаалагдсангүй', sym, iv); tgSend(`⚠ Түүхэн тест: ${sym} ${iv} график ачаалагдсангүй — алгаслаа.`); continue; }
      const t0 = Date.now(); let R = null;
      try{ R = await station.page.evaluate(() => window.__MP.histRun()); }catch(e){ log('Түүхэн тестийн алдаа:', e.message); }
      if(R){ out.push(R); log(`Түүхэн тест ${sym} ${iv}: ${Math.round((Date.now() - t0)/1000)} сек`); tgSend(histTestText(R)); }
    }
    // pooled over everything this station has tested (all symbols/timeframes)
    const D = await station.eval(() => window.__MP.diagText && window.__MP.diagText());
    if(D) tgSend(D);
    const LC = await station.eval(() => window.__MP.lcText && window.__MP.lcText());   // v77 pattern lifecycle
    if(LC) tgSend(LC);
  }finally{
    await station.eval(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]);
    histTestBusy = false; ST.lastHistTest = Date.now(); stSave();
    backupNow(false).catch(() => {});
  }
  return out;
}
function histTestText(R){
  const L = [`🧪 Түүхэн тест · ${R.sym} ${R.iv} · ${Math.round(R.sec/60)} мин`];
  if(R.bt){
    L.push(`${R.bt.src === 'dukascopy' ? 'Урт түүх (Dukascopy)' : 'Twelve Data'}: ${String(R.bt.from).slice(0, 10)} → ${String(R.bt.to).slice(0, 10)} · ${R.bt.n} лаа · ${R.bt.sig} дохио`);
    R.bt.rows.forEach(r => L.push(` • ${r.name}: ${r.n} · TP ${pc(r.wr)} · ${rr(r.exp)}${r.gross != null ? ` (зардалгүй ${rr(r.gross)})` : ''} — ${r.verdict}`));
  } else L.push('Арилжааны төлөвлөгөөний тест хийгдсэнгүй.');
  if(R.dowTxt) L.push(R.dowTxt);
  if(R.fq && R.fq.length){
    L.push('', `Таамгийн нарийвчлал (${R.fqInfo && R.fqInfo.long ? 'урт түүхээр' : 'богино түүхээр'}, ${R.fqInfo ? R.fqInfo.pts : '—'} цэг):`);
    R.fq.forEach(f => L.push(` • ${f.name}: ${f.calls ? pc(f.hr) + ` (${f.calls} таамаг, суурь ${pc(f.naive)})` : '—'} — ${f.lbl}`));
  }
  return L.join('\n');
}

function csList(){
  return fs.readdirSync(DIRS.candles).filter(f => f.endsWith('.json')).map(f => { const k = f.slice(0, -5), e = csGet(k), ds = [...e.rows.keys()].sort(); return {key: k, symbol: e.meta && e.meta.symbol, interval: e.meta && e.meta.interval, n: ds.length, from: ds[0] || null, to: ds[ds.length - 1] || null}; });
}

// ---------------------------------------------------------------- the station (headless app)
const sleep = ms => new Promise(r => setTimeout(r, ms));
let SHUTTING = false;
const station = {
  ctx: null, page: null, alive: false, starting: false, since: 0, restarts: 0, fails: 0, last: null,
  async start(){
    if(this.starting) return; this.starting = true;
    try{
      const {chromium} = require('playwright');
      this.ctx = await chromium.launchPersistentContext(DIRS.profile, {
        headless: true, viewport: {width: 1280, height: 900}, deviceScaleFactor: 1, locale: 'mn-MN',
        args: ['--disable-dev-shm-usage', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows'],
      });
      this.ctx.on('close', () => { if(this.alive && !SHUTTING){ this.alive = false; log('Chromium хаагдлаа'); this.schedule('браузер хаагдсан'); } });
      await this.ctx.exposeBinding('__mpNotify', (src, title, body, img) => onAppNotify(title, body, img));
      await this.ctx.exposeBinding('__mpBigSave', (src, key, val) => bigSave(key, val));
      await this.ctx.addInitScript(INIT_SCRIPT());
      await this.ctx.route(/api\.twelvedata\.com/, tdRoute);
      await this.ctx.route(/api\.telegram\.org/, r => r.fulfill({status: 200, contentType: 'application/json', body: '{"ok":true}'}));   // the server sends Telegram itself
      const page = this.ctx.pages()[0] || await this.ctx.newPage(); this.page = page;
      page.on('crash', () => { log('Станцын хуудас унасан (crash)'); this.schedule('хуудас унасан'); });
      page.on('pageerror', e => logThrottled('pageerror', 'App JS алдаа: ' + String(e.message).slice(0, 300)));
      await page.goto(`http://127.0.0.1:${CFG.port}/`, {waitUntil: 'load', timeout: 120000});
      await page.waitForFunction(() => window.__MP && window.__MP.ping, null, {timeout: 60000});
      this.alive = true; this.since = Date.now(); this.fails = 0;
      log('✓ Станц ачаалагдлаа');
      // chart symbol / timeframe, then the forward test
      await sleep(8000);
      const p = await page.evaluate(() => window.__MP.ping());
      if(CFG.sym && (p.sym !== CFG.sym || p.iv !== CFG.iv)){ await page.evaluate(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]); await sleep(8000); }
      if(CFG.autoStation){ const F = await page.evaluate(() => window.__MP.startStation()); log('Станц:', F && F.on ? `ажиллаж байна (${(F.syms || []).join(', ')})` : 'асаагүй'); }
    }catch(e){ log('Станц эхлүүлэхэд алдаа:', String(e && e.message || e)); this.alive = false; this.schedule('эхлүүлж чадсангүй'); }
    finally{ this.starting = false; }
  },
  async stop(){ this.alive = false; try{ if(this.ctx) await this.ctx.close(); }catch(e){} this.ctx = null; this.page = null; },
  async restart(why){ log('Станцыг дахин эхлүүлж байна:', why); this.restarts++; await this.stop(); await sleep(3000); await this.start(); },
  schedule(why){
    if(this.timer) return;
    const wait = Math.min(5*60e3, 15e3*Math.pow(2, Math.min(this.fails++, 4)));
    tgSend(`⚠ Станц дахин эхэлж байна: ${why}`, {dedupe: 'restart', every: 30*60e3});
    this.timer = setTimeout(async () => { this.timer = null; await this.restart(why); }, wait);
  },
  async eval(fn, arg){ if(!this.alive || !this.page) return null; try{ return await this.page.evaluate(fn, arg); }catch(e){ return null; } },
};
function INIT_SCRIPT(){
  // runs in the page before the app: marks the server mode, gives the app
  // its API key / settings, and turns browser notifications into Telegram
  return `(() => {
    window.__MP_SERVER = true; window.__MP_TOKEN = ${JSON.stringify(CFG.token)};
    try{
      const set = (k, v) => { if(localStorage.getItem(k) !== v) localStorage.setItem(k, v); };
      set('eud_twelvedata_apikey', ${JSON.stringify(CFG.tdKey)});
      set('eud_autorefresh_secs', ${JSON.stringify(CFG.refreshSec)});
      if(!localStorage.getItem('eud_disc_v1')) localStorage.setItem('eud_disc_v1', '1');
      localStorage.setItem('eud_bull', '0');
    }catch(e){}
    const N = function(title, opt){ try{ window.__mpNotify(String(title || ''), String((opt && opt.body) || ''), (opt && typeof opt.image === 'string' && opt.image.startsWith('data:image/png;base64,')) ? opt.image : null); }catch(e){} this.close = () => {}; };
    N.permission = 'granted'; N.requestPermission = () => Promise.resolve('granted');
    try{ Object.defineProperty(window, 'Notification', {value: N, configurable: true, writable: true}); }catch(e){ window.Notification = N; }
  })();`;
}
const logT = new Map();
function logThrottled(k, msg){ const t = logT.get(k) || 0; if(Date.now() - t < 10*60e3) return; logT.set(k, Date.now()); log(msg); }
// the same message is not repeated within 6 h — also across restarts (the
// app re-announces a still-standing setup after every reload)
function onAppNotify(title, body, img){
  const h = crypto.createHash('sha1').update(title + '\n' + body).digest('hex').slice(0, 16), now = Date.now();
  ST.seen = ST.seen || {}; Object.keys(ST.seen).forEach(k => { if(now - ST.seen[k] > 6*36e5) delete ST.seen[k]; });
  if(ST.seen[h]){ log('Мэдэгдэл (давтагдсан — илгээгээгүй):', title); return; }
  ST.seen[h] = now; stSave(); log('Мэдэгдэл:', title + (img ? ' (зурагтай)' : ''));
  // v1.5: an entry signal comes with its chart picture (the app draws it)
  let photo = null; if(img){ try{ photo = Buffer.from(img.slice(img.indexOf(',') + 1), 'base64'); if(photo.length < 1000 || photo.length > 9e6) photo = null; }catch(e){ photo = null; } }
  const text = `🔔 ${title}\n${body}`;
  if(photo && text.length <= 1000) tgSend(text, {photo}); else { tgSend(text); if(photo) tgSend('📈 ' + title, {photo}); }
}
// every Twelve Data request of the station passes here: count the credit,
// keep the server's daily cap, and store the candles that came back
async function tdRoute(route){
  const url = route.request().url();
  if(/apikey=probe/.test(url)) return route.fulfill({status: 200, contentType: 'application/json', body: '{"code":401,"message":"probe","status":"error"}'});
  const C = credits();
  if(C.used >= CFG.creditCap) return route.fulfill({status: 200, contentType: 'application/json', body: JSON.stringify({code: 429, status: 'error', message: `You have run out of API credits for the day. ${C.used} API credits were used, with the current limit being ${CFG.creditCap} (mp-server cap).`})});
  const m = /[?&]symbol=([^&]+)/.exec(url); creditUse(m ? Math.max(1, decodeURIComponent(m[1]).split(',').length) : 1);
  try{
    // candle times always in UTC (an app older than v76 does not ask for it)
    let path0 = url.replace(/^https?:\/\/api\.twelvedata\.com/, '');
    if(/^\/time_series\?/.test(path0) && !/[?&]timezone=/i.test(path0)) path0 = path0.replace('?', '?timezone=UTC&');
    const up = CFG.tdBase + path0;
    const resp = await route.fetch({url: up, timeout: 45000});
    const body = await resp.text();
    if(/\/time_series/.test(url)) csPut(body, path0);
    await route.fulfill({status: resp.status(), headers: {'content-type': 'application/json', 'access-control-allow-origin': '*'}, body});
  }catch(e){ logThrottled('tdnet', 'Twelve Data-д холбогдож чадсангүй: ' + e.message); try{ await route.abort('failed'); }catch(x){} }
}
async function shot(){ if(!station.alive || !station.page) return null; try{ return await station.page.screenshot({type: 'png'}); }catch(e){ return null; } }

// ---------------------------------------------------------------- backups
let lastBackup = 0;
async function backupNow(daily){
  const B = await station.eval(() => window.__MP.backup());
  if(!B || !B.keys) return false;
  const txt = JSON.stringify(B);
  try{
    writeAtomic(path.join(DIRS.backups, 'latest.json'), txt);
    if(daily) writeAtomic(path.join(DIRS.backups, `station-${ymd()}.json`), txt);
    if(daily && CFG.backupCopy){ try{ fs.mkdirSync(CFG.backupCopy, {recursive: true}); fs.copyFileSync(path.join(DIRS.backups, 'latest.json'), path.join(CFG.backupCopy, `station-${ymd()}.json`)); }catch(e){ log('Нөөцийг BACKUP_COPY_DIR руу хуулж чадсангүй:', e.message); } }
    pruneDir(DIRS.backups, /^station-\d{4}-\d\d-\d\d\.json$/, CFG.backupKeep);
    lastBackup = Date.now(); return true;
  }catch(e){ log('Нөөц бичиж чадсангүй:', e.message); return false; }
}
function latestBackup(){ try{ return fs.readFileSync(path.join(DIRS.backups, 'latest.json'), 'utf8'); }catch(e){ return null; } }
// the daily backup also goes to the owner's Telegram chat — a copy that
// survives even if this machine (or the cloud account) is lost
function backupToTelegram(caption){
  const b = latestBackup(); if(!b) return false;
  const buf = Buffer.from(b, 'utf8'); if(buf.length > 45*1024*1024){ tgSend('⚠ Нөөц файл Telegram-д хэт том байна (' + Math.round(buf.length/1e6) + ' MB).'); return false; }
  let n = 0; try{ n = Object.keys(JSON.parse(b).keys || {}).length; }catch(e){}
  tgSend(`${caption} · ${ymd()} · ${n} хэсэг · ${Math.round(buf.length/1024)} KB\nСэргээх: апп → 🧪 Үр дүнгийн нотолгоо → 📂 Файлаас сэргээх`, {doc: buf, docName: `station-${ymd()}.json`});
  return true;
}

// ---------------------------------------------------------------- price alarms (compatible with the phone's «Сервер сэрүүлэг»)
async function alarmsRun(){
  const live = ST.alarms.filter(a => !ST.fired.includes(a.id)); if(!live.length) return;
  const syms = [...new Set(live.map(a => String(a.sym).split(':')[0]))];
  if(credits().used + syms.length > CFG.creditCap) return;
  creditUse(syms.length);
  let j; try{ const r = await fetch(`${CFG.tdBase}/price?symbol=${encodeURIComponent(syms.join(','))}&apikey=${encodeURIComponent(CFG.tdKey)}`, {signal: AbortSignal.timeout(30000)}); j = await r.json(); }catch(e){ return; }
  const px = s => syms.length === 1 ? parseFloat(j.price) : parseFloat((j[s] || {}).price);
  for(const a of live){
    const p = px(String(a.sym).split(':')[0]); if(!isFinite(p)) continue;
    const hit = a.kind === 'above' ? p >= a.level : a.kind === 'below' ? p <= a.level : a.kind === 'zone' ? (p >= a.lo && p <= a.hi) : false;
    if(hit){ tgSend(`🔔 ${a.text}\n${a.sym} одоо ${p}`); ST.fired.push(a.id); stSave(); log('Сэрүүлэг:', a.text); }
  }
}

// ---------------------------------------------------------------- report text
const pc = x => x == null || !isFinite(x) ? '—' : Math.round(x*100) + '%';
const rr = x => x == null || !isFinite(x) ? '—' : (x >= 0 ? '+' : '') + (+x).toFixed(2) + 'R';
function fmtPx(p){ p = +p; return !isFinite(p) ? '—' : p.toFixed(p >= 1000 ? 2 : p >= 10 ? 3 : 5); }
function dur(ms){ const h = Math.floor(ms/36e5), d = Math.floor(h/24); return d ? `${d} хоног ${h % 24} цаг` : `${h} цаг ${Math.floor(ms/6e4) % 60} мин`; }
async function reportText(full){
  const S = await station.eval(() => window.__MP.summary());
  const C = credits(), mem = 1 - os.freemem()/os.totalmem();
  const L = [];
  L.push(`${full ? '📊 Өдрийн тайлан' : '🖥 Серверийн байдал'} · ${new Date().toLocaleString('sv-SE').slice(0, 16)}`);
  L.push(`Сервер: ${dur(process.uptime()*1000)} ажиллаж байна · RAM ${Math.round(mem*100)}% · станц ${station.alive ? 'ачаалагдсан' : '⚠ ачаалагдаагүй'}${station.restarts ? ` · ${station.restarts} удаа дахин эхэлсэн` : ''}`);
  L.push(`API: сервер өнөөдөр ${C.used}/${CFG.creditCap} кредит (Twelve Data хязгаар 800 — утсан дээрх хэрэглээ үүнд орохгүй)`);
  if(!S){ L.push('Станцын өгөгдөл одоогоор уншигдсангүй.'); return L.join('\n'); }
  const F = S.fwd, J = S.journal;
  L.push(F && F.on ? `Бодит туршилт: ● ажиллаж байна · ${((Date.now() - F.since)/DAY).toFixed(1)} хоног · ${(F.syms || []).join(', ')} · ${S.scanCfg.every || '—'} мин тутам` : 'Бодит туршилт: ⏸ зогссон');
  L.push(`График: ${S.sym} ${S.iv} · ${S.ping && S.ping.price != null ? fmtPx(S.ping.price) : '—'} · ${S.verdict ? S.verdict.action : '—'}`);
  const nToday = ST.lastJr && ST.lastJr.day !== ymd() ? J.total - ST.lastJr.n : null;
  L.push(`Журнал: ${J.total} дохио (эхэлснээс +${J.sinceStart}${nToday != null ? `, сүүлийн тайлангаас +${nToday}` : ''}) · дууссан ${J.done} · нээлттэй ${J.open} · цэвэр ${rr(J.netR)}`);
  if(full){
    L.push('', 'Аргууд (100 дууссан дохионоос дүгнэнэ):');
    S.methods.forEach(m => L.push(` • ${m.name}: ${m.n || 0} дууссан · ${m.n ? pc(m.wr) : '—'} · ${m.n ? rr(m.exp) : '—'} — ${m.lbl}`));
    if(S.fq && S.fq.length){ L.push('', `Таамгийн нарийвчлал (${S.sym} ${S.iv}):`); S.fq.forEach(f => L.push(` • ${f.name}: ${f.calls ? pc(f.hr) + ` (${f.calls} таамаг, энгийн суурь ${pc(f.naive)})` : '—'} — ${f.lbl}`)); }
    const sc = Object.entries(S.scan || {}); if(sc.length){ L.push('', 'Скан:'); sc.forEach(([k, x]) => L.push(` • ${k}: ${({confirmed: (x.dir > 0 ? '▲ LONG' : '▼ SHORT') + ' бүрдсэн', setup: 'бэлтгэл', trend: 'тренд', none: 'дохиогүй', nodata: 'өгөгдөлгүй', paid: 'төлбөртэй', err: 'алдаа'})[x.status] || x.status}`)); }
  }
  return L.join('\n');
}

// ---------------------------------------------------------------- HTTP
const okTok = t => { const a = Buffer.from(String(t || '')), b = Buffer.from(CFG.token); return a.length === b.length && crypto.timingSafeEqual(a, b); };
function authed(req){
  if(okTok(req.headers['x-secret'])) return true;
  const ck = /(?:^|;\s*)mp_t=([^;]+)/.exec(req.headers.cookie || ''); if(ck && okTok(decodeURIComponent(ck[1]))) return true;
  return false;
}
const CORS = {'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,X-Secret', 'Access-Control-Max-Age': '600'};
function send(res, code, body, type = 'application/json; charset=utf-8', extra = {}){
  res.writeHead(code, Object.assign({'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}, CORS, extra));
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function readBody(req, max = 512*1024){ return new Promise((ok, no) => { let n = 0; const ch = []; req.on('data', c => { n += c.length; if(n > max){ no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch).toString('utf8'))); req.on('error', no); }); }
function readRaw(req, max){ return new Promise((ok, no) => { let n = 0; const ch = []; req.on('data', c => { n += c.length; if(n > max){ no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', no); }); }
// ---------------------------------------------------------------- self-update: mp-server.zip uploaded on the /status page
// (no SSH needed): unpack to a temp folder, check every file (syntax, version, app), keep the
// current files in data/update-prev, copy the new ones in, npm install only if dependencies changed,
// then exit — systemd (or run.bat) starts the new version.
const execFileP = (cmd, args, opt = {}) => new Promise((ok, no) => require('child_process').execFile(cmd, args, Object.assign({timeout: 10*60e3, maxBuffer: 8*1024*1024}, opt), (e, so, se) => e ? no(Object.assign(e, {stderr: String(se || '')})) : ok(String(so || ''))));
const UPD_FILES = ['server.js', 'hist.js', 'lzma.js', 'trend.js', 'package.json', 'config.example.env', 'README.txt', 'install.sh', 'mpctl', 'install.bat', 'check.bat', 'test-run.bat', 'run.bat', 'restart.bat', 'stop.bat', 'setup-windows.ps1'];
async function selfUpdate(buf){
  if(!buf || buf.length < 1000 || buf[0] !== 0x50 || buf[1] !== 0x4b) throw new Error('Энэ mp-server.zip файл биш байна.');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mpupd-')), x = path.join(tmp, 'x');
  try{
    const zf = path.join(tmp, 'u.zip'); fs.writeFileSync(zf, buf); fs.mkdirSync(x);
    if(process.platform === 'win32') await execFileP('powershell', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -Force -LiteralPath '${zf.replace(/'/g, "''")}' -DestinationPath '${x.replace(/'/g, "''")}'`]);
    else await execFileP('unzip', ['-q', '-o', zf, '-d', x]).catch(e => { throw new Error('unzip ажилласангүй: ' + (e.stderr || e.message).slice(0, 200)); });
    const top = [x].concat(fs.readdirSync(x).map(d => path.join(x, d))).find(d => fs.existsSync(path.join(d, 'server.js')) && fs.existsSync(path.join(d, 'package.json')));
    if(!top) throw new Error('zip дотор mp-server (server.js, package.json) олдсонгүй.');
    const need = ['server.js', 'hist.js', 'lzma.js', 'package.json', path.join('app', 'index.html')].filter(f => !fs.existsSync(path.join(top, f)));
    if(need.length) throw new Error('zip-д дутуу файл: ' + need.join(', '));
    const src = fs.readFileSync(path.join(top, 'server.js'), 'utf8'), to = (/const VERSION = '([^']+)'/.exec(src) || [])[1];
    if(!to || !/^mp-server /.test(to)) throw new Error('server.js-ийн хувилбар танигдсангүй.');
    for(const f of ['server.js', 'hist.js', 'lzma.js']) await execFileP(process.execPath, ['--check', path.join(top, f)]).catch(e => { throw new Error(`${f} алдаатай: ${(e.stderr || e.message).split('\n').slice(0, 3).join(' ')}`); });
    try{ JSON.parse(fs.readFileSync(path.join(top, 'package.json'), 'utf8')); }catch(e){ throw new Error('package.json алдаатай.'); }
    const app = fs.readFileSync(path.join(top, 'app', 'index.html'), 'utf8');
    if(!/market-pattern-dashboard/.test(app) || !/__MP_SERVER/.test(app) || app.length < 100000) throw new Error('zip доторх app/index.html Market Pattern апп биш байна.');
    // keep the running version for a manual roll-back
    const prev = path.join(DATA, 'update-prev'); fs.mkdirSync(path.join(prev, 'app'), {recursive: true});
    UPD_FILES.concat([path.join('app', 'index.html')]).forEach(f => { try{ if(fs.existsSync(path.join(ROOT, f))) fs.copyFileSync(path.join(ROOT, f), path.join(prev, f)); }catch(e){} });
    const depsOld = (() => { try{ return JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).dependencies || {}); }catch(e){ return ''; } })();
    const depsNew = JSON.stringify(JSON.parse(fs.readFileSync(path.join(top, 'package.json'), 'utf8')).dependencies || {});
    UPD_FILES.forEach(f => { const a = path.join(top, f); if(fs.existsSync(a)){ const b = path.join(ROOT, f); fs.copyFileSync(a, b + '.new'); fs.renameSync(b + '.new', b); } });
    try{ fs.copyFileSync(APP_FILE, path.join(ROOT, 'app', 'index.prev.html')); }catch(e){}
    fs.copyFileSync(path.join(top, 'app', 'index.html'), APP_FILE + '.new'); fs.renameSync(APP_FILE + '.new', APP_FILE);
    let npm = false;
    if(depsOld !== depsNew){ npm = true; await execFileP(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], {cwd: ROOT}); }
    return {from: VERSION, to, npm, app: (/ver: 'v(\d+)'/.exec(app) || [])[1] || null};
  }finally{ try{ fs.rmSync(tmp, {recursive: true, force: true}); }catch(e){} }
}
let appHtml = null, appMtime = 0;
function appPage(){
  const st = fs.statSync(APP_FILE);
  if(!appHtml || st.mtimeMs !== appMtime){ appHtml = fs.readFileSync(APP_FILE, 'utf8').replace(/<head([^>]*)>/i, m => m + '<script>window.__MP_SERVED=1;</script>'); appMtime = st.mtimeMs; }
  return appHtml;
}
async function handle(req, res){
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  if(req.method === 'OPTIONS') return send(res, 204, '');
  if(p === '/' || p === '/index.html') return send(res, 200, appPage(), 'text/html; charset=utf-8', {'Cache-Control': 'no-cache'});
  if(p === '/favicon.ico') return send(res, 204, '');
  if(p === '/status'){
    const t = u.searchParams.get('t');
    if(t && okTok(t)) return send(res, 302, '', 'text/plain', {'Location': '/status', 'Set-Cookie': `mp_t=${encodeURIComponent(t)}; Path=/; HttpOnly; SameSite=Strict; Secure; Max-Age=${180*86400}`});
    if(!authed(req)) return send(res, 403, LOGIN_HTML, 'text/html; charset=utf-8');
    return send(res, 200, await statusHtml(), 'text/html; charset=utf-8');
  }
  if(!authed(req)) return send(res, 403, {ok: false, error: 'forbidden'});
  // worker-compatible alarm API (phone: Alert → «Сервер сэрүүлэг»)
  if(p === '/sync' && req.method === 'POST'){
    let b; try{ b = JSON.parse(await readBody(req)); }catch(e){ return send(res, 400, {ok: false}); }
    const alarms = (Array.isArray(b.alarms) ? b.alarms : []).slice(0, 80).filter(a => a && a.id && a.sym && (isFinite(a.level) || (isFinite(a.lo) && isFinite(a.hi)))).map(a => ({id: String(a.id).slice(0, 80), sym: String(a.sym).slice(0, 30), kind: a.kind, level: +a.level, lo: a.lo != null ? +a.lo : undefined, hi: a.hi != null ? +a.hi : undefined, text: String(a.text || '').slice(0, 300)}));
    const ids = new Set(alarms.map(a => a.id)); ST.alarms = alarms; ST.fired = ST.fired.filter(id => ids.has(id)); stSave();
    return send(res, 200, {ok: true, n: alarms.length, fired: ST.fired.length});
  }
  if(p === '/test'){ tgSend('✅ Сервер холбогдлоо. Утас унтраалттай байсан ч энд мэдэгдэл ирнэ.'); return send(res, 200, {ok: true}); }
  if(p === '/api/status'){ const S = await station.eval(() => window.__MP.summary()); return send(res, 200, {ok: true, server: VERSION, host: os.hostname(), uptime: Math.round(process.uptime()), alive: station.alive, since: station.since, restarts: station.restarts, credits: credits(), cap: CFG.creditCap, mem: {free: os.freemem(), total: os.totalmem()}, lastBackup, alarms: ST.alarms.length, station: S}); }
  if(p === '/api/trend'){ const R = trendGet(); return send(res, 200, {ok: !!R, R, acct: trendAcct(), live: trendLive(), last: ST.trendLast || null, hist: hist() ? hist().coverage().filter(c => CFG.trendSymbols.includes(c.symbol)) : []}); }
  if(p === '/api/bigstore'){ const body = JSON.stringify(bigAll());
    if(/\bgzip\b/.test(req.headers['accept-encoding'] || '')) return send(res, 200, require('zlib').gzipSync(body, {level: 6}), 'application/json; charset=utf-8', {'Content-Encoding': 'gzip'});
    return send(res, 200, body); }
  if(p === '/api/backup'){
    if(station.alive && Date.now() - lastBackup > 60e3) await backupNow(false);
    const b = latestBackup(); return b ? send(res, 200, b) : send(res, 404, {ok: false, error: 'нөөц алга'});
  }
  if(p === '/api/shot'){ const png = await shot(); return png ? send(res, 200, png, 'image/png') : send(res, 503, {ok: false}); }
  if(p === '/api/history'){
    const Hh = hist(); if(!Hh) return send(res, 404, {status: 'error', code: 404, message: 'history disabled'});
    const sym = u.searchParams.get('symbol'), iv = u.searchParams.get('interval'), lim = Math.min(400000, Math.max(100, +u.searchParams.get('bars') || 50000));
    if(!sym || !iv) return send(res, 200, {ok: true, coverage: Hh.coverage(), busy: Hh.busy, prog: Hh.prog});
    if(!CFG.histSymbols.includes(sym)) return send(res, 404, {status: 'error', code: 404, message: 'symbol not in HISTORY_SYMBOLS'});
    const r = Hh.bars(sym, iv, lim);
    return r.error ? send(res, 404, {status: 'error', code: 404, message: r.note}) : send(res, 200, JSON.stringify(r));
  }
  if(p === '/api/histtest' && req.method === 'POST'){ if(histTestBusy) return send(res, 409, {ok: false, error: 'busy'}); histTest('/status хуудас', histPick(u.searchParams.get('symbol') || '')); return send(res, 200, {ok: true}); }
  if(p === '/api/candles'){
    const sym = u.searchParams.get('symbol'), iv = u.searchParams.get('interval');
    if(!sym || !iv){ return send(res, 200, {ok: true, sets: csList()}); }
    const e = csGet(csKey(sym, iv)); const ds = [...e.rows.keys()].sort();
    if(u.searchParams.get('format') === 'csv') return send(res, 200, 'datetime,open,high,low,close,volume\n' + ds.map(d => [d, ...e.rows.get(d)].join(',')).join('\n'), 'text/csv; charset=utf-8', {'Content-Disposition': `attachment; filename="${csKey(sym, iv)}.csv"`});
    return send(res, 200, {ok: true, meta: e.meta, n: ds.length, bars: ds.map(d => [d, ...e.rows.get(d)])});
  }
  if(p === '/api/app' && req.method === 'POST'){
    let html; try{ html = await readBody(req, 30*1024*1024); }catch(e){ return send(res, 413, {ok: false, error: 'файл хэт том'}); }
    if(!/market-pattern-dashboard/.test(html) || !/__MP_SERVER/.test(html) || html.length < 100000) return send(res, 400, {ok: false, error: 'Энэ Market Pattern апп-ын (v72+) файл биш байна.'});
    const ver = (/>v(\d+)</.exec(html) || /ver: 'v(\d+)'/.exec(html) || [])[1];
    try{ fs.copyFileSync(APP_FILE, path.join(ROOT, 'app', 'index.prev.html')); }catch(e){}
    writeAtomic(APP_FILE, html); log('Апп шинэчлэгдлээ (upload):', ver ? 'v' + ver : '?');
    return send(res, 200, {ok: true, ver: ver ? 'v' + ver : null});
  }
  if(p === '/api/update' && req.method === 'POST'){
    let buf; try{ buf = await readRaw(req, 40*1024*1024); }catch(e){ return send(res, 413, {ok: false, error: 'файл хэт том'}); }
    let R; try{ R = await selfUpdate(buf); }catch(e){ log('Шинэчлэл амжилтгүй:', e.message); return send(res, 400, {ok: false, error: e.message}); }
    log('Сервер шинэчлэгдлээ:', R.from, '→', R.to, R.npm ? '(npm install хийсэн)' : '');
    send(res, 200, Object.assign({ok: true}, R));
    setTimeout(async () => { SHUTTING = true; ST.exit = {at: Date.now(), why: `шинэчлэгдсэн: ${R.from} → ${R.to}`}; try{ csFlush(); await backupNow(false); writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); }, 1200);
    return;
  }
  if(p === '/api/env' && req.method === 'POST'){
    let b; try{ b = JSON.parse(await readBody(req)); }catch(e){ return send(res, 400, {ok: false}); }
    const ALLOW = {TD_API_KEY: /^[A-Za-z0-9]{8,80}$/, TG_TOKEN: /^\d{5,15}:[A-Za-z0-9_-]{20,80}$/, CHART_SYMBOL: /^[A-Z0-9]{2,10}\/[A-Z0-9]{2,10}$/, CHART_INTERVAL: /^(1min|5min|15min|30min|45min|1h|2h|4h|1day)$/, CREDIT_CAP: /^\d{2,5}$/, REPORT_HOUR: /^([01]?\d|2[0-3])$/, ALARM_EVERY_MIN: /^\d{1,3}$/, HISTORY_TEST_INTERVALS: /^(15min|30min|1h|2h|4h|1day)(,(15min|30min|1h|2h|4h|1day)){0,4}$/};
    const vals = {}, bad = [];
    Object.keys(ALLOW).forEach(k => { const v = b[k] == null ? '' : String(b[k]).trim(); if(!v) return; if(ALLOW[k].test(v)) vals[k] = v; else bad.push(k); });
    if(bad.length) return send(res, 400, {ok: false, error: 'Буруу утга: ' + bad.join(', ')});
    if(!Object.keys(vals).length) return send(res, 400, {ok: false, error: 'Өөрчлөх утга алга'});
    if(vals.TG_TOKEN && vals.TG_TOKEN !== CFG.tgToken){ vals.TG_CHAT = ''; ST.tgOffset = 0; stSave(); }
    envSet(vals); log('Тохиргоо өөрчлөгдлөө:', Object.keys(vals).join(', '));
    send(res, 200, {ok: true, restart: true});
    setTimeout(async () => { SHUTTING = true; ST.exit = {at: Date.now(), why: 'тохиргоо өөрчлөгдсөн'}; try{ csFlush(); await backupNow(false); writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); }, 800);
    return;
  }
  if(p === '/api/restart' && req.method === 'POST'){ station.restart('/api/restart'); return send(res, 200, {ok: true}); }
  return send(res, 404, {ok: false});
}
const LOGIN_HTML = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Station</title><body style="background:#131722;color:#EEF1F6;font-family:system-ui;padding:24px"><h3>Нууц үг хэрэгтэй</h3><form method="get" action="/status"><input name="t" type="password" placeholder="STATION_TOKEN" style="width:100%;max-width:360px;height:40px;border-radius:8px;border:1px solid #2F3440;background:#1B2130;color:#fff;padding:0 10px"><br><br><button style="height:40px;padding:0 18px;border-radius:8px;border:0;background:#E2B04A;color:#131722;font-weight:600">Нэвтрэх</button></form></body>`;
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'})[c]);
async function statusHtml(){
  const txt = await reportText(true), sets = csList();
  return `<!doctype html><html lang="mn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="120"><title>Станц</title>
<style>:root{--bg:#131722;--card:#1B2130;--line:#2F3440;--tx:#EEF1F6;--mut:#8A909C;--gold:#E2B04A}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:760px;margin:0 auto;padding:16px}
h1{font-size:19px;margin:4px 0 12px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin:0 0 12px}pre{white-space:pre-wrap;margin:0;font:14px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}
a.b,button{display:inline-block;height:38px;line-height:38px;padding:0 14px;border-radius:8px;border:0;background:var(--gold);color:#131722;font-weight:600;text-decoration:none;margin:4px 6px 4px 0;font-size:14px;cursor:pointer}
img{width:100%;border-radius:8px;border:1px solid var(--line)}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:4px 6px;border-bottom:1px solid var(--line);text-align:left}small{color:var(--mut)}</style></head>
<body><main><h1>🖥 Market Pattern · Станц</h1>
${!CFG.tgToken ? `<div class="card"><b>Telegram холбогдоогүй</b><br><small>Доорх «Тохиргоо» хэсэгт бот token-оо оруулна уу.</small></div>` : !CFG.tgChat ? `<div class="card" style="border-color:var(--gold)"><b>Telegram-аа холбох</b><br>Ботдоо дараах кодыг бичиж илгээнэ үү:<div style="font:600 30px/1.4 ui-monospace,monospace;letter-spacing:6px;color:var(--gold);margin:6px 0">${PAIR_CODE}</div><small>Код сервер дахин асах бүрт солигдоно.</small></div>` : ''}
<div class="card"><pre>${esc(txt)}</pre></div>
<div class="card"><a class="b" href="/">Апп нээх</a><a class="b" href="/api/backup" download="station-latest.json">💾 Нөөц татах</a><button onclick="fetch('/api/restart',{method:'POST'}).then(()=>alert('Дахин ачаалж байна'))">🔄 Станцыг дахин ачаалах</button></div>
<div class="card"><b>Апп шинэчлэх</b> <small>(Claude-оос авсан market-pattern-dashboard_NN.html)</small><br><br><input type="file" id="up" accept=".html,text/html" style="color:#EEF1F6;max-width:100%"><br><button onclick="(async()=>{const f=document.getElementById('up').files[0];if(!f)return alert('Файлаа сонгоно уу');const r=await fetch('/api/app',{method:'POST',headers:{'Content-Type':'text/html'},body:await f.text()});const j=await r.json().catch(()=>({}));alert(j.ok?('✓ '+(j.ver||'')+' суулаа — станц 10 секундэд дахин ачаалагдана'):('✕ '+(j.error||r.status)))})()">⬆ Суулгах</button></div>
<div class="card"><b>Сервер шинэчлэх</b> <small>(Claude-оос авсан mp-server.zip — апп ч хамт шинэчлэгдэнэ; SSH хэрэггүй)</small><br><br><input type="file" id="upz" accept=".zip,application/zip" style="color:#EEF1F6;max-width:100%"><br><button onclick="(async()=>{const f=document.getElementById('upz').files[0];if(!f)return alert('mp-server.zip-ээ сонгоно уу');this.disabled=true;this.textContent='⏳ Шалгаж, суулгаж байна…';const r=await fetch('/api/update',{method:'POST',headers:{'Content-Type':'application/zip'},body:f});const j=await r.json().catch(()=>({}));if(j.ok){alert('✓ '+j.from+' → '+j.to+(j.app?' (апп v'+j.app+')':'')+' суулаа. Сервер 1 минутын дотор шинэ хувилбараар асна.');setTimeout(()=>location.reload(),60000)}else{alert('✕ '+(j.error||r.status));this.disabled=false;this.textContent='⬆ Сервер шинэчлэх'}})()">⬆ Сервер шинэчлэх</button></div>
<div class="card"><b>Станцын дэлгэц</b> <small>(дарахад шинэчлэгдэнэ)</small><br><br><img id="sh" src="/api/shot?ts=${Date.now()}" alt="" onclick="this.src='/api/shot?ts='+Date.now()"></div>
<div class="card"><pre>${esc(histText())}</pre><br><button onclick="fetch('/api/histtest',{method:'POST'}).then(r=>alert(r.ok?'Түүхэн тест эхэллээ — дүн Telegram-аар ирнэ':'Аль хэдийн явж байна'))">🧪 Урт түүхээр тест хийх</button></div>
<div class="card"><b>Хуримтлагдсан лаа</b><table><tr><th>Хослол</th><th>Цаг</th><th>Лаа</th><th>Хугацаа</th><th></th></tr>${sets.map(x => `<tr><td>${esc(x.symbol)}</td><td>${esc(x.interval)}</td><td>${x.n}</td><td><small>${esc((x.from || '').slice(0, 10))} → ${esc((x.to || '').slice(0, 10))}</small></td><td><a href="/api/candles?symbol=${encodeURIComponent(x.symbol || '')}&interval=${encodeURIComponent(x.interval || '')}&format=csv">CSV</a></td></tr>`).join('') || '<tr><td colspan="5"><small>одоогоор алга</small></td></tr>'}</table></div>
<div class="card"><details><summary><b>⚙ Тохиргоо</b> <small>(хоосон талбар өөрчлөгдөхгүй)</small></summary><br>
<form id="envf" onsubmit="event.preventDefault();(async()=>{const o={};new FormData(this).forEach((v,k)=>{if(String(v).trim())o[k]=String(v).trim()});const r=await fetch('/api/env',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});const j=await r.json().catch(()=>({}));if(j.ok){alert('✓ Хадгаллаа — сервер 30 секундэд дахин асна');setTimeout(()=>location.reload(),30000)}else alert('✕ '+(j.error||r.status))})()">
${[['TD_API_KEY', 'Twelve Data API түлхүүр', CFG.tdKey ? '•••• ' + CFG.tdKey.slice(-4) : 'хоосон'], ['TG_TOKEN', 'Telegram бот token', CFG.tgToken ? '•••• ' + CFG.tgToken.slice(-4) : 'хоосон'], ['CHART_SYMBOL', 'Үндсэн хослол', CFG.sym], ['CHART_INTERVAL', 'Цаг (15min, 1h…)', CFG.iv], ['CREDIT_CAP', 'Өдрийн кредитийн хязгаар', CFG.creditCap], ['ALARM_EVERY_MIN', 'Сэрүүлэг шалгах (мин)', CFG.alarmEvery], ['REPORT_HOUR', 'Тайлангийн цаг (0–23)', CFG.reportHour]].map(([k, l, ph]) => `<label style="display:block;margin:0 0 8px"><small>${l}</small><br><input name="${k}" placeholder="${esc(ph)}" autocomplete="off" style="width:100%;height:38px;border-radius:8px;border:1px solid var(--line);background:#131722;color:var(--tx);padding:0 10px;box-sizing:border-box"></label>`).join('')}
<button type="submit">💾 Хадгалаад дахин асаах</button></form></details></div>
<small>${VERSION} · ${esc(os.hostname())}</small></main></body></html>`;
}

// ---------------------------------------------------------------- check mode
async function check(){
  let ok = true; const say = (good, t) => { console.log((good ? '  ✓ ' : '  ✕ ') + t); if(!good) ok = false; };
  console.log('Тохиргоог шалгаж байна…');
  say(fs.existsSync(ENV_FILE), '.env файл');
  say(!!CFG.tdKey, 'TD_API_KEY бичигдсэн');
  say(CFG.token.length >= 16, 'STATION_TOKEN (16+ тэмдэгт)');
  say(fs.existsSync(APP_FILE), 'app/index.html');
  try{ require.resolve('playwright'); say(true, 'playwright суусан'); }catch(e){ say(false, 'playwright суугаагүй — install.bat-ийг ажиллуулна уу'); }
  if(CFG.tdKey){ try{ const r = await fetch(`${CFG.tdBase}/api_usage?apikey=${encodeURIComponent(CFG.tdKey)}`); const j = await r.json(); say(j && j.status !== 'error', 'Twelve Data түлхүүр ' + (j && j.status !== 'error' ? `ажиллаж байна (өнөөдөр ${j.daily_usage}/${j.plan_daily_limit})` : '— ' + (j && j.message))); }catch(e){ say(false, 'Twelve Data-д холбогдсонгүй: ' + e.message); } }
  if(CFG.tgToken){ try{ const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/getMe`); const j = await r.json(); say(j && j.ok, 'Telegram бот ' + (j && j.ok ? '@' + j.result.username : '— token буруу')); }catch(e){ say(false, 'Telegram-д холбогдсонгүй: ' + e.message); } }
  else console.log('  · TG_TOKEN хоосон — Telegram ашиглахгүй');
  if(CFG.tgToken && !CFG.tgChat) console.log('  · TG_CHAT хоосон — серверийг асаагаад ботод дурын мессеж бичвэл chat ID-гаа хариу авна');
  console.log(ok ? (process.platform === 'win32' ? '\nБүгд зөв. Одоо test-run.bat-ээр туршиж үзээрэй.' : '\nБүгд зөв. Одоо: sudo mpctl restart') : '\nДээрх ✕ зүйлсийг засна уу.');
  return ok;
}

// ---------------------------------------------------------------- start / stop reasons
// why did the previous run end? written on every graceful stop; missing = it was killed
function exitMark(why){ try{ ST.exit = {at: Date.now(), why}; writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} }
function bootNotice(){
  const E = ST.exit, now = Date.now(), up = os.uptime(), verChanged = ST.ver && ST.ver !== VERSION;
  let why = E && now - E.at < 30*60e3 ? E.why : up < 600 ? 'сервер машин дахин ачаалагдсан' : verChanged ? `шинэчлэгдсэн: ${ST.ver} → ${VERSION}` : ST_FRESH ? 'анх удаа асав' : !ST.ver ? `шинэчлэгдсэн → ${VERSION}` : 'гэнэт зогссон (санах ой дүүрсэн эсвэл алдаа — /status-ийн логийг харна)';
  ST.ver = VERSION;
  if(up < 600 && E && /SIGTERM/.test(E.why)) why = 'сервер машин дахин ачаалагдсан';
  delete ST.exit;
  // several restarts in a row (e.g. Ubuntu's morning security updates restart the service once per package) → one message
  const B = ST.boot = ST.boot || {at: 0, sup: 0, why: []};
  if(now - B.at < 10*60e3 && !/шинэчлэгдсэн/.test(why)){ B.sup++;   // an update is always reported at once
     B.why.push(why); B.why = B.why.slice(-6); stSave(); }
  else{ B.at = now; B.sup = 0; B.why = []; stSave(); tgSend(`🟢 Сервер асаалаа (${os.hostname()}) — өмнөх зогсолт: ${why}. /status гэж бичвэл байдлыг хэлнэ.`); }
  setTimeout(() => { const b = ST.boot; if(b && b.sup > 0){ const n = b.sup, w = Array.from(new Set(b.why)); b.sup = 0; b.why = []; b.at = Date.now(); stSave();
    tgSend(`ℹ Сүүлийн хэдэн минутад сервер дахиад ${n} удаа дахин асав (${w.join('; ')}). Одоо 10 минут тогтвортой ажиллаж байна — өгөгдөл алдагдаагүй.`); } }, 10*60e3);
}
const SIG_WHY = {SIGTERM: 'систем зогсоосон (SIGTERM) — ихэвчлэн Ubuntu-гийн автомат аюулгүй байдлын шинэчлэл эсвэл mpctl restart', SIGINT: 'гараар зогсоосон (SIGINT)'};

// ---------------------------------------------------------------- main
async function main(){
  log(`${VERSION} эхэлж байна · ${os.hostname()} · Node ${process.version}`);
  const srv = http.createServer((req, res) => { handle(req, res).catch(e => { log('HTTP алдаа:', e.message); try{ send(res, 500, {ok: false}); }catch(x){} }); });
  await new Promise((ok, no) => { srv.once('error', no); srv.listen(CFG.port, CFG.host, ok); }).catch(e => { log(`❌ ${CFG.port} порт эзэлсэн эсвэл нээгдсэнгүй: ${e.message}. Сервер өөр цонхонд ажиллаж байгаа эсэхийг шалгана уу.`); process.exit(3); });
  log(`✓ HTTP: http://${CFG.host}:${CFG.port}/`);
  await station.start();
  bootNotice();
  tgPoll();

  // health check: the page must answer; otherwise restart the browser
  setInterval(async () => {
    if(!station.alive || station.starting) return;
    const p = await station.eval(() => window.__MP && window.__MP.ping());
    if(p && p.ok){ station.fails = 0; station.last = p; return; }
    station.miss = (station.miss || 0) + 1;
    if(station.miss >= 3){ station.miss = 0; station.schedule('хуудас хариу өгөхгүй байна'); }
  }, 60e3);
  // memory guard + daily fresh reload at 04:30 (long-running pages slowly grow)
  setInterval(async () => {
    if(!station.alive || station.starting || histTestBusy) return;
    const d = new Date();
    if(d.getHours() === 4 && d.getMinutes() >= 30 && d.getMinutes() < 35 && Date.now() - station.since > 3*36e5){ await backupNow(false); return station.restart('өдөр бүрийн шинэчлэл'); }
    try{ const cdp = await station.page.context().newCDPSession(station.page); const m = await cdp.send('Performance.getMetrics').catch(() => null); await cdp.detach().catch(() => {});
      const heap = m && (m.metrics.find(x => x.name === 'JSHeapUsedSize') || {}).value; if(heap && heap > 1.5e9){ await backupNow(false); station.restart(`санах ой ${Math.round(heap/1e6)} MB`); } }catch(e){}
  }, 5*60e3);
  // backups every 30 min (+ a dated copy once a day), candle flush every 30 s
  setInterval(() => { backupNow(!fs.existsSync(path.join(DIRS.backups, `station-${ymd()}.json`))); }, 30*60e3);
  setTimeout(() => backupNow(!fs.existsSync(path.join(DIRS.backups, `station-${ymd()}.json`))), 3*60e3);
  setInterval(csFlush, 30e3);
  // price alarms
  setInterval(() => { alarmsRun().catch(e => log('Сэрүүлэг шалгахад алдаа:', e.message)); }, CFG.alarmEvery*60e3);
  // long history: first download a few minutes after start, then every night at 01:30;
  // the long history test runs every Sunday 03:00 (markets closed, station idle)
  if(CFG.history){
    setTimeout(() => { tdPrime().catch(() => {}).then(() => hist().run('эхний таталт')).then(() => trendCompute('эхний таталт')).catch(e => log('Түүх татахад алдаа:', e.message)); }, num(ENV.HIST_START_DELAY_S, 240)*1000);
    setInterval(() => { const d = new Date();
      if(d.getHours() === 1 && d.getMinutes() >= 30 && d.getMinutes() < 31) tdPrime().catch(() => {}).then(() => hist().run('шөнийн шинэчлэл')).then(() => trendCompute('шөнийн шинэчлэл')).catch(e => log('Түүх татахад алдаа:', e.message));
      // Sunday 10:00 — the 01:30 update has brought Friday's close; positions apply from Monday's open (05:00 Ulaanbaatar)
      if(CFG.trendOn && d.getDay() === 0 && d.getHours() >= 10 && ST.trendWeek !== ymd(d)) trendWeekly().catch(e => log('Тренд тайлангийн алдаа:', e.message));
      if(d.getDay() === 0 && d.getHours() === 3 && d.getMinutes() < 1 && Date.now() - (ST.lastHistTest || 0) > 20*36e5) histTest('долоо хоног бүрийн', histPick('')).catch(e => log('Түүхэн тестийн алдаа:', e.message));
    }, 60e3);
  }
  // daily report
  setInterval(async () => {
    const d = new Date(), key = ymd(d);
    if(d.getHours() === CFG.reportHour && ST.lastReport !== key){
      ST.lastReport = key; tgSend(await reportText(true));
      if(CFG.backupTg && await backupNow(true)) backupToTelegram('💾 Өдрийн нөөц');
      const S = await station.eval(() => window.__MP.summary()); if(S) ST.lastJr = {day: key, n: S.journal.total}; stSave();
    }
  }, 60e3);
  // a new app/index.html (update) → reload the station with it
  let wt = null; fs.watchFile(APP_FILE, {interval: 5000}, () => { clearTimeout(wt); wt = setTimeout(() => { log('app/index.html шинэчлэгдсэн'); tgSend('⬆ Апп шинэчлэгдлээ — станц шинэ хувилбараар дахин ачаалагдаж байна.'); station.restart('апп шинэчлэгдсэн'); }, 4000); });
  // log housekeeping
  setInterval(() => pruneDir(DIRS.logs, /^server-.*\.log$/, 14), 6*36e5); pruneDir(DIRS.logs, /^server-.*\.log$/, 14);

  const bye = async sig => { if(SHUTTING) return; SHUTTING = true; log('Зогсож байна (' + sig + ')'); if(!ST.exit || Date.now() - ST.exit.at > 60e3) ST.exit = {at: Date.now(), why: SIG_WHY[sig] || sig};
    try{ csFlush(); await backupNow(false); }catch(e){} try{ writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); };
  process.on('SIGINT', () => bye('SIGINT')); process.on('SIGTERM', () => bye('SIGTERM'));
  process.on('unhandledRejection', e => logThrottled('unh', 'unhandledRejection: ' + String(e && e.message || e)));
  process.on('uncaughtException', e => { const m = String(e && e.stack || e).slice(0, 600); log('❌ Барьж аваагүй алдаа:', m); exitMark('программын алдаа: ' + String(e && e.message || e).slice(0, 120)); setTimeout(() => process.exit(1), 300); });
}
