# v84 / mp-server 1.11 — on top of build19 (v83 / 1.10.2)
import subprocess, re
A='/tmp/claude-0/an/'
subprocess.run(['python3', A+'build19.py'], check=True)
VERSION='mp-server 1.11'
# ---------------- server ----------------
p='/home/claude/mp-server/server.js'; s=open(p).read()
def R(a, b, cnt=1):
    global s
    assert s.count(a)==cnt, (s.count(a), a[:90]); s=s.replace(a, b)
R("const VERSION = 'mp-server 1.10.2';", "const VERSION = '"+VERSION+"';")
R("  port: num(ENV.PORT, 8787), host: ENV.HOST || '127.0.0.1',", "  port: num(ENV.PORT, 8787), host: ENV.HOST || '127.0.0.1', tz: ENV.STATION_TZ || 'Asia/Ulaanbaatar',")
# the station browser runs in the owner's time zone (dates, «today», times written on pictures)
R("headless: true, viewport: {width: 1280, height: 900}, deviceScaleFactor: 1, locale: 'mn-MN',", "headless: true, viewport: {width: 1280, height: 900}, deviceScaleFactor: 1, locale: 'mn-MN', timezoneId: CFG.tz,")
R("const TREND_FILE = path.join(DATA, 'trend.json')", open(A+'calglue.js.src').read()+"const TREND_FILE = path.join(DATA, 'trend.json')")
R("  if(p === '/api/trend'){", "  if(p === '/api/cal'){ const C = ST.cal || {}; return send(res, 200, {ok: !!C.at, at: C.at || 0, err: C.err || null, ev: (C.ev || []).filter(e => e.ts > Date.now() - 864e5)}); }\n  if(p === '/api/trend'){")
# coach signals can be muted from Telegram (the app's own setting lives on the station)
R("  const text = `🔔 ${title}\\n${body}`;", "  if(ST.coachMute && /^🎓/.test(title)){ log('Мэдэгдэл (Багш чимээгүй):', title); return; }\n  const text = `🔔 ${title}\\n${body}`;")
R("  else if(cmd === '/shot'){", """  else if(cmd === '/cal'){ if(/now|шинэ/i.test(arg)) await calFetch('Telegram'); tgSend(calText()); }
  else if(cmd === '/coach'){ const a = String(arg || '').trim().toLowerCase();
    if(a === 'off'){ ST.coachMute = true; stSave(); tgSend('🔕 Багшийн дохио Telegram-д ирэхгүй (апп дотор бүртгэлээ үргэлжлүүлнэ). Буцааж: /coach on'); }
    else if(a === 'on'){ ST.coachMute = false; stSave(); tgSend('🔔 Багшийн дохио асаалттай.'); }
    else { const t = await station.eval(() => window.__MP.coText && window.__MP.coText()); tgSend((t || 'Станц хариу өгөхгүй байна (апп v84-өөс хуучин уу?).') + (ST.coachMute ? '\\n\\n🔕 Telegram дохио чимээгүй байна — /coach on' : '\\n\\n/coach off — дохиог түр хаах')); } }
  else if(cmd === '/shot'){""")
R("\\n/swing — swing систем (3 шүргэлт): тест, дохио, шалгах хуудас (/swing XAU 4h · 1h · d)", "\\n/swing — swing систем (3 шүргэлт): тест, дохио, шалгах хуудас (/swing XAU 4h · 1h · d)\\n/coach — Багшийн дадлагын оролтууд (/coach off · on — дохио)\\n/cal — ойрын чухал мэдээний хуанли")
R("  setInterval(csFlush, 30e3);", "  setInterval(csFlush, 30e3);\n  // v1.11 economic calendar: soon after start, then every 4 h\n  setTimeout(() => calFetch('эхлэл'), 90e3); setInterval(() => calFetch('4 цаг тутам'), 4*36e5);")
open(p,'w').write(s)
# ---------------- app ----------------
p='/home/claude/w.html'; s=open(p).read()
s=s.replace("'v83'", "'v84'").replace('>v83<', '>v84<').replace('v83 · </span>', 'v84 · </span>')
anchor="  document.addEventListener('toggle', ev => { const d = ev.target; if(d && d.matches && d.matches('details.vsec') && d.open && d.querySelector('.tr-box')) trLoad(false); }, true);\n"
R(anchor, anchor+open(A+'fab.js.src').read())
R('        <div id="eudDrawOverlay" style="position:absolute; inset:0; display:none; touch-action:none; cursor:crosshair;"></div>', open(A+'fab.html').read()+'        <div id="eudDrawOverlay" style="position:absolute; inset:0; display:none; touch-action:none; cursor:crosshair;"></div>')
R('  <div class="eud-ivsheet" id="eudWhySheet" style="display:none; z-index:80;">', open(A+'fabsheet.html').read()+'  <div class="eud-ivsheet" id="eudWhySheet" style="display:none; z-index:80;">')
R("  .tr-v{font-weight:600; font-size:13.5px;}", open(A+'fab.css').read()+"  .tr-v{font-weight:600; font-size:13.5px;}")
R("    if(swActivate(target)) return;\n    if(coActivate(target)) return;\n", "    if(fabActivate(target)) return;\n    if(swActivate(target)) return;\n    if(coActivate(target)) return;\n")
R("    try{ coTick(); if(state.activeTab === 'coach') coRender(); }catch(e){ console.error(e); }", "    try{ coTick(); if(state.activeTab === 'coach' || state.fab === 'coach') coRender(); }catch(e){ console.error(e); }\n    try{ fabRender(); }catch(e){ console.error(e); }")
# the chosen analogue stays across a refresh / interval / symbol change (v84)
R("      state.lastFetchAt = Date.now();\n      state.selectedMatch = null;\n      renderAll();", "      state.lastFetchAt = Date.now();\n      renderAll();")
R("      if(el) el.addEventListener('change', () => {\n        state.selectedMatch = null;\n        if(id === 'eudInterval'){", "      if(el) el.addEventListener('change', () => {\n        if(id === 'eudInterval'){")
# the coach looks at every scanned series too
R("          try{ entRecordAll(E.entFull, sym, IV, c); }catch(e){}", "          try{ entRecordAll(E.entFull, sym, IV, c); }catch(e){}\n          try{ coTickFor(c, sym, IV); }catch(e){ console.error(e); }")
R("      stopStation(){ fwdStop(); return true; },", "      stopStation(){ fwdStop(); return true; },\n      coText(){ try{ return coTgText(); }catch(e){ return '🎓 Багш: алдаа — ' + String(e && e.message || e); } },")
# Anticipation · book: its own record on the 4/4 signal, and every result with a picture
R("      alertNotify(`${sym} · ${lbl} ${R.stage}/4${R.stage === 4 && !R.chased ? ' — 4 нөхцөл бүрдсэн, шалгаж үзээрэй' : ''}`, msg, ",
  "      alertNotify(`${sym} · ${lbl} ${R.stage}/4${R.stage === 4 && !R.chased ? ' — 4 нөхцөл бүрдсэн, шалгаж үзээрэй' : ''}`, msg + (R.stage === 4 && entMk(R) === 'scenN' ? '\\n' + jrMethodLine('scenN') : ''), ")
R("      if(res){ const cR = costR(x.sym, x.fill, x.sl); x.res = res; x.Rg = +R.toFixed(2); x.cR = +cR.toFixed(3); x.R = +(R - cR).toFixed(2); x.t1 = candles[Math.min(k, n - 1)].time; changed++; }   // R is NET of costs\n    });\n    if(changed) jrSave();",
  "      if(res){ const cR = costR(x.sym, x.fill, x.sl); x.res = res; x.Rg = +R.toFixed(2); x.cR = +cR.toFixed(3); x.R = +(R - cR).toFixed(2); x.t1 = candles[Math.min(k, n - 1)].time; changed++; if(JR_NTF[x.plan] && !x.shadow) done.push(x); }   // R is NET of costs\n    });\n    if(changed) jrSave();\n    done.forEach(x => { try{ jrNotifyDone(x, candles); }catch(e){ console.error(e); } });")
R("    const J = jrLoad(), n = candles.length; let changed = 0;\n    if(n < 3) return 0;", "    const J = jrLoad(), n = candles.length, done = []; let changed = 0;\n    if(n < 3) return 0;")
R("  function jrResolve(candles, sym, iv){", r"""  // v84: methods whose every result goes to Telegram with a picture (being watched on the record)
  const JR_NTF = {scenN: 'Anticipation · номын'};
  function jrMethodLine(k){ const st = methodStatus(k); return `📒 Бүртгэл (${JR_NTF[k] || k}): ${st.n ? `${st.n} арилжаа · ялалт ${Math.round(st.wr*100)}% · дундаж ${st.exp >= 0 ? '+' : ''}${st.exp.toFixed(2)}R` : 'хаагдсан арилжаа алга'}${st.open ? ` · нээлттэй ${st.open}` : ''}${st.n < PROOF_MIN ? ` · ${st.n}/${PROOF_MIN} хэмжиж байна` : ''}`; }
  function jrNotifyDone(x, c){
    const d = priceDecimals(x.fill), f = v => (+v).toFixed(d), win = x.res === 'win', what = x.res === 'loss' ? 'SL ✕' : x.res === 'exp' ? 'хугацаа дууссан ⌛' : x.part === 'tp2' ? 'TP2 ✓' : x.part === 'tp1' ? 'TP1 ✓ (½), үлдсэн нь орох үнэ дээр' : 'TP ✓';
    const ke = c.findIndex(b => b.time > x.t1), cc = ke > 40 ? c.slice(0, ke) : c;
    try{ sigImgSet(cc, {sym: x.sym, tf: ivLabel(x.iv), name: `${JR_NTF[x.plan] || x.planName} · үр дүн`, note: what, dir: x.dir, entry: x.fill, sl: x.sl, tp1: x.tp1, tp2: x.tp2, lines: []}); }catch(e){}
    alertNotify(`📒 ${x.sym} ${ivLabel(x.iv)} · ${JR_NTF[x.plan] || x.planName} — ${what} ${x.R >= 0 ? '+' : ''}${(+x.R).toFixed(2)}R`,
      `${x.dir > 0 ? 'LONG' : 'SHORT'} ${f(x.fill)} · SL ${f(x.sl)} · TP1 ${f(x.tp1)}${x.tp2 != null ? ' · TP2 ' + f(x.tp2) : ''} (${String(x.t0).slice(5, 16)} → ${String(x.t1 || '').slice(5, 16)} UTC, ${x.bars} лаа). Зардал хассан цэвэр дүн.\n${jrMethodLine(x.plan)}`,
      win ? '#34D399' : x.res === 'loss' ? '#F87171' : '#8A909C');
  }
  function jrResolve(candles, sym, iv){""")
open(p,'w').write(s)
print('built', VERSION, 'app v84')
