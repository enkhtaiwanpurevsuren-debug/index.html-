A='/tmp/claude-0/an/'
VERSION='mp-server 1.10.2'
s=open(A+'server182.js').read()
t='return {run, text, lotsFor, minAccount, verdict};'
assert s.count(t)==1; s=s.replace(t,'return {run, text, lotsFor, minAccount, verdict, spreadOf, CONTRACT};')
sw=open(A+'sw.js.src').read().replace("if(typeof module !== 'undefined') module.exports = SW;\n","")
glue=open(A+'swglue.js.src').read()
for a,b in [("function sw1h(sym){","function sw1h(sym, lim){"),("a = SW.fromTd(Hh.bars(sym, '1h', 0))","a = SW.fromTd(Hh.bars(sym, '1h', lim || 0))"),
            ("let F; try{ F = sw1h(sym); }catch(e){ continue; } if(F.length < 600) continue;","let F; try{ F = sw1h(sym, 9000); }catch(e){ continue; } if(F.length < 600) continue;"),
            ("let F; try{ F = sw1h(L.sym); }catch(e){ continue; }","let F; try{ F = sw1h(L.sym, 5000); }catch(e){ continue; }")]:
  assert glue.count(a)==1, a; glue=glue.replace(a,b)
anchor="const TREND_FILE = path.join(DATA, 'trend.json')"
assert s.count(anchor)==1
s=s.replace(anchor, "// ---------------------------------------------------------------- v1.9 swing system («3 шүргэлт»)\n"+sw+glue+"\n"+anchor)
for a,b in [(".then(() => trendCompute('эхний таталт')).catch(", ".then(() => trendCompute('эхний таталт')).then(() => swingCompute('эхний таталт')).then(() => swingTick()).catch("),
            (".then(() => trendCompute('шөнийн шинэчлэл')).catch(", ".then(() => trendCompute('шөнийн шинэчлэл')).then(() => swingCompute('шөнийн шинэчлэл')).catch(")]:
  assert s.count(a)==1; s=s.replace(a,b)
old="      if(CFG.trendOn && d.getDay() === 0 && d.getHours() >= 10 && ST.trendWeek !== ymd(d)) trendWeekly().catch(e => log('Тренд тайлангийн алдаа:', e.message));"
assert s.count(old)==1
s=s.replace(old, old+"\n      // v1.9 swing system: a few minutes after every hour (1H bars close every hour, 4H at 00/04/08/12/16/20 UTC)\n      if(d.getMinutes() === 7 && !ST.swOff) swingTick().catch(e => log('Swing шалгалтын алдаа:', e.message));\n      // v1.9.2: a station that has never computed the swing test does it once its history is ready\n      if(d.getMinutes() === 20 && !swingGet() && !swingBusy && hist() && !hist().busy) swingCompute('анхны тооцоо').then(() => swingTick()).catch(e => log('Swing тестийн алдаа:', e.message));")
old="  if(p === '/api/trend'){"
assert s.count(old)==1; s=s.replace(old, open(A+'swapi.js.src').read()+old,1)
old="  else if(cmd === '/shot'){"
assert s.count(old)==1; s=s.replace(old, open(A+'swtg.js.src').read()+old)
a="\\n/trend — тренд системийн одоогийн байршил (/trend 5000 — дансны хэмжээ тохируулах)"
assert s.count(a)==1
s=s.replace(a, a+"\\n/swing — swing систем (3 шүргэлт): тест, дохио, шалгах хуудас (/swing XAU 4h · 1h · d)")
assert s.count("const VERSION = 'mp-server 1.8.2';")==1
s=s.replace("const VERSION = 'mp-server 1.8.2';","const VERSION = '"+VERSION+"';")
open('/home/claude/mp-server/server.js','w').write(s)
# ---------- app ----------
s=open('/home/claude/w82pre.html').read().replace("'v82'", "'v83'").replace('>v82<', '>v83<').replace('v82 · </span>', 'v83 · </span>')
js=open(A+'swapp.js.src').read()+open(A+'coach.js.src').read()
anchor="  document.addEventListener('toggle', ev => { const d = ev.target; if(d && d.matches && d.matches('details.vsec') && d.open && d.querySelector('.tr-box')) trLoad(false); }, true);\n"
assert s.count(anchor)==1; s=s.replace(anchor, anchor+js)
for a,f in [('    <button type="button" class="eud-tab" data-tab="forecast" title="Ижил төстэй түүхэн загварууд ба таамаг">','cobtn.html'),
            ('    <button type="button" class="eud-tab" data-tab="dow" title="Dow онолын шинжилгээ">','swbtn.html'),
            ('    <div class="eud-tabpanel eud-panel-box" data-tab="trade" style="display:none;">','copan.html'),
            ('    <div class="eud-tabpanel eud-panel-box" data-tab="trade" style="display:none;">','swpan.html'),
            ("  .tr-v{font-weight:600; font-size:13.5px;}",'cocss.css'),
            ("  .tr-v{font-weight:600; font-size:13.5px;}",'swcss.css')]:
  assert s.count(a)==1; s=s.replace(a, open(A+f).read()+a)
old_sync="    setTimeout(() => { try{ drawVerdictCharts(); }catch(e){} try{ drawFcCharts(); }catch(e){} }, 0);\n  }"
assert s.count(old_sync)==1
s=s.replace(old_sync, "    // v82/v83: the Swing and Coach panels fill themselves whenever they are shown (bar, menu sheet or code)\n    if(state.activeTab === 'swing') setTimeout(() => { try{ swLoad(false); }catch(e){ console.error(e); } }, 0);\n    if(state.activeTab === 'coach') setTimeout(() => { try{ coRender(); }catch(e){ console.error(e); } }, 0);\n"+old_sync)
# taps on phones arrive through handleActivate (the touchend handler cancels the click)
old_ha="  function handleActivate(target){\n    if(!target || !target.closest) return;\n"
assert s.count(old_ha)==1
s=s.replace(old_ha, old_ha+"    if(swActivate(target)) return;\n    if(coActivate(target)) return;\n")
# the coach follows every analysis: its practice entries and their SL/TP
old_ra="    try{ alertsCheck(); }catch(e){ console.error(e); }\n    syncLayerButtons();\n    syncTabs();\n  }"
assert s.count(old_ra)==1
s=s.replace(old_ra, "    try{ alertsCheck(); }catch(e){ console.error(e); }\n    try{ coTick(); if(state.activeTab === 'coach') coRender(); }catch(e){ console.error(e); }\n    syncLayerButtons();\n    syncTabs();\n  }")
open('/home/claude/w.html','w').write(s)
print('built', VERSION)
