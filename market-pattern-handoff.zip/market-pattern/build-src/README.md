# build-src (түүхэн лавлагаа)
v83–v84-ийг `server182.js` (сервер 1.8.2) ба `w82pre.html` (апп v82) дээр patch хийж угсарсан эх файлууд.
`build19.py` → 1.10.2 / v83, `build20.py` → 1.11 / v84. Скриптүүд `/tmp/claude-0/an/` замыг хатуу бичсэн.
Цаашид эдгээрийг ашиглахгүй — `mp-server/server.js` ба `mp-server/app/index.html`-г шууд засна.
