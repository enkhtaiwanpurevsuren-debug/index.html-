#!/usr/bin/env bash
# =====================================================================
#  Market Pattern сервер — Linux (Ubuntu 22.04/24.04, x86 эсвэл ARM)
#  суулгах / шинэчлэх скрипт. Oracle Cloud дээр:
#      unzip mp-server.zip && cd mp-server && sudo bash install.sh
#  Дахин ажиллуулахад .env болон data хавтас хэвээр үлдэж, зөвхөн
#  программ шинэчлэгдэнэ.
# =====================================================================
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Ингэж ажиллуулна уу:  sudo bash install.sh"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"
DST="${MP_DIR:-/opt/mp-server}"
BR="$DST/browsers"
say(){ printf '\n\033[1;33m==> %s\033[0m\n' "$*"; }
ok(){ printf '\033[1;32m✓ %s\033[0m\n' "$*"; }

# first boot: Ubuntu's own automatic updates may hold the package lock for a while
wait_apt(){ for i in $(seq 1 180); do if ! pgrep -x apt-get >/dev/null && ! pgrep -x apt >/dev/null && ! pgrep -x dpkg >/dev/null && ! pgrep -f '/usr/bin/unattended-upgrade( |$)' >/dev/null; then return 0; fi; [ "$i" = 1 ] && echo "Ubuntu шинэчлэл дуусахыг хүлээж байна…"; sleep 5; done; }
if [ -z "${SKIP_APT:-}" ]; then
  wait_apt
  say "1/7 Системийн багцууд"
  export DEBIAN_FRONTEND=noninteractive
  apt-get -o DPkg::Lock::Timeout=600 update -y
  apt-get -o DPkg::Lock::Timeout=600 install -y curl ca-certificates unzip nano
fi

say "2/7 Цагийн бүс → Asia/Ulaanbaatar (өдрийн тайлангийн цаг)"
timedatectl set-timezone Asia/Ulaanbaatar 2>/dev/null || ln -sf /usr/share/zoneinfo/Asia/Ulaanbaatar /etc/localtime || true

say "3/7 Node.js"
NODE_MAJ=$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)
if [ "${NODE_MAJ:-0}" -lt 20 ]; then
  wait_apt 2>/dev/null || true
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get -o DPkg::Lock::Timeout=600 install -y nodejs
fi
ok "Node $(node -v)"

say "4/7 Хэрэглэгч ба хавтас ($DST)"
id mp >/dev/null 2>&1 || useradd --system --create-home --home-dir /var/lib/mp --shell /usr/sbin/nologin mp
mkdir -p "$DST/app" "$DST/data"
for f in server.js hist.js lzma.js package.json config.example.env README.txt; do cp -f "$SRC/$f" "$DST/$f"; done
if [ -f "$DST/app/index.html" ] && ! cmp -s "$SRC/app/index.html" "$DST/app/index.html"; then cp -f "$DST/app/index.html" "$DST/app/index.prev.html"; fi
cp -f "$SRC/app/index.html" "$DST/app/index.html"
chown -R mp:mp "$DST"

say "5/7 Багц ба Chromium (3–10 мин)"
cd "$DST"
sudo -u mp -H env PLAYWRIGHT_BROWSERS_PATH="$BR" npm install --omit=dev --no-audit --no-fund
[ -n "${SKIP_APT:-}" ] || { wait_apt; env PLAYWRIGHT_BROWSERS_PATH="$BR" npx --yes playwright install-deps chromium; }
sudo -u mp -H env PLAYWRIGHT_BROWSERS_PATH="$BR" npx --yes playwright install chromium
ok "Chromium бэлэн"

say "6/7 Тохиргооны файл (.env)"
if [ ! -f "$DST/.env" ]; then sudo -u mp -H node server.js --init-env; fi
chown mp:mp "$DST/.env"; chmod 600 "$DST/.env"

say "7/7 Автомат эхлэлт (systemd) ба mpctl"
install -m 755 "$SRC/mpctl" /usr/local/bin/mpctl
if [ -z "${SKIP_SYSTEMD:-}" ]; then
  cat > /etc/systemd/system/mp-server.service <<UNIT
[Unit]
Description=Market Pattern station server
After=network-online.target
Wants=network-online.target

[Service]
User=mp
WorkingDirectory=$DST
Environment=PLAYWRIGHT_BROWSERS_PATH=$BR
Environment=NODE_ENV=production
ExecStart=$(command -v node) server.js
Restart=always
RestartSec=20
# stop = SIGTERM to the server only; it closes Chromium itself and saves its state first
KillMode=mixed
TimeoutStopSec=45
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable mp-server >/dev/null
fi

if [ -z "${SKIP_APT:-}" ] && ! command -v tailscale >/dev/null 2>&1; then
  say "Tailscale суулгаж байна"
  curl -fsSL https://tailscale.com/install.sh | sh
fi

echo
if [ -n "${SKIP_START:-}" ]; then
  ok "Суулгалт дууслаа (эхлүүлэхийг дуудагч хийнэ)."
elif grep -qE '^TD_API_KEY=.+' "$DST/.env"; then
  [ -n "${SKIP_SYSTEMD:-}" ] || systemctl restart mp-server
  ok "Сервер (дахин) асаалаа.  Байдал: mpctl status  ·  Лог: mpctl logs"
else
  ok "Суулгалт дууслаа."
  echo "Дараагийн алхам:  sudo mpctl set TD_API_KEY ТАНЫ_ТҮЛХҮҮР   (эсвэл sudo mpctl edit)"
  echo "STATION_TOKEN: $(grep '^STATION_TOKEN=' "$DST/.env" | cut -d= -f2-)   ← үүнийг хадгалаарай"
fi
