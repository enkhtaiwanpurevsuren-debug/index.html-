'use strict';
// =====================================================================
//  LONG HISTORY from the Dukascopy public datafeed (free, years of data).
//
//  • Downloads one compressed file of 1-minute bid candles per day
//    (…/datafeed/XAUUSD/2024/00/15/BID_candles_min_1.bi5, month 0-based),
//    turns it into 15-minute and 1-hour candles and keeps them on disk
//    (data/history/<SYMBOL>/<year>.json). Only missing days are fetched,
//    politely: 2 requests at a time, retries with back-off.
//  • The file format is not officially documented, so nothing is assumed
//    blindly: the record layout (field order, int/float prices) is detected
//    from the candle invariants (low ≤ open/close ≤ high), and the price
//    scale + any time-zone offset are CALIBRATED against the Twelve Data
//    candles the station already stores. Until that check passes the data
//    is marked unverified and is not served to the app.
//  • Serves Twelve-Data-shaped JSON (newest first) so the app's own parser
//    reads it unchanged: 15min, 30min, 45min, 1h, 2h, 4h, 1day, 1week.
// =====================================================================
const fs = require('fs');
const path = require('path');
const {decompress} = require('./lzma');

const DAY = 864e5;
const SCALES = [1, 10, 100, 1e3, 1e4, 1e5, 1e6];
const DEFAULT_SCALE = s => /JPY/.test(s) ? 1e3 : /^(XAU|XAG|XPT|XPD)/.test(s) ? 1e3 : /^(BTC|ETH)/.test(s) ? 10 : 1e5;
const pad = n => String(n).padStart(2, '0');
const ymdUTC = d => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
const sleep = ms => new Promise(r => setTimeout(r, ms));

function makeHist(opt){
  const {dir, base, years, symbols, log, tdStore, onEvent} = opt;
  const pauseMs = opt.pauseMs != null ? opt.pauseMs : 250;
  fs.mkdirSync(dir, {recursive: true});
  const code = s => String(s).split(':')[0].replace(/[^A-Za-z0-9]/g, '').toUpperCase();   // XAU/USD → XAUUSD
  const sdir = s => path.join(dir, code(s));
  const H = {busy: false, prog: null, stop: false};

  // ---------- per-symbol state ----------
  const metaCache = new Map();
  function meta(s){
    if(metaCache.has(s)) return metaCache.get(s);
    let m = null; try{ m = JSON.parse(fs.readFileSync(path.join(sdir(s), 'meta.json'), 'utf8')); }catch(e){}
    m = Object.assign({symbol: s, code: code(s), layout: null, scale: null, shiftMin: 0, verified: false, verifyNote: '', days: {}, from: null, to: null, bars15: 0, fail: {}, lastErr: ''}, m || {});
    if(!m.fail || typeof m.fail !== 'object') m.fail = {};
    // v1.3: the Twelve Data candles this history is checked against are UTC now (before: Australia/Sydney
    // for forex/metals, which the calibration absorbed as a fixed shift of whole hours). Dukascopy is UTC,
    // so the shift is 0 — the next calibration (every start / every night) confirms it.
    if(m.tzv !== 2){ if(m.shiftMin){ log(`Түүх ${code(s)}: цагийн шилжилт ${m.shiftMin/60} цаг → 0 (Dukascopy UTC)`); try{ onEvent && onEvent(`🕐 ${code(s)}: урт түүх ${m.shiftMin/60} цагаар шилжсэн байсныг 0 болгож засав (Dukascopy UTC). Хуучин түүхэн тестийн дүнг /histtest-ээр шинэчилнэ үү.`); }catch(e){} } m.shiftMin = 0; m.tzv = 2; metaCache.set(s, m); try{ metaSave(s); }catch(e){} return m; }
    metaCache.set(s, m); return m;
  }
  function metaSave(s){ const m = meta(s); fs.mkdirSync(sdir(s), {recursive: true}); const f = path.join(sdir(s), 'meta.json'); fs.writeFileSync(f + '.tmp', JSON.stringify(m)); fs.renameSync(f + '.tmp', f); }
  const yearCache = new Map();   // "XAUUSD/2024" → {m15: Map(t → row), h1: Map, dirty}
  function yearData(s, y){
    const k = code(s) + '/' + y; if(yearCache.has(k)) return yearCache.get(k);
    const e = {m15: new Map(), h1: new Map(), dirty: false};
    try{ const j = JSON.parse(fs.readFileSync(path.join(sdir(s), y + '.json'), 'utf8')); (j.m15 || []).forEach(r => e.m15.set(r[0], r)); (j.h1 || []).forEach(r => e.h1.set(r[0], r)); }catch(x){}
    yearCache.set(k, e); return e;
  }
  function flush(){
    for(const [k, e] of yearCache){ if(!e.dirty) continue;
      const [c, y] = k.split('/'), f = path.join(dir, c, y + '.json'); fs.mkdirSync(path.join(dir, c), {recursive: true});
      const srt = M => [...M.values()].sort((a, b) => a[0] - b[0]);
      fs.writeFileSync(f + '.tmp', JSON.stringify({m15: srt(e.m15), h1: srt(e.h1)})); fs.renameSync(f + '.tmp', f); e.dirty = false; }
    // keep memory small: drop clean years from the cache
    for(const [k, e] of yearCache) if(!e.dirty) yearCache.delete(k);
  }

  // ---------- download one day ----------
  // bounded retries (a day that keeps failing is retried on a later run, not
  // here — one bad day must not stall the whole download for minutes)
  async function fetchBuf(url, tries = 4){
    let last = 'unavailable';
    for(let a = 0; a < tries; a++){
      try{
        const r = await fetch(url, {signal: AbortSignal.timeout(45000), headers: {'User-Agent': 'Mozilla/5.0 (mp-server history)'}});
        if(r.status === 404) return Buffer.alloc(0);
        if(r.status === 429 || r.status >= 500){ last = 'HTTP ' + r.status; H.busyHits = (H.busyHits || 0) + 1; await sleep(2000*Math.pow(2, a)); continue; }
        if(!r.ok) throw Object.assign(new Error('HTTP ' + r.status), {final: true});
        return Buffer.from(await r.arrayBuffer());
      }catch(e){ if(e.final) throw e; last = e.name === 'TimeoutError' ? 'хугацаа хэтэрсэн' : (e.cause && e.cause.code) || e.message; if(a === tries - 1) break; await sleep(1500*Math.pow(2, a)); }
    }
    throw new Error(last);
  }
  const dayUrl = (s, d) => `${base}/${code(s)}/${d.getUTCFullYear()}/${pad(d.getUTCMonth())}/${pad(d.getUTCDate())}/BID_candles_min_1.bi5`;

  // record layout detection: 24-byte records [time, a, b, c, d, volume]; the
  // price fields are int32 (or float32 for some instruments) in an order that
  // must satisfy low ≤ open, close ≤ high on (almost) every bar
  const ORDERS = {OCLH: 1, OHLC: 1};   // price field orders tried (Dukascopy candles are reported as open, close, low, high)
  function decodeRaw(buf, layout){
    const n = Math.floor(buf.length/24), out = [];
    for(let i = 0; i < n; i++){
      const o = i*24, t = buf.readUInt32BE(o);
      const v = [0, 1, 2, 3].map(k => layout.float ? buf.readFloatBE(o + 4 + 4*k) : buf.readInt32BE(o + 4 + 4*k));
      let op, cl, lo, hi;
      if(layout.order === 'OCLH'){ [op, cl, lo, hi] = v; } else { [op, hi, lo, cl] = v; }
      out.push({t, o: op, h: hi, l: lo, c: cl, vol: buf.readFloatBE(o + 20)});
    }
    return out;
  }
  function detectLayout(buf){
    if(!buf.length || buf.length % 24) return null;
    let best = null;
    for(const float of [false, true]) for(const order of Object.keys(ORDERS)){
      const L = {float, order}, R = decodeRaw(buf, L).filter(r => !(r.vol === 0 && r.o === r.h && r.h === r.l && r.l === r.c));
      if(R.length < 20) continue;
      const okBars = R.filter(r => isFinite(r.o) && r.l <= Math.min(r.o, r.c) && r.h >= Math.max(r.o, r.c) && r.l > 0).length/R.length;
      const tsOk = R.every((r, i) => r.t % 60 === 0 && r.t < 86400 && (i === 0 || r.t > R[i-1].t));
      const changing = R.filter(r => r.h > r.l).length/R.length;
      // int prices read as float become tiny denormals (and floats read as int become huge), with the
      // same ordering — so plausibility of the magnitude decides between the two
      const med = R.map(r => r.c).sort((a, b) => a - b)[R.length >> 1];
      const plaus = float ? (med > 1e-6 && med < 1e7 ? 1 : 0) : (med >= 1 && med < 5e8 ? 1 : 0);
      const score = okBars + (tsOk ? 1 : 0) + (changing > 0.3 ? 0.5 : 0) + plaus;
      if(!best || score > best.score) best = {L, score, okBars, tsOk};
    }
    return best && best.okBars > 0.98 && best.tsOk ? best.L : null;
  }
  // 1-minute bars of one UTC day → merge into 15m and 1h buckets
  function ingestDay(s, d, buf){
    const m = meta(s); if(!buf.length) return 0;
    if(!m.layout){ const L = detectLayout(buf); if(!L) throw new Error('файлын бүтэц танигдсангүй'); m.layout = L; log(`Түүх ${code(s)}: файлын бүтэц ${L.order}${L.float ? ' float' : ' int'}`); }
    const sc = m.scale || DEFAULT_SCALE(code(s)), day0 = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())/1000;
    const R = decodeRaw(buf, m.layout).filter(r => !(r.vol === 0 && r.o === r.h && r.h === r.l && r.l === r.c));
    const Y = yearData(s, d.getUTCFullYear());
    const agg = (M, sec, r) => { const t = day0 + r.t, b = t - (t % sec), x = M.get(b);
      const o = r.o/sc, h = r.h/sc, l = r.l/sc, c = r.c/sc;
      if(!x) M.set(b, [b, o, h, l, c, +r.vol.toFixed(2), t]);   // [7th] = last minute seen, keeps order when merging
      else{ if(t < x[6]){ x[1] = o; } else { x[4] = c; x[6] = t; } x[2] = Math.max(x[2], h); x[3] = Math.min(x[3], l); x[5] = +(x[5] + r.vol).toFixed(2); } };
    // a re-download of the same day replaces its bars
    for(const k of [...Y.m15.keys()]) if(k >= day0 && k < day0 + 86400) Y.m15.delete(k);
    for(const k of [...Y.h1.keys()]) if(k >= day0 && k < day0 + 86400) Y.h1.delete(k);
    R.forEach(r => { agg(Y.m15, 900, r); agg(Y.h1, 3600, r); });
    Y.dirty = true; return R.length;
  }

  // ---------- calibration against Twelve Data ----------
  // finds the price scale and the time offset (whole hours) at which the
  // Dukascopy 15-minute closes match the stored Twelve Data closes
  function calibrate(s){
    const a = calibrateWith(s, '15min', 'm15');
    if(a.ok) return a;
    const b = calibrateWith(s, '1h', 'h1');   // 1-hour Twelve Data candles reach further back → overlap sooner
    return b.ok ? b : (a.n || !b.n ? a : b);
  }
  function calibrateWith(s, tdIv, key){
    const m = meta(s), td = tdStore(s, tdIv); if(!td || td.length < 60) return {ok: false, note: 'Twelve Data-гийн харьцуулах лаа хараахан алга'};
    const sc0 = m.scale || DEFAULT_SCALE(code(s));
    const dk = new Map(); const ys = new Set(td.map(r => new Date(r.t*1000).getUTCFullYear()));
    ys.forEach(y => { const Y = yearData(s, y); for(const [t, r] of Y[key]) dk.set(t, r[4]*sc0); });   // back to raw units
    if(dk.size < 60) return {ok: false, note: 'давхцах хугацааны Dukascopy өгөгдөл хараахан алга'};
    const tdFrom = td[0].t, tdTo = td[td.length - 1].t; let dkTo = 0; for(const t of dk.keys()) if(t > dkTo) dkTo = t;
    let best = null;
    for(let sh = -14; sh <= 14; sh++){
      const ratios = [];
      td.forEach(r => { const raw = dk.get(r.t - sh*3600); if(raw) ratios.push(r.c/raw); });
      if(ratios.length < 40) continue;
      ratios.sort((a, b) => a - b); const med = ratios[ratios.length >> 1];
      const scale = SCALES.reduce((b, x) => Math.abs(Math.log(med*x)) < Math.abs(Math.log(med*b)) ? x : b, 1);
      const err = ratios.map(q => Math.abs(q*scale - 1)).sort((a, b) => a - b)[ratios.length >> 1];
      if(!best || err < best.err) best = {sh, scale, err, n: ratios.length};
    }
    if(!best){ const iso = t => new Date(t*1000).toISOString().slice(0, 10);
      return {ok: false, note: dkTo && dkTo < tdFrom ? `давхцах цаг алга: Dukascopy ${iso(dkTo)} хүртэл, Twelve Data ${iso(tdFrom)}-аас — шинэ өдрүүд татагдмагц шалгана` : 'давхцах цаг олдсонгүй'}; }
    const ok = best.err < 0.0025;
    // best.scale = the divisor that turns the raw values into Twelve Data's prices
    return {ok, divisor: best.scale, shiftMin: best.sh*60, err: best.err, n: best.n,
      tdIv, note: ok ? `Twelve Data-тай (${tdIv}) ${best.n} лаагаар таарсан (дундаж зөрүү ${(best.err*100).toFixed(3)}%${best.sh ? `, цагийн зөрүү ${best.sh} цаг` : ''})` : `зөрүү хэт их (${(best.err*100).toFixed(2)}%)`};
  }
  function applyCalibration(s){
    const m = meta(s), C = calibrate(s); m.verifyNote = C.note;
    if(C.ok){
      const sc0 = m.scale || DEFAULT_SCALE(code(s)), divisor = C.divisor;
      if(divisor !== sc0){
        log(`Түүх ${code(s)}: үнийн масштаб ${sc0} → ${divisor} болгон засав`);
        // rescale every stored year
        fs.readdirSync(sdir(s)).filter(f => /^\d{4}\.json$/.test(f)).forEach(f => { const Y = yearData(s, +f.slice(0, 4)); const k = sc0/divisor;
          [Y.m15, Y.h1].forEach(M => M.forEach(r => { r[1] *= k; r[2] *= k; r[3] *= k; r[4] *= k; })); Y.dirty = true; });
        flush();
      }
      // v1.8.2: Dukascopy is UTC by definition and every stored Twelve Data candle is UTC, so the
      // shift is always 0. A non-zero best match means the comparison data is off, not Dukascopy —
      // reported, never applied (1.3–1.8.1 kept re-applying +11 h found against old candles).
      if(C.shiftMin){ C.note += ` · ⚠ хамгийн сайн таарц ${C.shiftMin/60} цагийн зөрүүтэй гарсан ч Dukascopy UTC тул 0-ээр ашиглав`; log(`Түүх ${code(s)}: калибровк ${C.shiftMin/60} цагийн зөрүү санал болгосон — үл хэрэгсэв (UTC)`); }
      m.scale = divisor; m.shiftMin = 0; m.verified = true; m.verifiedAt = Date.now();
    }else if(m.verified && /хэт их/.test(C.note)){ m.verified = false; onEvent && onEvent(`⚠ ${code(s)} урт түүх Twelve Data-тай таарахаа больсон: ${C.note}. Түүхэн тестэд ашиглахгүй.`); }
    metaSave(s); return C;
  }

  // ---------- the download job ----------
  async function run(reason){
    if(H.busy) return {busy: true}; H.busy = true; H.stop = false;
    const t0 = Date.now(), done = {}; let failed = 0;
    try{
      const end = new Date(Date.now() - DAY), start = new Date(Date.UTC(end.getUTCFullYear() - years, end.getUTCMonth(), end.getUTCDate()));
      H.errs = {}; H.busyHits = 0;
      for(const s of symbols){
        const m = meta(s), fresh = [], retry = [], crypto = /^(BTC|ETH|LTC|XRP|SOL)/.test(code(s));
        for(let d = new Date(end); d >= start; d = new Date(d.getTime() - DAY)){
          const wd = d.getUTCDay(); if(wd === 6 && !crypto) continue;     // Saturday — FX/metals closed (crypto trades)
          const k = ymdUTC(d), v = m.days[k], age = Date.now() - d.getTime();
          if(v === 1) continue;
          // an empty weekday is unusual (data is published with a delay) → re-check for 3 weeks; empty Sundays for 4 days
          if(v === 'e' && !(age < (wd === 0 || wd === 6 ? 4 : 21)*DAY)) continue;
          // a day that failed 3 runs in a row waits a week before the next try
          if(v === 'x' && !(Date.now() - (m.fail[k] && m.fail[k].at || 0) > 7*DAY)) continue;
          (m.fail[k] ? retry : fresh).push(new Date(d));
        }
        const todo = fresh.concat(retry);   // never-tried days first (newest first), earlier failures last
        if(!todo.length){ done[code(s)] = 0; try{ applyCalibration(s); }catch(e){ log('Түүх шалгахад алдаа:', e.message); } continue; }
        log(`Түүх ${code(s)}: ${todo.length} өдөр татна (${reason}${retry.length ? `, үүнээс ${retry.length} нь өмнө амжилтгүй болсон` : ''})`);
        let n = 0, k = 0, nf = 0, streak = 0;
        const worker = async () => { while(k < todo.length && !H.stop){ const d = todo[k++], key = ymdUTC(d);
          try{ const buf = await fetchBuf(dayUrl(s, d), m.fail[key] ? 2 : 4); const raw = buf.length ? decompress(buf) : buf; const c = ingestDay(s, d, raw); m.days[key] = c ? 1 : 'e'; delete m.fail[key]; n++; streak = 0; }
          catch(e){ failed++; nf++; streak++; const msg = String(e.message || e).slice(0, 80); H.errs[msg] = (H.errs[msg] || 0) + 1; m.lastErr = msg;
            const F = m.fail[key] = {n: ((m.fail[key] && m.fail[key].n) || 0) + 1, at: Date.now(), e: msg}; if(F.n >= 3) m.days[key] = 'x';
            if(nf < 5) log(`Түүх ${code(s)} ${key}: ${msg}`);
            // throttling / outage → back off; a broken file (decode error) is not a reason to wait
            if(!/^(HTTP (429|5\d\d)|хугацаа|E[A-Z]+)/.test(msg)) streak = 0;
            if(streak >= 8){ log(`Түүх ${code(s)}: дараалсан ${streak} сүлжээний алдаа — 60 сек хүлээнэ`); await sleep(60000); streak = 0; } }
          H.prog = {sym: code(s), i: k, n: todo.length};
          if((n + nf) % 40 === 0){ flush(); metaSave(s); }
          await sleep(pauseMs); } };
        await Promise.all([worker(), worker()]);
        flush();
        // first calibration as soon as recent data exists, then on every run
        applyCalibration(s);
        const ks = Object.keys(m.days).filter(x => m.days[x] === 1).sort(); m.from = ks[0] || null; m.to = ks[ks.length - 1] || null;
        metaSave(s); done[code(s)] = n;
        if(nf) log(`Түүх ${code(s)}: ${nf} өдөр татаж чадсангүй (дараагийн удаа дахин оролдоно)`);
        if(H.stop) break;
      }
    }finally{ H.busy = false; H.prog = null; flush(); }
    const r = {done, failed, sec: Math.round((Date.now() - t0)/1000), errs: H.errs, busyHits: H.busyHits};
    log('Түүх татаж дууслаа:', r); return r;
  }

  // ---------- serve ----------
  const IVS = {'15min': ['m15', 1], '30min': ['m15', 2], '45min': ['m15', 3], '1h': ['h1', 1], '2h': ['h1', 2], '4h': ['h1', 4], '1day': ['h1', 'D'], '1week': ['h1', 'W']};
  function bars(s, iv, limit){
    const m = meta(s), spec = IVS[iv]; if(!spec) return {error: 'unsupported', note: `${iv} цагийн урт түүх байхгүй (15min–1week)`};
    if(!m.verified) return {error: 'unverified', note: m.verifyNote || 'Twelve Data-тай хараахан шалгагдаагүй'};
    const ys = fs.existsSync(sdir(s)) ? fs.readdirSync(sdir(s)).filter(f => /^\d{4}\.json$/.test(f)).map(f => +f.slice(0, 4)).sort() : [];
    let rows = []; ys.forEach(y => { const Y = yearData(s, y); rows = rows.concat([...Y[spec[0]].values()]); });
    rows.sort((a, b) => a[0] - b[0]);
    const sh = (m.shiftMin || 0)*60; rows = rows.map(r => [r[0] + sh, r[1], r[2], r[3], r[4], r[5]]);
    // group into the requested interval (UTC-based buckets after the shift)
    if(spec[1] !== 1){
      const out = new Map(), sec = spec[0] === 'm15' ? 900 : 3600;
      rows.forEach(r => {
        let b;
        if(spec[1] === 'D') b = r[0] - (r[0] % 86400);
        else if(spec[1] === 'W'){ const d = r[0] - (r[0] % 86400), wd = new Date(d*1000).getUTCDay(); b = d - ((wd + 6) % 7)*86400; }
        else{ const w = sec*spec[1]; b = r[0] - (r[0] % w); }
        const x = out.get(b); if(!x) out.set(b, [b, r[1], r[2], r[3], r[4], r[5]]); else{ x[2] = Math.max(x[2], r[2]); x[3] = Math.min(x[3], r[3]); x[4] = r[4]; x[5] += r[5]; } });
      rows = [...out.values()].sort((a, b) => a[0] - b[0]);
    }
    if(limit && rows.length > limit) rows = rows.slice(-limit);
    for(const [k, e] of yearCache) if(!e.dirty) yearCache.delete(k);   // read-only use: free memory
    const dec = Math.max(2, Math.min(6, Math.round(Math.log10(m.scale || 1e5))));
    const iso = t => new Date(t*1000).toISOString().slice(0, 19).replace('T', ' ');
    return {meta: {symbol: s, interval: iv, exchange_timezone: 'UTC', type: 'history', source: 'dukascopy-bid'}, status: 'ok',
      values: rows.reverse().map(r => ({datetime: iso(r[0]), open: r[1].toFixed(dec), high: r[2].toFixed(dec), low: r[3].toFixed(dec), close: r[4].toFixed(dec), volume: String(Math.round(r[5]))}))};
  }
  function coverage(){
    return symbols.map(s => { const m = meta(s), ks = Object.keys(m.days).filter(x => m.days[x] === 1).sort();
      const pend = Object.keys(m.fail || {}).length, gaveUp = Object.values(m.days).filter(v => v === 'x').length;
      return {symbol: s, code: code(s), from: ks[0] || null, to: ks[ks.length - 1] || null, days: ks.length, verified: m.verified, note: m.verifyNote, layout: m.layout, scale: m.scale, shiftMin: m.shiftMin,
        failing: pend, gaveUp, lastErr: m.lastErr || ''}; });
  }
  return Object.assign(H, {run, bars, coverage, calibrate: applyCalibration, _test: {detectLayout, decodeRaw, ingestDay, meta, yearData, flush}});
}
module.exports = {makeHist};
