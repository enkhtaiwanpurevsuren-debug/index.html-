@echo off
cd /d "%~dp0"
title Market Pattern server (test) - close this window or press Ctrl+C to stop
set PLAYWRIGHT_BROWSERS_PATH=%~dp0browsers
echo Starting in this window. Open http://127.0.0.1:8787/status in a browser on this notebook.
echo Stop with Ctrl+C (or close the window) before running setup-windows.
node server.js
pause
