'use strict';
// =====================================================================
//  Minimal LZMA ("LZMA-alone" / .lzma) decoder — pure JS, no dependencies.
//  Dukascopy .bi5 files are LZMA-alone streams. Follows the reference
//  LzmaSpec decoder (Igor Pavlov, public domain) step by step.
// =====================================================================
const kNumBitModelTotalBits = 11, kBitModelTotal = 1 << kNumBitModelTotalBits, kNumMoveBits = 5;
const kTopValue = 1 << 24;

class RangeDecoder {
  constructor(buf, pos){
    this.buf = buf; this.pos = pos; this.range = 0xFFFFFFFF; this.code = 0; this.corrupted = false;
    const b0 = this.buf[this.pos++];
    for(let i = 0; i < 4; i++) this.code = ((this.code << 8) | this.next()) >>> 0;
    if(b0 !== 0 || this.code === this.range) this.corrupted = true;
  }
  next(){ if(this.pos >= this.buf.length) throw new Error('lzma: unexpected end of input'); return this.buf[this.pos++]; }
  normalize(){ if(this.range < kTopValue){ this.range = (this.range << 8) >>> 0; this.code = ((this.code << 8) | this.next()) >>> 0; } }
  finishedOK(){ return this.code === 0; }
  directBits(numBits){
    let res = 0;
    do{
      this.range >>>= 1;
      this.code = (this.code - this.range) >>> 0;
      const t = 0 - (this.code >>> 31);       // 0 or -1
      this.code = (this.code + (this.range & t)) >>> 0;
      if(this.code === this.range) this.corrupted = true;
      this.normalize();
      res = ((res << 1) + (t + 1)) >>> 0;
    }while(--numBits);
    return res;
  }
  bit(probs, i){
    let v = probs[i];
    const bound = (this.range >>> kNumBitModelTotalBits) * v >>> 0;
    let symbol;
    if(this.code < bound){
      v += (kBitModelTotal - v) >>> kNumMoveBits; this.range = bound; symbol = 0;
    }else{
      v -= v >>> kNumMoveBits; this.code = (this.code - bound) >>> 0; this.range = (this.range - bound) >>> 0; symbol = 1;
    }
    probs[i] = v; this.normalize(); return symbol;
  }
}
const initProbs = n => new Uint16Array(n).fill(kBitModelTotal >>> 1);
function bitTreeDecode(probs, base, numBits, rc){ let m = 1; for(let i = 0; i < numBits; i++) m = (m << 1) + rc.bit(probs, base + m); return m - (1 << numBits); }
function bitTreeReverseDecode(probs, base, numBits, rc){ let m = 1, sym = 0; for(let i = 0; i < numBits; i++){ const bit = rc.bit(probs, base + m); m = (m << 1) + bit; sym |= bit << i; } return sym; }

const kNumPosBitsMax = 4, kNumStates = 12, kNumLenToPosStates = 4, kNumAlignBits = 4, kStartPosModelIndex = 4, kEndPosModelIndex = 14, kNumFullDistances = 1 << (kEndPosModelIndex >>> 1), kMatchMinLen = 2;

class LenDecoder {
  constructor(){ this.choice = initProbs(2); this.low = initProbs(kNumPosBitsMax << 3); this.mid = initProbs(kNumPosBitsMax << 3); this.high = initProbs(256); }
  decode(rc, posState){
    if(rc.bit(this.choice, 0) === 0) return bitTreeDecode(this.low, posState << 3, 3, rc);
    if(rc.bit(this.choice, 1) === 0) return 8 + bitTreeDecode(this.mid, posState << 3, 3, rc);
    return 16 + bitTreeDecode(this.high, 0, 8, rc);
  }
}

function decompress(input){
  const buf = input instanceof Uint8Array ? input : new Uint8Array(input);
  if(buf.length < 13) throw new Error('lzma: header too short');
  let d = buf[0]; if(d >= 9*5*5) throw new Error('lzma: bad properties');
  const lc = d % 9; d = (d / 9) | 0; const lp = d % 5, pb = (d / 5) | 0;
  let dictSize = (buf[1] | (buf[2] << 8) | (buf[3] << 16) | (buf[4] << 24)) >>> 0;
  if(dictSize < 4096) dictSize = 4096;
  // 64-bit unpacked size; all 0xFF = unknown (an end marker follows)
  let unknown = true; for(let i = 5; i < 13; i++) if(buf[i] !== 0xFF){ unknown = false; break; }
  let unpackSize = 0; if(!unknown){ for(let i = 12; i >= 5; i--) unpackSize = unpackSize*256 + buf[i]; }
  // a corrupt / non-LZMA file must fail fast, never allocate or loop without bound
  // (a Dukascopy day file unpacks to ~35 KB; allow far more, but not unlimited)
  const MAX_OUT = 64*1024*1024;
  if(!unknown && unpackSize > MAX_OUT) throw new Error('lzma: unpacked size too large (corrupt file?)');
  const out = new Uint8Array(unknown ? Math.max(1 << 16, Math.min(MAX_OUT, buf.length*8)) : unpackSize);
  let outPos = 0, outBuf = out;
  const grow = () => { if(outBuf.length >= MAX_OUT) throw new Error('lzma: output too large (corrupt file?)'); const nb = new Uint8Array(Math.min(MAX_OUT, outBuf.length*2)); nb.set(outBuf); outBuf = nb; };
  const putByte = b => { if(outPos >= outBuf.length) grow(); outBuf[outPos++] = b; };
  const getByte = dist => outBuf[outPos - dist];

  const rc = new RangeDecoder(buf, 13);
  if(rc.corrupted) throw new Error('lzma: corrupted range coder init');
  const literalProbs = initProbs(0x300 << (lc + lp));
  const posSlot = initProbs(kNumLenToPosStates << 6), posDecoders = initProbs(1 + kNumFullDistances - kEndPosModelIndex), align = initProbs(1 << kNumAlignBits);
  const isMatch = initProbs(kNumStates << kNumPosBitsMax), isRep = initProbs(kNumStates), isRepG0 = initProbs(kNumStates), isRepG1 = initProbs(kNumStates), isRepG2 = initProbs(kNumStates), isRep0Long = initProbs(kNumStates << kNumPosBitsMax);
  const lenDec = new LenDecoder(), repLenDec = new LenDecoder();
  const pbMask = (1 << pb) - 1, lpMask = (1 << lp) - 1;
  let rep0 = 0, rep1 = 0, rep2 = 0, rep3 = 0, state = 0;

  const decodeLiteral = (st, r0) => {
    const prevByte = outPos > 0 ? outBuf[outPos - 1] : 0;
    const litState = ((outPos & lpMask) << lc) + (prevByte >>> (8 - lc));
    const base = 0x300 * litState;
    let symbol = 1;
    if(st >= 7){
      let matchByte = getByte(r0 + 1);
      do{
        const matchBit = (matchByte >>> 7) & 1; matchByte <<= 1;
        const bit = rc.bit(literalProbs, base + ((1 + matchBit) << 8) + symbol);
        symbol = (symbol << 1) | bit;
        if(matchBit !== bit) break;
      }while(symbol < 0x100);
    }
    while(symbol < 0x100) symbol = (symbol << 1) | rc.bit(literalProbs, base + symbol);
    putByte(symbol - 0x100);
  };
  const decodeDistance = len => {
    let lenState = len; if(lenState > kNumLenToPosStates - 1) lenState = kNumLenToPosStates - 1;
    const ps = bitTreeDecode(posSlot, lenState << 6, 6, rc);
    if(ps < 4) return ps;
    const numDirectBits = (ps >>> 1) - 1;
    let dist = ((2 | (ps & 1)) << numDirectBits) >>> 0;
    if(ps < kEndPosModelIndex) dist = (dist + bitTreeReverseDecode(posDecoders, dist - ps, numDirectBits, rc)) >>> 0;
    else{ dist = (dist + ((rc.directBits(numDirectBits - kNumAlignBits) << kNumAlignBits) >>> 0)) >>> 0; dist = (dist + bitTreeReverseDecode(align, 0, kNumAlignBits, rc)) >>> 0; }
    return dist;
  };
  const updLit = s => s < 4 ? 0 : s < 10 ? s - 3 : s - 6;
  const updMatch = s => s < 7 ? 7 : 10, updRep = s => s < 7 ? 8 : 11, updShortRep = s => s < 7 ? 9 : 11;

  for(;;){
    if(!unknown && outPos >= unpackSize) break;
    const posState = outPos & pbMask;
    if(rc.bit(isMatch, (state << kNumPosBitsMax) + posState) === 0){
      decodeLiteral(state, rep0); state = updLit(state); continue;
    }
    let len;
    if(rc.bit(isRep, state) !== 0){
      if(outPos === 0) throw new Error('lzma: rep match at start');
      if(rc.bit(isRepG0, state) === 0){
        if(rc.bit(isRep0Long, (state << kNumPosBitsMax) + posState) === 0){ state = updShortRep(state); putByte(getByte(rep0 + 1)); continue; }
      }else{
        let dist;
        if(rc.bit(isRepG1, state) === 0) dist = rep1;
        else{ if(rc.bit(isRepG2, state) === 0) dist = rep2; else{ dist = rep3; rep3 = rep2; } rep2 = rep1; }
        rep1 = rep0; rep0 = dist;
      }
      len = repLenDec.decode(rc, posState); state = updRep(state);
    }else{
      rep3 = rep2; rep2 = rep1; rep1 = rep0;
      len = lenDec.decode(rc, posState); state = updMatch(state);
      rep0 = decodeDistance(len);
      if(rep0 === 0xFFFFFFFF){ break; }   // end marker
      if(rep0 >= outPos) throw new Error('lzma: distance beyond output');
    }
    len += kMatchMinLen;
    if(!unknown && unpackSize - outPos < len) len = unpackSize - outPos;
    for(let i = 0; i < len; i++) putByte(getByte(rep0 + 1));
  }
  return Buffer.from(outBuf.buffer, outBuf.byteOffset, outPos);
}
module.exports = {decompress};
