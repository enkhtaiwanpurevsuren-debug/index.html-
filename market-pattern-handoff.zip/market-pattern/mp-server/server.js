'use strict';
// =====================================================================
//  Market Pattern — NOTEBOOK СЕРВЕР (mp-server)
//
//  Notebook дээр 24/7 ажиллана:
//   1. Станц  — dashboard-ыг (app/index.html) нүдэнд үл харагдах Chromium-д
//               яг утсан дээрхтэй адил ажиллуулж, бодит туршилтыг (скан,
//               журнал, таамгийн хэмжилт) зогсолтгүй явуулна.
//   2. Telegram — станцын мэдэгдэл, өдрийн тайлан, үнийн сэрүүлэг; ботод
//               /status /shot /report командаар асууж болно.
//   3. Өгөгдөл — Twelve Data-аас ирсэн лаа бүрийг data/candles-д хуримтлуулна.
//   4. Нөөц    — станцын бүх өгөгдлийг 30 мин тутам data/backups-д хадгална.
//   5. Утаснаас — Tailscale-ээр https://<нэр>.ts.net хаягаар апп, /status
//               хуудас, станцын өгөгдлийг татах.
//
//  Нууц мэдээлэл (API түлхүүр, Telegram token, нууц үг) зөвхөн .env файлд.
// =====================================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const DIRS = {big: path.join(DATA, 'big'), profile: path.join(DATA, 'profile'), candles: path.join(DATA, 'candles'), backups: path.join(DATA, 'backups'), logs: path.join(DATA, 'logs'), history: path.join(DATA, 'history')};
const APP_FILE = path.join(ROOT, 'app', 'index.html');
const ENV_FILE = path.join(ROOT, '.env');
const STATE_FILE = path.join(DATA, 'state.json');
const VERSION = 'mp-server 1.11';
const RESTART_HINT = process.platform === 'win32' ? '.env засаад restart.bat' : 'sudo mpctl edit';

// ---------------------------------------------------------------- .env
function parseEnv(txt){
  const out = {};
  String(txt).replace(/^﻿/, '').split(/\r?\n/).forEach(line => {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line); if(!m || /^\s*#/.test(line)) return;
    let v = m[2]; if(/^".*"$/.test(v) || /^'.*'$/.test(v)) v = v.slice(1, -1);
    out[m[1]] = v;
  });
  return out;
}
function initEnv(){
  const ex = path.join(ROOT, 'config.example.env');
  if(fs.existsSync(ENV_FILE)){ console.log('.env аль хэдийн байна — өөрчлөөгүй.'); return; }
  const tok = crypto.randomBytes(18).toString('base64url');
  let txt = fs.readFileSync(ex, 'utf8').replace(/^STATION_TOKEN=.*$/m, 'STATION_TOKEN=' + tok);
  if(process.platform !== 'win32') txt = txt.replace(/\r\n/g, '\n');
  fs.writeFileSync(ENV_FILE, txt, {mode: 0o600});
  console.log('.env үүслээ. STATION_TOKEN автоматаар үүсгэгдсэн: ' + tok);
  console.log(process.platform === 'win32' ? 'Одоо .env-ийг Notepad-аар нээж TD_API_KEY, TG_TOKEN-оо бичнэ үү.' : 'Одоо sudo mpctl edit гэж .env-д TD_API_KEY, TG_TOKEN-оо бичнэ үү.');
}
if(process.argv.includes('--init-env')){ initEnv(); process.exit(0); }

const ENV = Object.assign({}, fs.existsSync(ENV_FILE) ? parseEnv(fs.readFileSync(ENV_FILE, 'utf8')) : {}, process.env.MP_TEST ? process.env : {});
const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
const CFG = {
  port: num(ENV.PORT, 8787), host: ENV.HOST || '127.0.0.1', tz: ENV.STATION_TZ || 'Asia/Ulaanbaatar',
  tdKey: (ENV.TD_API_KEY || '').trim(), token: (ENV.STATION_TOKEN || '').trim(),
  tgToken: (ENV.TG_TOKEN || '').trim(), tgChat: (ENV.TG_CHAT || '').trim(),
  sym: ENV.CHART_SYMBOL || 'XAU/USD', iv: ENV.CHART_INTERVAL || '15min',
  refreshSec: String(num(ENV.CHART_REFRESH_SEC, 900)),
  autoStation: ENV.AUTO_START_STATION !== '0',
  creditCap: num(ENV.CREDIT_CAP, 600), alarmEvery: Math.max(2, num(ENV.ALARM_EVERY_MIN, 5)),
  history: ENV.HISTORY !== '0', histYears: Math.max(1, Math.min(15, num(ENV.HISTORY_YEARS, 5))),
  histSymbols: String(ENV.HISTORY_SYMBOLS || 'XAU/USD,EUR/USD,GBP/USD,USD/JPY,BTC/USD').split(',').map(x => x.trim()).filter(Boolean),
  // v1.8 trend system: daily bars of many markets (diversification is what makes trend-following work)
  trendSymbols: String(ENV.TREND_SYMBOLS || 'EUR/USD,GBP/USD,USD/JPY,AUD/USD,USD/CAD,USD/CHF,NZD/USD,EUR/JPY,GBP/JPY,EUR/GBP,AUD/JPY,XAU/USD,XAG/USD,BTC/USD').split(',').map(x => x.trim()).filter(Boolean),
  trendYears: Math.max(3, Math.min(15, num(ENV.TREND_YEARS, 10))), trendAcct: num(ENV.TREND_ACCOUNT, 10000), trendOn: ENV.TREND !== '0',
  histTestIvs: String(ENV.HISTORY_TEST_INTERVALS || '15min,1h,4h').split(',').map(x => x.trim()).filter(Boolean),
  dukaBase: (ENV.DUKA_BASE || 'https://datafeed.dukascopy.com/datafeed').replace(/\/+$/, ''),
  reportHour: num(ENV.REPORT_HOUR, 21), backupKeep: num(ENV.BACKUP_KEEP_DAYS, 30),
  backupCopy: (ENV.BACKUP_COPY_DIR || '').trim(), backupTg: ENV.BACKUP_TELEGRAM !== '0',
  tdBase: (ENV.TD_BASE || 'https://api.twelvedata.com').replace(/\/+$/, ''),
  tgBase: (ENV.TG_BASE || 'https://api.telegram.org').replace(/\/+$/, ''),
};
const DAY = 864e5;
// rewrite chosen keys of .env in place (other lines and comments stay)
function envSet(vals){
  let txt = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8') : '';
  const nl = /\r\n/.test(txt) ? '\r\n' : '\n';
  Object.entries(vals).forEach(([k, v]) => {
    v = String(v).replace(/[\r\n]/g, '').trim();
    const re = new RegExp('^' + k + '=.*$', 'm');
    txt = re.test(txt) ? txt.replace(re, k + '=' + v) : txt.replace(/\s*$/, '') + nl + k + '=' + v + nl;
  });
  fs.writeFileSync(ENV_FILE, txt, {mode: 0o600});
}
const PAIR_CODE = String(crypto.randomInt(100000, 1000000));

// ---------------------------------------------------------------- logging
Object.values(DIRS).forEach(d => fs.mkdirSync(d, {recursive: true}));
const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function log(...a){
  const line = `[${new Date().toLocaleString('sv-SE')}] ` + a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ');
  console.log(line);
  try{ fs.appendFileSync(path.join(DIRS.logs, `server-${ymd()}.log`), line + '\n'); }catch(e){}
}
function pruneDir(dir, re, keepDays){
  try{ fs.readdirSync(dir).forEach(f => { if(!re.test(f)) return; const p = path.join(dir, f); if(Date.now() - fs.statSync(p).mtimeMs > keepDays*DAY) fs.unlinkSync(p); }); }catch(e){}
}
function writeAtomic(file, data){ const tmp = file + '.tmp'; fs.writeFileSync(tmp, data); fs.renameSync(tmp, file); }
// v1.7 «big store»: the research stores (history-test signals, forecast audit, pattern lifecycle,
// test summaries) outgrew the browser's 5 MB localStorage — writes failed silently and new test
// results were lost. On the station they live in data/big/*.json instead (no size limit).
const BIG_KEYS = ['eud_fq_v1', 'eud_btsig', 'eud_lc_hist', 'eud_bt'];
const bigFile = k => path.join(DIRS.big, k + '.json');
function bigSave(key, val){
  if(!BIG_KEYS.includes(key) || typeof val !== 'string' || val.length > 200*1024*1024) return false;
  try{ JSON.parse(val); writeAtomic(bigFile(key), val); return true; }catch(e){ log('Том өгөгдөл хадгалж чадсангүй:', key, e.message); return false; }
}
function bigAll(){ const o = {}; BIG_KEYS.forEach(k => { try{ o[k] = fs.readFileSync(bigFile(k), 'utf8'); }catch(e){} }); return o; }

if(process.argv.includes('--check')){ check().then(ok => process.exit(ok ? 0 : 1)); }
else{
  const miss = [];
  if(!CFG.tdKey) miss.push('TD_API_KEY'); if(CFG.token.length < 16) miss.push('STATION_TOKEN (16+ тэмдэгт)');
  if(miss.length){ log('❌ .env дутуу байна: ' + miss.join(', ') + '. install.bat-ийг ажиллуулж .env-ээ бөглөнө үү.'); process.exit(2); }
  if(!fs.existsSync(APP_FILE)){ log('❌ app/index.html олдсонгүй.'); process.exit(2); }
  main().catch(e => { log('❌ Эхлэхэд алдаа:', String(e && e.stack || e)); process.exit(1); });
}

// ---------------------------------------------------------------- persistent state
const ST = (() => { try{ return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }catch(e){ return {}; } })();
const ST_FRESH = !Object.keys(ST).length;
ST.credits = ST.credits || {day: '', used: 0}; ST.alarms = ST.alarms || []; ST.fired = ST.fired || [];
ST.tgOffset = ST.tgOffset || 0; ST.lastReport = ST.lastReport || ''; ST.lastJr = ST.lastJr || null;
let stTimer = null;
function stSave(){ clearTimeout(stTimer); stTimer = setTimeout(() => { try{ writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){ log('state.json хадгалж чадсангүй', e.message); } }, 500); }

// Twelve Data resets the daily credits at 00:00 UTC
function credits(){ const d = new Date().toISOString().slice(0, 10); if(ST.credits.day !== d){ ST.credits = {day: d, used: 0, capped: false}; stSave(); } return ST.credits; }
function creditUse(n){ const C = credits(); C.used += n; if(!C.capped && C.used >= CFG.creditCap){ C.capped = true; tgSend(`⛔ Серверийн өнөөдрийн API хязгаар (${CFG.creditCap}) хүрлээ — 08:00 цагт (UTC 00:00) шинэчлэгдэнэ. Станц тэр болтол хүлээнэ.`); log('API cap reached', C.used); } stSave(); }

// ---------------------------------------------------------------- Telegram
const tgQueue = []; let tgBusy = false; const tgSeen = new Map();
function tgSend(text, opt = {}){
  if(!CFG.tgToken || !CFG.tgChat) return;
  if(opt.dedupe){ const last = tgSeen.get(opt.dedupe); if(last && Date.now() - last < (opt.every || 10*60e3)) return; tgSeen.set(opt.dedupe, Date.now()); }
  if(!opt.photo && !opt.doc && String(text).length > 4000){ const t = String(text); let cut = t.lastIndexOf('\n', 3900); if(cut < 2000) cut = 3900; const o2 = Object.assign({}, opt, {dedupe: null}); tgSend(t.slice(0, cut), opt); tgSend(t.slice(cut + 1), o2); return; }
  tgQueue.push({text: String(text).slice(0, 4000), photo: opt.photo || null, doc: opt.doc || null, docName: opt.docName || 'file.json'}); tgPump();
}
async function tgPump(){
  if(tgBusy) return; tgBusy = true;
  while(tgQueue.length){
    const m = tgQueue.shift();
    try{
      if(m.doc){
        const fd = new FormData(); fd.append('chat_id', CFG.tgChat); fd.append('caption', m.text.slice(0, 1000)); fd.append('document', new Blob([m.doc], {type: 'application/json'}), m.docName);
        const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendDocument`, {method: 'POST', body: fd}); if(!r.ok) log('Telegram файл илгээж чадсангүй:', r.status);
      }else if(m.photo){
        const fd = new FormData(); fd.append('chat_id', CFG.tgChat); fd.append('caption', m.text.slice(0, 1000)); fd.append('photo', new Blob([m.photo], {type: 'image/png'}), 'chart.png');
        await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendPhoto`, {method: 'POST', body: fd});
      }else{
        await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendMessage`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({chat_id: CFG.tgChat, text: m.text, disable_web_page_preview: true})});
      }
    }catch(e){ log('Telegram илгээж чадсангүй:', e.message); }
    await sleep(1100);   // Telegram: ≤ 1 msg/sec to a chat
  }
  tgBusy = false;
}
// bot commands — long polling; only the owner's chat is answered
async function tgPoll(){
  if(!CFG.tgToken) return;
  for(;;){
    try{
      const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/getUpdates?timeout=50&offset=${ST.tgOffset}`, {signal: AbortSignal.timeout(65000)});
      const j = await r.json();
      if(j && j.ok) for(const u of j.result){
        ST.tgOffset = u.update_id + 1; stSave();
        const msg = u.message || u.edited_message; if(!msg || !msg.text) continue;
        const chat = String(msg.chat.id), cmd = msg.text.trim().split(/\s+/)[0].replace(/@.*$/, '').toLowerCase();
        if(!CFG.tgChat){
          // pairing: the 6-digit code shown on the /status page (only the owner sees it) binds this chat
          const say = text => fetch(`${CFG.tgBase}/bot${CFG.tgToken}/sendMessage`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({chat_id: chat, text})});
          const code = (/(\d{6})/.exec(msg.text) || [])[1];
          if(code === PAIR_CODE){
            CFG.tgChat = chat; try{ envSet({TG_CHAT: chat}); }catch(e){ log('.env бичиж чадсангүй:', e.message); }
            log('Telegram холбогдлоо, chat:', chat);
            await say('✅ Холбогдлоо! Одооноос станцын мэдэгдэл, өдрийн тайлан, нөөц энд ирнэ. /status гэж бичээд туршаарай.');
          }else{
            await say(`Энэ ботыг холбохын тулд серверийн /status хуудсанд харагдах 6 оронтой кодыг энд бичнэ үү.\n(Эсвэл .env-д TG_CHAT=${chat} гэж бичээд серверийг дахин эхлүүлнэ: ${RESTART_HINT})`);
            log('Telegram: холбох код хүлээж байна, chat:', chat);
          }
          continue;
        }
        if(chat !== CFG.tgChat){ log('Танихгүй chat-аас мессеж ирсэн — хариулаагүй:', chat); continue; }
        await tgCommand(cmd, msg.text);
      }
      else await sleep(5000);
    }catch(e){ await sleep(10000); }
  }
}
async function tgCommand(cmd, text){
  const arg = String(text || '').trim().split(/\s+/).slice(1).join(' ').trim();
  if(cmd === '/status' || cmd === '/start'){ tgSend(await reportText(false)); }
  else if(cmd === '/report'){ tgSend(await reportText(true)); }
  else if(cmd === '/chart'){ await chartCmd(arg); }
  else if(cmd === '/trend'){ const a = parseFloat(String(arg).replace(/[$,\s]/g, ''));
    if(isFinite(a) && a >= 100){ ST.trendAcct = Math.round(a); stSave(); tgSend(`✓ Тренд системийн дансны хэмжээ $${ST.trendAcct} болгож тохирууллаа.`); }
    const R = trendGet(); tgSend(R ? TR.text(R, trendAcct(), (ST.trendLast || {}).now) + trendLiveText() : 'Тренд систем хараахан тооцогдоогүй — урт түүх татагдаж дуусах хүртэл хүлээнэ үү (/history).'); }
  else if(cmd === '/swing'){ const parts = String(arg || '').toUpperCase().split(/\s+/).filter(Boolean);
    const tfOf = x => /^(1H|H1|60)$/.test(x) ? '1h' : /^(4H|H4)$/.test(x) ? '4h' : /^(D|1D|DAY|1DAY|D1)$/.test(x) ? '1day' : null;
    const tf = parts.map(tfOf).find(Boolean) || '4h', rest = parts.filter(x => !tfOf(x)), a = rest[0] || '';
    if(a === 'OFF' || a === 'ON'){
      if(parts.some(tfOf)){ const M = new Set(ST.swMuteTf || []); if(a === 'OFF') M.add(tf); else M.delete(tf); ST.swMuteTf = [...M]; stSave(); tgSend(`${a === 'OFF' ? '🔕' : '🔔'} ${swTfl(tf)} дохио ${a === 'OFF' ? 'унтарлаа' : 'асаалаа'} (бүртгэл үргэлжилнэ).`); }
      else { ST.swMute = a === 'OFF'; stSave(); tgSend(ST.swMute ? '🔕 3 шүргэлтийн бүх дохио Telegram-аар ирэхгүй (бүртгэл үргэлжилнэ). /swing on — буцааж асаах.' : '🔔 3 шүргэлтийн дохио дахин ирнэ.'); } }
    else if(/^\$?\d/.test(a)){ const v = parseFloat(a.replace(/[$,]/g, '')); if(v >= 100){ ST.swAcct = Math.round(v); stSave(); tgSend(`✓ Swing системийн данс $${ST.swAcct}`); } }
    else if(a === 'TEST'){ tgSend(swingTestText(tf)); }
    else if(a){ const sym = CFG.histSymbols.find(s => s.replace(/[^A-Z]/g, '').includes(a.replace(/[^A-Z]/g, ''))); const A = sym && swingNowAll()[sym], N = A && A[tf];
      tgSend(N ? swingCheckText(N, swingAcct()) : `«${a}» — хослол олдсонгүй эсвэл тооцоо хийгдээгүй байна. Жишээ: /swing XAU 4h`); }
    else { const N = swingNowAll(); tgSend([swingTestText(tf), '', swingLiveText(), '', `Одоо (${swTfl(tf)}):`, ...CFG.histSymbols.map(s => { const K = swingCheck(N[s] && N[s][tf], swingAcct()); return ` • ${s}: ${K.verdict}`; }), '', '/swing XAU 1h — шалгах хуудас (1h / 4h / d) · /swing test d — тест · /swing off | on (· /swing 1h off) · /swing 5000 — данс'].join('\n')); } }
  else if(cmd === '/cal'){ if(/now|шинэ/i.test(arg)) await calFetch('Telegram'); tgSend(calText()); }
  else if(cmd === '/coach'){ const a = String(arg || '').trim().toLowerCase();
    if(a === 'off'){ ST.coachMute = true; stSave(); tgSend('🔕 Багшийн дохио Telegram-д ирэхгүй (апп дотор бүртгэлээ үргэлжлүүлнэ). Буцааж: /coach on'); }
    else if(a === 'on'){ ST.coachMute = false; stSave(); tgSend('🔔 Багшийн дохио асаалттай.'); }
    else { const t = await station.eval(() => window.__MP.coText && window.__MP.coText()); tgSend((t || 'Станц хариу өгөхгүй байна (апп v84-өөс хуучин уу?).') + (ST.coachMute ? '\n\n🔕 Telegram дохио чимээгүй байна — /coach on' : '\n\n/coach off — дохиог түр хаах')); } }
  else if(cmd === '/shot'){ const png = await shot(); if(png) tgSend('📷 Станцын одоогийн дэлгэц', {photo: png}); else tgSend('Станц одоогоор ачаалагдаагүй байна.'); }
  else if(cmd === '/restart'){ tgSend('🔄 Станцыг дахин ачаалж байна…'); await station.restart('Telegram /restart'); }
  else if(cmd === '/backup'){ const ok = await backupNow(true); if(ok) backupToTelegram('💾 Станцын нөөц (одоогийн)'); else tgSend('Нөөц хадгалж чадсангүй.'); }
  else if(cmd === '/history'){ tgSend(histText()); }
  else if(cmd === '/histtest'){ if(histTestBusy) tgSend('Түүхэн тест аль хэдийн явж байна.'); else histTest('Telegram', histPick(arg)); }
  else if(cmd === '/lifecycle' || cmd === '/lc'){ const t = await station.eval(() => window.__MP.lcText && window.__MP.lcText()); tgSend(t || 'Станц хариу өгөхгүй байна (эсвэл апп v77-оос хуучин).'); }
  else if(cmd === '/diag'){ const t = await station.eval(() => window.__MP.diagText && window.__MP.diagText()); tgSend(t || 'Станц одоогоор хариу өгөхгүй байна (эсвэл апп v74-өөс хуучин).'); }
  else tgSend('Командууд:\n/status — товч байдал\n/report — дэлгэрэнгүй тайлан\n/shot — станцын дэлгэцийн зураг\n/backup — одоо нөөцлөөд файлыг энд илгээх\n/restart — станцыг дахин ачаалах\n/history — урт түүхийн хамрах хүрээ\n/histtest — шалгагдсан бүх хослолыг урт түүхээр тестлэх (/histtest XAU — нэгийг)\n/diag — нөхцөлийн онош (аль нөхцөлд ажилладаг)\n/lifecycle — паттерны амьдралын мөчлөг (таамаглалууд H1–H6)\n/chart — графикийн зураг (/chart XAU 1h — өөр хослол, цаг)\n/trend — тренд системийн одоогийн байршил (/trend 5000 — дансны хэмжээ тохируулах)\n/swing — swing систем (3 шүргэлт): тест, дохио, шалгах хуудас (/swing XAU 4h · 1h · d)\n/coach — Багшийн дадлагын оролтууд (/coach off · on — дохио)\n/cal — ойрын чухал мэдээний хуанли');
}

// ---------------------------------------------------------------- candle store
const CS = new Map();   // key → {meta, rows: Map(datetime → [o,h,l,c,v]), dirty}
const csKey = (sym, iv) => `${String(sym).replace(/[^A-Za-z0-9]+/g, '_')}__${iv}`;
const csFile = k => path.join(DIRS.candles, k + '.json');
// v1.3: every stored time is UTC. Twelve Data answers forex/metals in
// Australia/Sydney time unless asked for timezone=UTC (crypto is UTC), so the
// station's requests always ask for UTC and candles stored by 1.2 or older are
// shifted once when their file is first read.
const TZ_RE = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?$/;
function tzOldOf(sym){ const s = String(sym || '').toUpperCase().split(':')[0];
  if(/^(BTC|ETH|LTC|XRP|SOL|ADA|DOGE|BNB|DOT|LINK|AVAX|TRX|XLM|BCH)\b/.test(s)) return null;
  return /^[A-Z]{3}\/[A-Z]{3}$/.test(s) ? 'Australia/Sydney' : null; }
const tzFmt = {};
function tzOffMin(tz, ms){ const F = tzFmt[tz] || (tzFmt[tz] = new Intl.DateTimeFormat('en-US', {timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'}));
  const p = {}; F.formatToParts(new Date(ms)).forEach(x => { p[x.type] = x.value; }); return (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second) - ms)/60000; }
function tzToUtc(str, tz){ const m = TZ_RE.exec(str); if(!m || !tz) return str;
  const wall = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)); let ms = wall - tzOffMin(tz, wall)*60000; ms = wall - tzOffMin(tz, ms)*60000;
  const d = new Date(ms), z = v => String(v).padStart(2, '0');
  return `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())} ${z(d.getUTCHours())}:${z(d.getUTCMinutes())}${m[6] !== undefined ? ':' + z(d.getUTCSeconds()) : ''}`; }
function csGet(k){
  if(CS.has(k)) return CS.get(k);
  let e = {meta: null, rows: new Map(), dirty: false};
  try{ const j = JSON.parse(fs.readFileSync(csFile(k), 'utf8')); e.meta = j.meta; (j.bars || []).forEach(b => e.rows.set(b[0], b.slice(1)));
    const tz = e.meta && !e.meta.utc ? tzOldOf(e.meta.symbol) : null;
    if(e.meta && !e.meta.utc){ if(tz){ const R = new Map(); for(const [d, r] of e.rows) R.set(tzToUtc(d, tz), r); e.rows = R; log('Лааны санг UTC руу шилжүүллээ:', k, e.rows.size, 'лаа'); } e.meta.utc = true; e.dirty = true; }
  }catch(x){}
  CS.set(k, e); return e;
}
function csPut(txt, url){
  let j; try{ j = JSON.parse(txt); }catch(e){ return; }
  if(!j || j.status === 'error' || !j.meta || !Array.isArray(j.values) || !j.values.length) return;
  if(!/[?&]timezone=UTC\b/i.test(url || '') && tzOldOf(j.meta.symbol)) return;   // not UTC — never mixed into the store
  const k = csKey(j.meta.symbol, j.meta.interval);
  const e = csGet(k); e.meta = {symbol: j.meta.symbol, interval: j.meta.interval, tz: j.meta.exchange_timezone || null, type: j.meta.type || null, utc: true};
  j.values.forEach(v => { if(v && v.datetime) e.rows.set(v.datetime, [+v.open, +v.high, +v.low, +v.close, +(v.volume || 0)]); });
  e.dirty = true;
}
function csFlush(){
  for(const [k, e] of CS){ if(!e.dirty) continue;
    const bars = [...e.rows.entries()].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0).slice(-250000).map(([d, r]) => [d, ...r]);
    try{ writeAtomic(csFile(k), JSON.stringify({meta: e.meta, n: bars.length, bars})); e.dirty = false; }catch(x){ log('Лаа хадгалж чадсангүй', k, x.message); }
  }
}
// Twelve Data closes of one symbol/interval from the candle store, as [{t: epoch s (datetime read as UTC), c}]
function tdStoreRows(sym, iv){
  const e = csGet(csKey(sym, iv)); if(!e || !e.rows.size) return [];
  return [...e.rows.entries()].map(([d, r]) => ({t: Math.round(Date.parse(d.replace(' ', 'T') + 'Z')/1000), c: r[3]})).filter(x => isFinite(x.t) && x.c > 0).slice(-3000);
}
let HIST = null;
function hist(){
  if(!HIST && CFG.history){ const {makeHist} = require('./hist'); HIST = makeHist({dir: DIRS.history, base: CFG.dukaBase, years: CFG.trendOn ? Math.max(CFG.histYears, CFG.trendYears) : CFG.histYears, symbols: CFG.trendOn ? [...new Set(CFG.histSymbols.concat(CFG.trendSymbols))] : CFG.histSymbols, log, tdStore: tdStoreRows, onEvent: t => tgSend(t), pauseMs: num(ENV.HIST_PAUSE_MS, 250)}); }
  return HIST;
}
function histText(){
  const Hh = hist(); if(!Hh) return 'Урт түүх унтраалттай (.env: HISTORY=0).';
  const L = ['📚 Урт түүх (Dukascopy)' + (Hh.busy && Hh.prog ? ` · татаж байна: ${Hh.prog.sym} ${Hh.prog.i}/${Hh.prog.n} өдөр` : '')];
  Hh.coverage().forEach(c => L.push(` • ${c.symbol}: ${c.days ? `${c.from} → ${c.to} (${c.days} өдөр)` : 'хараахан алга'} · ${c.verified ? '✓ шалгагдсан' : '… ' + (c.note || 'шалгагдаагүй')}${c.failing ? ` · ${c.failing} өдөр амжилтгүй${c.gaveUp ? ` (${c.gaveUp} нь 7 хоног хүлээж байна)` : ''}${c.lastErr ? `: ${c.lastErr}` : ''}` : ''}`));
  return L.join('\n');
}
// history test + forecast audit on the station, for every interval in HISTORY_TEST_INTERVALS
let histTestBusy = false;
// symbols for a history test: «/histtest» = every symbol whose long history is verified; «/histtest XAU» = matching ones
// ---------------------------------------------------------------- trend system (v1.8)
// the trend module lives inside server.js: an updater of 1.7 or older copies only its known files
const TR = (() => {
// =====================================================================
//  TREND SYSTEM — time-series momentum, the trading rule with the longest
//  published record (Moskowitz, Ooi & Pedersen 2012; Hurst, Ooi & Pedersen
//  "A Century of Evidence on Trend-Following Investing").
//
//  Rules (fixed in advance, nothing fitted to the data):
//   • signal of an instrument = average of the signs of its 1-, 3- and
//     12-month returns  → −1, −⅓, +⅓ or +1;
//   • size = signal × (risk budget ÷ the instrument's own volatility), so a
//     calm and a wild market carry the same risk (volatility targeting);
//     volatility = exponentially weighted daily returns (≈ 60-day centre);
//   • rebalanced once a week on the week's last close, a position is only
//     changed when its size moves by more than 20 % (fewer trading costs);
//   • every instrument gets the same risk budget; the whole portfolio is
//     scaled to 10 % annual volatility (a long-only portfolio is scaled the
//     same way as the benchmark);
//   • costs: spread on every change of size + a 1 %/yr financing mark-up
//     on the notional held (the interest-rate differential itself — "carry"
//     — is not modelled: it can add or subtract).
//  Daily bars come from the station's long history (Dukascopy, UTC days).
// =====================================================================
const LB = [21, 63, 252];                 // 1, 3, 12 months of trading days
const LAM = 60/61;                        // EWMA weight (centre of mass ≈ 60 days)
const TAU = 0.40;                         // per-instrument risk budget before the portfolio scale (AQR convention)
const TARGET = 0.10;                      // portfolio annual volatility
const BAND = 0.20;                        // trade only if size changes > 20 %
const FIN = 0.01;                         // financing (swap) mark-up per year on the notional held
const MAXLEV = 4;                         // cap on one instrument's notional ÷ account
// typical retail spread (price units) — the same scale the app uses, a little wider for crosses
const SPREAD = {XAU: 0.35, XAG: 0.035, BTC: 20, JPYX: 0.025, JPY: 0.015, X: 0.00015, CROSS: 0.0002};
function spreadOf(sym){ const s = String(sym).toUpperCase();
  if(s.startsWith('XAU')) return SPREAD.XAU; if(s.startsWith('XAG')) return SPREAD.XAG; if(s.startsWith('BTC')) return SPREAD.BTC;
  const [b, q] = s.split('/'); if(q === 'JPY') return b === 'USD' ? SPREAD.JPY : SPREAD.JPYX;
  return b === 'USD' || q === 'USD' ? SPREAD.X : SPREAD.CROSS; }
const isCrypto = s => /^(BTC|ETH)/.test(String(s).toUpperCase());
// contract size of 1 lot (MT4/MT5 convention)
const CONTRACT = s => { const u = String(s).toUpperCase(); return u.startsWith('XAU') ? 100 : u.startsWith('XAG') ? 5000 : isCrypto(u) ? 1 : 100000; };

// daily closes from the history module ('1day' in Twelve-Data shape, newest first)
function dailyOf(H, sym){
  const j = H.bars(sym, '1day', 0); if(!j || j.error || !Array.isArray(j.values)) return null;
  const B = j.values.map(v => ({t: Date.parse(v.datetime.replace(' ', 'T') + 'Z'), c: +v.close})).filter(b => isFinite(b.t) && b.c > 0).reverse();
  // a weekday bar with almost no trading (holiday stub) is dropped
  return B.length > 300 ? B : null;
}
const wk = t => { const d = new Date(t), day = (d.getUTCDay() + 6) % 7; return Math.floor((t - day*864e5)/(7*864e5)); };   // ISO-week id

// one instrument through time: daily return, ex-ante vol, signal, weekly target size (before the portfolio scale)
function instSeries(sym, B){
  const n = B.length, per = isCrypto(sym) ? 365 : 261, L = isCrypto(sym) ? LB.map(x => Math.round(x*365/261)) : LB;
  const out = []; let v = null;
  for(let i = 1; i < n; i++){
    const r = B[i].c/B[i-1].c - 1;
    v = v == null ? r*r : LAM*v + (1 - LAM)*r*r;
    const ok = i >= L[2] && i >= 60, sig = ok ? L.reduce((a, l) => a + Math.sign(B[i].c - B[i - l].c), 0)/L.length : 0;
    const vol = Math.sqrt(v*per);
    out.push({t: B[i].t, c: B[i].c, r, vol, sig, ok, last: i === n - 1 || wk(B[i+1].t) !== wk(B[i].t), comp: ok ? L.map(l => Math.sign(B[i].c - B[i - l].c)) : null, per});
  }
  return out;
}
// simulate: positions set on the week's last close, earning the following days' returns
function simulate(series, longOnly){
  const days = new Map();                 // date → {pnl, gross, n}
  const inst = {};
  Object.entries(series).forEach(([sym, S]) => {
    const sp = spreadOf(sym), per = S.length ? S[0].per : 261; let w = 0; const R = [];
    for(let i = 0; i < S.length; i++){
      const x = S[i];
      // today's return on yesterday's position
      const g = w*x.r, fin = Math.abs(w)*FIN/per;
      let cost = 0;
      if(x.last && x.ok && x.vol > 0){
        const tgt = Math.max(-MAXLEV, Math.min(MAXLEV, (longOnly ? 1 : x.sig)*TAU/x.vol));
        if(Math.abs(tgt - w) > BAND*Math.max(Math.abs(w), Math.abs(tgt)) || (tgt === 0) !== (w === 0)){ cost = Math.abs(tgt - w)*sp/x.c; w = tgt; }
      }
      const net = g - fin - cost, k = Math.floor(x.t/864e5);
      const D = days.get(k) || {pnl: 0, gross: 0, n: 0}; D.pnl += net; D.gross += g; D.n++; days.set(k, D);
      R.push({t: x.t, net, g});
    }
    inst[sym] = R;
  });
  return {days, inst};
}
function stats(P, per){
  const n = P.length; if(n < 50) return null;
  const m = P.reduce((a, b) => a + b, 0)/n, sd = Math.sqrt(P.reduce((a, b) => a + (b - m)*(b - m), 0)/(n - 1));
  let eq = 1, peak = 1, dd = 0; P.forEach(p => { eq *= 1 + p; peak = Math.max(peak, eq); dd = Math.max(dd, 1 - eq/peak); });
  const years = n/per, sr = sd > 0 ? m/sd*Math.sqrt(per) : 0;
  return {n, years: +years.toFixed(1), ann: +(m*per).toFixed(4), vol: +(sd*Math.sqrt(per)).toFixed(4), sharpe: +sr.toFixed(2), t: +(sr*Math.sqrt(years)).toFixed(2), maxDD: +dd.toFixed(4), total: +(eq - 1).toFixed(4)};
}
function run(H, syms, opt = {}){
  const series = {}, skipped = [];
  syms.forEach(s => { let B = null; try{ B = dailyOf(H, s); }catch(e){} if(!B){ skipped.push(s); return; } series[s] = instSeries(s, B); });
  const names = Object.keys(series); if(names.length < 2) return {error: 'хангалттай өдрийн түүх алга (2+ хэрэгсэл хэрэгтэй)', skipped};
  const simAndScale = longOnly => {
    const {days, inst} = simulate(series, longOnly);
    const keys = [...days.keys()].sort((a, b) => a - b);
    // the first day every instrument may hold a position (after its 12-month warm-up)
    const start = Math.max(...names.map(s => { const f = series[s].find(x => x.ok); return f ? Math.floor(f.t/864e5) : Infinity; }));
    const ks = keys.filter(k => k > start);
    const raw = ks.map(k => days.get(k).pnl/names.length), rawG = ks.map(k => days.get(k).gross/names.length);
    // observations per year from the calendar (crypto trades at weekends, so it is not 261)
    const per = ks.length > 1 ? ks.length/((ks[ks.length - 1] - ks[0] + 1)/365.25) : 261;
    const st0 = stats(raw, per), scale = st0 && st0.vol > 0 ? TARGET/st0.vol : 1;
    const P = raw.map(p => p*scale), G = rawG.map(p => p*scale);
    return {ks, P, G, scale, start, per};
  };
  const T = simAndScale(false), Bm = simAndScale(true);
  if(!T.P.length) return {error: 'тест хийх хугацаа хэт богино', skipped};
  const pp = T.per, all = stats(T.P, pp), gross = stats(T.G, pp), cut = Math.floor(T.P.length*0.6);
  const yearly = {}; T.ks.forEach((k, i) => { const y = new Date(k*864e5).getUTCFullYear(); yearly[y] = (yearly[y] || 1)*(1 + T.P[i]); });
  const years = Object.entries(yearly).map(([y, e]) => ({y: +y, r: +(e - 1).toFixed(4)}));
  // per-instrument Sharpe of its own (unscaled) trend P/L
  const perInst = names.map(s => { const S = series[s], first = S.findIndex(x => x.ok); const {inst} = simulate({[s]: S}, false); const P = inst[s].slice(first + 1).map(x => x.net); const st = stats(P, S[0].per); return {sym: s, sharpe: st ? st.sharpe : null, years: st ? st.years : 0}; });
  // equity curve (weekly points) for the chart
  const curve = []; let e = 1, eb = 1; T.ks.forEach((k, i) => { e *= 1 + T.P[i]; eb *= 1 + (Bm.P[i] || 0); if(i % 5 === 0 || i === T.ks.length - 1) curve.push([k, +e.toFixed(4), +eb.toFixed(4)]); });
  // ---- current positions: the last week's target, in "notional ÷ account" ----
  const now = names.map(s => {
    const S = series[s], x = S[S.length - 1];
    // the size held now = the target set on the last completed week's close
    // the newest bar counts as a week's end once its week is over (Friday close for FX, Sunday for crypto, or a later week has begun)
    const ended = q => { const dw = new Date(q.t).getUTCDay(); return wk(Date.now()) > wk(q.t) || (isCrypto(s) ? dw === 0 : dw === 5); };
    let j = S.length - 1; if(!ended(x)){ j--; while(j > 0 && !S[j].last) j--; }
    const y = S[j], w = y.ok && y.vol > 0 ? Math.max(-MAXLEV, Math.min(MAXLEV, y.sig*TAU/y.vol))*T.scale/names.length : 0;
    return {sym: s, t: y.t, price: y.c, sig: +y.sig.toFixed(3), comp: y.comp, vol: +y.vol.toFixed(4), w: +w.toFixed(4), contract: CONTRACT(s), spread: spreadOf(s), lastBar: x.t};
  });
  return {at: Date.now(), asOf: Math.max(...names.map(s => series[s][series[s].length - 1].t)), syms: names, skipped, scale: +T.scale.toFixed(4),
    rules: {LB, TARGET, BAND, FIN, TAU, MAXLEV},
    stats: all, gross, first: stats(T.P.slice(0, cut), pp), second: stats(T.P.slice(cut), pp), bench: stats(Bm.P, Bm.per),
    from: T.ks[0]*864e5, to: T.ks[T.ks.length - 1]*864e5, years, perInst, curve, now};
}
// USD value of one unit of the base currency (for lot sizes of crosses)
function baseUsd(sym, now){
  const [b, q] = String(sym).toUpperCase().split('/'); const px = s => (now.find(x => x.sym === s) || {}).price;
  if(q === 'USD') return px(sym); if(b === 'USD') return 1;
  if(px(b + '/USD')) return px(b + '/USD'); if(px('USD/' + b)) return 1/px('USD/' + b);
  return null;
}
// lots for an account (USD) — weight = notional ÷ account
function lotsFor(R, acct){
  return R.now.map(x => { const bu = baseUsd(x.sym, R.now), notional = x.w*acct, units = bu ? notional/bu : null, lots = units != null ? units/x.contract : null;
    return Object.assign({}, x, {notional: +notional.toFixed(0), lots: lots != null ? +lots.toFixed(2) : null, tooSmall: lots != null && Math.abs(lots) < 0.01 && x.w !== 0}); });
}
// smallest account at which every non-zero position is at least 0.01 lot
function minAccount(R){ let m = 0; R.now.forEach(x => { const bu = baseUsd(x.sym, R.now); if(!bu || !x.w) return; const need = 0.01*x.contract*bu/Math.abs(x.w); m = Math.max(m, need); }); return Math.ceil(m/100)*100; }

const pc = x => x == null ? '—' : (x >= 0 ? '+' : '') + (x*100).toFixed(1) + '%';
const arrow = s => s > 0.5 ? '▲▲' : s > 0 ? '▲' : s < -0.5 ? '▼▼' : s < 0 ? '▼' : '·';
function verdict(R){
  const s = R.stats, a = R.first, b = R.second; if(!s) return 'тест хийгдсэнгүй';
  if(s.sharpe > 0 && a && b && a.sharpe > 0 && b.sharpe > 0 && s.t >= 2) return '✓ эерэг — хоёр хугацааны хэсэгт ижил, статистикийн хувьд итгэлтэй (t ≥ 2)';
  if(s.sharpe > 0 && a && b && a.sharpe > 0 && b.sharpe > 0) return '≈ эерэг, хоёр хэсэгт ижил — гэхдээ статистикийн хувьд итгэл хангалтгүй (t < 2)';
  if(s.sharpe > 0) return '≈ эерэг ч хугацааны хэсэг бүрт биш';
  return '✕ энэ хугацаа, хэрэгслүүд дээр алдагдалтай';
}
function text(R, acct, prev){
  if(!R || R.error) return '📈 Тренд систем: ' + (R ? R.error : 'тооцоо хийгдээгүй');
  const s = R.stats, d = t => new Date(t).toISOString().slice(0, 10);
  const L = [`📈 Тренд систем (time-series momentum) · ${R.syms.length} хэрэгсэл`,
    `Түүхэн тест ${d(R.from)} → ${d(R.to)} (${s.years} жил), зардал хассан, 10%-ийн хэлбэлзэлд тааруулсан:`,
    ` жилд ${pc(s.ann)} · Sharpe ${s.sharpe} (t=${s.t}) · хамгийн их уналт −${(s.maxDD*100).toFixed(1)}%`,
    ` эхний 60% / сүүлийн 40%: Sharpe ${R.first ? R.first.sharpe : '—'} / ${R.second ? R.second.sharpe : '—'} · зөвхөн LONG барьсан бол Sharpe ${R.bench ? R.bench.sharpe : '—'}`,
    ` зардалгүй бол жилд ${pc(R.gross ? R.gross.ann : null)} — спред ба swap-ийн нөлөө жилд ${pc(R.gross ? s.ann - R.gross.ann : null)}`,
    ` → ${verdict(R)}`,
    '', `Одоогийн байршил (${d(R.asOf)} хаалтаар, данс $${acct}):`];
  lotsFor(R, acct).sort((a, b) => Math.abs(b.w) - Math.abs(a.w)).forEach(x => {
    const p = prev && prev.find(y => y.sym === x.sym), ch = !p ? '' : Math.sign(p.w) !== Math.sign(x.w) ? (x.w === 0 ? ' ⟵ ХААХ' : p.w === 0 ? ' ⟵ ШИНЭ' : ' ⟵ ЭРГҮҮЛЭХ') : Math.abs(x.w - p.w) > BAND*Math.max(Math.abs(x.w), Math.abs(p.w)) ? ' ⟵ хэмжээ өөрчлөх' : '';
    L.push(` ${arrow(x.sig)} ${x.sym}: ${x.w === 0 ? 'байршилгүй' : (x.w > 0 ? 'LONG ' : 'SHORT ') + (x.tooSmall ? '<0.01 лот — данс бага тул алгас' : x.lots != null ? Math.abs(x.lots).toFixed(2) + ' лот' : '')}${ch}`); });
  const ma = minAccount(R); L.push('', `Бүх байршлыг 0.01 лотоор нээх хамгийн бага данс ≈ $${ma}. Шинэчлэх: даваа гаригт зах нээгдэхэд. Гарын авлага: апп → 📈 Тренд систем.`, 'Санхүүгийн зөвлөгөө биш — түүхэн үр дүн ирээдүйг баталгаажуулахгүй.');
  return L.join('\n');
}
return {run, text, lotsFor, minAccount, verdict, spreadOf, CONTRACT};
})();
// ---------------------------------------------------------------- v1.9 swing system («3 шүргэлт»)
// =====================================================================
//  SWING SYSTEM (v1.9) — the rules of a swing method written as code.
//  Core, fully mechanical rule («3 шүргэлт»):
//    • a support / resistance line that price has tested at least 3 times
//      (3 swing points on the line, no candle CLOSE beyond it in between)
//    • the first 4-hour close beyond that line → enter in the break's direction
//    • SL a fixed distance away (2 × 4H ATR), TP 4 × that distance (1:4)
//    • nothing is moved; one position per market at a time; 1 % risk
//  The other rules of the method are recorded at every signal as
//  confirmations, so the test can show whether they improve the result:
//    D Dow trend agrees · D pitchfork direction agrees · W Dow agrees ·
//    breakout volume above its average · 4 or more touches.
//  Everything at bar i uses only bars up to i (swings are known K bars
//  after they happen) — no hindsight.
// =====================================================================
const SW = (() => {
const C = {K: 5, KD: 2, WIN: 300, TOL: 0.35, BRK: 0.10, MINT: 3, SLK: 2.0, RR: 4, MAXH: 360, SLIP: 0.2, FIN: 0.01};
const H4 = 4*36e5, DAYMS = 864e5;
// the timeframes the rule runs on: bar length, fewest 1H bars in a bar, longest hold
const TFS = {'1h': {ms: 36e5, minN: 1, maxDays: 20, lbl: '1H'}, '4h': {ms: H4, minN: 2, maxDays: 60, lbl: '4H'}, '1day': {ms: DAYMS, minN: 6, maxDays: 180, lbl: 'D'}};
// F (1H, weekend removed) → the bars of tf, the daily and the weekly bars
function frames(F, sym, tf){
  const D = agg(F, DAYMS).filter(b => b.n >= 6 || isCry(sym)), W = agg(D, 7*DAYMS, 4*DAYMS);
  const B = tf === '1h' ? F.map(b => Object.assign({}, b, {n: 1, e: b.t})) : tf === '1day' ? D : agg(F, H4).filter(b => b.n >= 2);
  return {B, D, W};
}
const isCry = s => /^(BTC|ETH)/.test(String(s).toUpperCase());

// ---------- bars ----------
// Twelve-Data-shaped json (newest first) → [{t, o, h, l, c, v}] oldest first
function fromTd(j){
  if(!j || j.error || !Array.isArray(j.values)) return [];
  return j.values.map(v => ({t: Date.parse(String(v.datetime).replace(' ', 'T') + 'Z'), o: +v.open, h: +v.high, l: +v.low, c: +v.close, v: +(v.volume || 0)}))
    .filter(b => isFinite(b.t) && b.c > 0 && b.h >= b.l).reverse();
}
// merge two ascending series by time; b wins after a's last bar
function merge(a, b){
  if(!a.length) return b.slice(); if(!b.length) return a.slice();
  const last = a[a.length - 1].t; return a.concat(b.filter(x => x.t > last));
}
// fixed UTC buckets (4H: 00, 04, 08 … ; D: UTC day). Weekend FX stubs are left out by the caller.
function agg(B, ms, off = 0){
  const out = []; let cur = null;
  for(const x of B){ const k = Math.floor((x.t - off)/ms)*ms + off;
    if(!cur || cur.t !== k){ if(cur) out.push(cur); cur = {t: k, o: x.o, h: x.h, l: x.l, c: x.c, v: x.v, n: 1, e: x.t, s: x.s}; }
    else{ cur.h = Math.max(cur.h, x.h); cur.l = Math.min(cur.l, x.l); cur.c = x.c; cur.v += x.v; cur.n++; cur.e = x.t; if(cur.s !== x.s) cur.s = 'm'; } }
  if(cur) out.push(cur); return out;
}
// FX / metals: no bars inside the weekly close (Fri 21:00 → Sun 21:00 UTC, a fixed approximation)
function dropWeekend(B, sym){
  if(isCry(sym)) return B;
  return B.filter(b => { const d = new Date(b.t), wd = d.getUTCDay(), h = d.getUTCHours(); return !(wd === 6 || (wd === 5 && h >= 21) || (wd === 0 && h < 21)); });
}
function atrS(B, n = 14){
  const A = new Array(B.length).fill(0); let a = null;
  for(let i = 1; i < B.length; i++){ const tr = Math.max(B[i].h - B[i].l, Math.abs(B[i].h - B[i-1].c), Math.abs(B[i].l - B[i-1].c)); a = a == null ? tr : (a*(n - 1) + tr)/n; A[i] = a; }
  A[0] = A[1] || (B[0] ? B[0].h - B[0].l : 0); return A;
}
// fractal swings: a high above the K bars on each side; known («at») K bars later
function pivots(B, K){
  const P = [];
  for(let i = K; i < B.length - K; i++){
    let hi = true, lo = true;
    for(let k = 1; k <= K; k++){ if(!(B[i].h > B[i-k].h && B[i].h >= B[i+k].h)) hi = false; if(!(B[i].l < B[i-k].l && B[i].l <= B[i+k].l)) lo = false; if(!hi && !lo) break; }
    if(hi) P.push({i, p: B[i].h, t: 'H', at: i + K});
    if(lo) P.push({i, p: B[i].l, t: 'L', at: i + K});
  }
  return P;
}

// ---------- Dow + pitchfork on a higher timeframe (known pivots only) ----------
// trend from the last two highs and lows: +1 HH+HL, −1 LH+LL, 0 otherwise
function dowOf(P){
  const H = P.filter(x => x.t === 'H').slice(-2), L = P.filter(x => x.t === 'L').slice(-2);
  if(H.length < 2 || L.length < 2) return 0;
  if(H[1].p > H[0].p && L[1].p > L[0].p) return 1;
  if(H[1].p < H[0].p && L[1].p < L[0].p) return -1;
  return 0;
}
// pitchfork from the last three alternating swings A, B, C: median from A to the middle of B–C
function forkOf(P){
  const Q = []; for(const x of P){ if(Q.length && Q[Q.length - 1].t === x.t){ const y = Q[Q.length - 1]; if((x.t === 'H' && x.p >= y.p) || (x.t === 'L' && x.p <= y.p)) Q[Q.length - 1] = x; } else Q.push(x); }
  if(Q.length < 3) return null;
  const [A, B, Cc] = Q.slice(-3), mi = (B.i + Cc.i)/2, mp = (B.p + Cc.p)/2;
  if(!(mi > A.i)) return null;
  const slope = (mp - A.p)/(mi - A.i);
  return {A, B, C: Cc, slope, dir: slope > 0 ? 1 : slope < 0 ? -1 : 0, at: (i) => A.p + slope*(i - A.i)};
}
// a higher-timeframe context that can be asked «what was known at time t»
function htf(Bh, K){
  const P = pivots(Bh, K), A = atrS(Bh);
  return {B: Bh, P, A, idx: t => { let lo = 0, hi = Bh.length - 1, r = -1; while(lo <= hi){ const m = (lo + hi) >> 1; if(Bh[m].t + (Bh[m].e != null ? 0 : 0) <= t){ r = m; lo = m + 1; } else hi = m - 1; } return r; }};
}
// the context at 4H bar end time tEnd: only HTF bars that CLOSED before it, and pivots already confirmed
function htfAt(X, tEnd, span){
  let j = X.idx(tEnd - span) ; // last HTF bar that started at least one HTF bar before → closed
  if(j < 0) return null;
  const P = X.P.filter(p => p.at <= j);
  const fk = forkOf(P);
  return {dow: dowOf(P), fork: fk ? fk.dir : 0, forkObj: fk, j, P};
}

// ---------- the 3-touch line engine over 4H bars ----------
// returns every break of a line with ≥ MINT touches (no position logic here)
function lineBreaks(B, A, opt = {}){
  const K = opt.K || C.K, WIN = opt.WIN || C.WIN, TOL = opt.TOL || C.TOL, BRK = opt.BRK || C.BRK, MINT = opt.MINT || C.MINT;
  const P = pivots(B, K), n = B.length, byAt = new Map(); P.forEach(p => { if(!byAt.has(p.at)) byAt.set(p.at, []); byAt.get(p.at).push(p); });
  const known = {H: [], L: []}, act = [], out = [];
  const val = (ln, i) => ln.p1 + ln.s*(i - ln.i1);
  for(let i = 1; i < n; i++){
    // 1) breaks at this bar's close (lines built from swings known before this bar)
    const best = {1: null, '-1': null};
    for(let q = act.length - 1; q >= 0; q--){ const ln = act[q], v = val(ln, i), a = A[i] || A[i-1];
      const beyond = ln.t === 'H' ? B[i].c > v + BRK*a : B[i].c < v - BRK*a;
      if(beyond){ act.splice(q, 1); if(ln.n >= MINT){ const d = ln.t === 'H' ? 1 : -1, cur = best[d]; if(!cur || ln.n > cur.n || (ln.n === cur.n && ln.last > cur.last)) best[d] = Object.assign({}, ln, {v}); } continue; }
      if(i - ln.last > WIN) act.splice(q, 1); }
    [1, -1].forEach(d => { const ln = best[d]; if(ln) out.push({i, d, n: ln.n, v: ln.v, i1: ln.i1, i2: ln.i2, p1: ln.p1, s: ln.s, last: ln.last, t: ln.t, slope: ln.s}); });
    // 2) swings confirmed by this bar: touches of live lines, then new lines
    const nw = byAt.get(i) || [];
    for(const p of nw){
      for(const ln of act) if(ln.t === p.t && p.i > ln.i2){ const v = val(ln, p.i), a = A[p.i] || a0(A); if(Math.abs(p.p - v) <= TOL*a){ ln.n++; ln.last = p.i; } }
      const L = known[p.t];
      for(let z = L.length - 1; z >= 0; z--){ const q = L[z]; if(q.i < p.i - WIN) break; if(p.i - q.i < 2*K) continue;
        const s = (p.p - q.p)/(p.i - q.i), ln = {t: p.t, i1: q.i, p1: q.p, i2: p.i, s, n: 2, last: p.i};
        let ok = true;
        // no close beyond the line from its first swing to now, and no swing of the same kind piercing it
        for(let k = q.i; k <= i && ok; k++){ const v = val(ln, k), a = A[k] || a0(A); if(p.t === 'H' ? B[k].c > v + TOL*a : B[k].c < v - TOL*a) ok = false; }
        if(!ok) continue;
        for(const r of L) if(r.i > q.i && r.i < p.i){ const v = val(ln, r.i), a = A[r.i] || a0(A); const dv = (r.p - v)*(p.t === 'H' ? 1 : -1);
          if(dv > TOL*a){ ok = false; break; } if(Math.abs(dv) <= TOL*a) ln.n++; }
        if(ok) act.push(ln); }
      L.push(p);
    }
    // keep the line set small: drop weakest duplicates (same kind, nearly same value now)
    if(act.length > 400){ act.sort((x, y) => y.n - x.n || y.last - x.last); act.length = 300; }
  }
  return {breaks: out, active: act, P};
}
const a0 = A => { for(let k = A.length - 1; k >= 0; k--) if(A[k] > 0) return A[k]; return 1; };

// ---------- one trade on fine (1H) bars after the 4H close ----------
function resolve(F, fromT, s, maxMs){
  let lo = 0, hi = F.length - 1, k = F.length;
  while(lo <= hi){ const m = (lo + hi) >> 1; if(F[m].t >= fromT){ k = m; hi = m - 1; } else lo = m + 1; }
  let mfe = 0, mae = 0;
  for(; k < F.length; k++){ const b = F[k];
    if(b.t - fromT > maxMs) return {res: 'exp', px: b.o, t: b.t, mfe, mae};
    const fav = ((s.d > 0 ? b.h : b.l) - s.e)*s.d/s.risk, adv = ((s.d > 0 ? b.l : b.h) - s.e)*s.d/s.risk; if(fav > mfe) mfe = fav; if(adv < mae) mae = adv;
    const hitSL = s.d > 0 ? b.l <= s.sl : b.h >= s.sl, hitTP = s.d > 0 ? b.h >= s.tp : b.l <= s.tp;
    if(hitSL){ const gap = s.d > 0 ? b.o < s.sl : b.o > s.sl; return {res: 'loss', px: gap ? b.o : s.sl, t: b.t, mfe, mae: Math.max(-1.5, mae)}; }   // SL and TP in one bar → loss
    if(hitTP) return {res: 'win', px: s.tp, t: b.t, mfe, mae};
  }
  return {res: 'open', px: F.length ? F[F.length - 1].c : s.e, t: F.length ? F[F.length - 1].t : fromT, mfe, mae, open: true};
}

// ---------- the system over one market's history ----------
// F = 1H bars (oldest first). spread = typical spread in price units.
function run(sym, F, spread, opt = {}){
  F = dropWeekend(F, sym);
  const tf = TFS[opt.tf] ? opt.tf : '4h', T = TFS[tf], {B, D, W} = frames(F, sym, tf), A = atrS(B), BAR = T.ms, maxD = opt.maxDays || T.maxDays;
  if(B.length < 400 || D.length < 60) return null;
  const XD = htf(D, C.KD), XW = htf(W, C.KD), LB = lineBreaks(B, A, opt), sig = [];
  let busyT = -Infinity;
  const vAvg = i => { let s = 0, k = 0; for(let q = Math.max(0, i - 20); q < i; q++){ s += B[q].v; k++; } return k ? s/k : 0; };
  for(const br of LB.breaks){
    const i = br.i, end = B[i].t + BAR; if(end <= busyT) continue;
    const a = A[i]; if(!(a > 0)) continue;
    const d = br.d, e = B[i].c, risk = C.SLK*a, sl = e - d*risk, tp = e + d*C.RR*risk;
    const cd = htfAt(XD, end, DAYMS), cw = htfAt(XW, end, 7*DAYMS), va = vAvg(i);
    const R0 = resolve(F, end, {d, e, sl, tp, risk}, maxD*DAYMS);
    const days = Math.max(0, (R0.t - end)/DAYMS), g = (R0.px - e)*d/risk;
    const cost = ((1 + C.SLIP)*spread)/risk + C.FIN*e*days/365/risk, R = g - cost;
    sig.push({sym, tf, t: end, i, d, e, sl, tp, risk, n: br.n, res: R0.res, R: +R.toFixed(3), Rg: +g.toFixed(3), cost: +cost.toFixed(3), days: +days.toFixed(1),
      mfe: +R0.mfe.toFixed(2), mae: +R0.mae.toFixed(2), open: !!R0.open,
      f: {dD: cd ? cd.dow*d : 0, fD: cd ? cd.fork*d : 0, dW: cw ? cw.dow*d : 0, vol: va > 0 ? +(B[i].v/va).toFixed(2) : null, t4: br.n >= 4 ? 1 : 0}});
    busyT = R0.open ? Infinity : R0.t;
  }
  // baseline: random 4H closes, random direction, the same 1:4 bracket and costs
  let seed = 7919 + sym.length*31; const rnd = () => { seed = (seed*1103515245 + 12345) % 2147483648; return seed/2147483648; };
  const base = [], nB = Math.max(300, sig.length*4);
  for(let q = 0; q < nB; q++){ const i = 100 + Math.floor(rnd()*(B.length - 140)), a = A[i]; if(!(a > 0)) continue; const d = rnd() < 0.5 ? 1 : -1, e = B[i].c, risk = C.SLK*a, end = B[i].t + BAR;
    const R0 = resolve(F, end, {d, e, sl: e - d*risk, tp: e + d*C.RR*risk, risk}, maxD*DAYMS); if(R0.open) continue;
    const days = Math.max(0, (R0.t - end)/DAYMS); base.push((R0.px - e)*d/risk - ((1 + C.SLIP)*spread)/risk - C.FIN*e*days/365/risk); }
  return {sym, tf, from: B[0].t, to: B[B.length - 1].t, bars4: B.length, sigs: sig, base};
}

// ---------- statistics ----------
function stat(R){
  const n = R.length; if(!n) return {n: 0};
  const m = R.reduce((a, b) => a + b, 0)/n, sd = n > 1 ? Math.sqrt(R.reduce((a, b) => a + (b - m)*(b - m), 0)/(n - 1)) : 0;
  let eq = 0, pk = 0, dd = 0, st = 0, ws = 0; R.forEach(r => { eq += r; pk = Math.max(pk, eq); dd = Math.max(dd, pk - eq); if(r < 0){ st++; ws = Math.max(ws, st); } else st = 0; });
  return {n, wr: +(R.filter(r => r > 0).length/n).toFixed(3), m: +m.toFixed(3), ci: +(1.96*sd/Math.sqrt(n)).toFixed(3), sum: +R.reduce((a, b) => a + b, 0).toFixed(1), dd: +dd.toFixed(1), streak: ws};
}
// the rule sets compared: the bare rule, then adding the method's confirmations one by one
const SETS = [
  {k: 'all', n: 'Үндсэн дүрэм (3 шүргэлт → эвдрэл)', f: s => true},
  {k: 'dD', n: '+ D Доу трендийн дагуу', f: s => s.f.dD > 0},
  {k: 'dDfD', n: '+ D Доу + D сэрээ дагуу', f: s => s.f.dD > 0 && s.f.fD > 0},
  {k: 'dDdW', n: '+ D Доу + W Доу дагуу', f: s => s.f.dD > 0 && s.f.dW > 0},
  {k: 'dDv', n: '+ D Доу + volume дунджаас их', f: s => s.f.dD > 0 && s.f.vol != null && s.f.vol >= 1},
  {k: 'full', n: 'Бүх баталгаа (D Доу + сэрээ + volume)', f: s => s.f.dD > 0 && s.f.fD > 0 && s.f.vol != null && s.f.vol >= 1},
  {k: 'anti', n: 'Харьцуулалт: D Доугийн ЭСРЭГ', f: s => s.f.dD < 0},
  {k: 't4', n: 'Харьцуулалт: 4+ шүргэлттэй шугам', f: s => s.f.t4 === 1}];
// pooled report over many markets; time split 60/40 by date across the whole pool
function report(runs){
  const R = runs.filter(Boolean); if(!R.length) return {error: 'түүх хангалтгүй'};
  const all = [].concat(...R.map(r => r.sigs.filter(s => !s.open))).sort((a, b) => a.t - b.t);
  const cutT = all.length ? all[Math.floor(all.length*0.6)].t : 0;
  const sets = SETS.map(S => { const L = all.filter(S.f), A = L.filter(s => s.t < cutT), Bq = L.filter(s => s.t >= cutT);
    const st = stat(L.map(s => s.R)); return Object.assign({k: S.k, name: S.n}, st, {mA: stat(A.map(s => s.R)).m, nA: A.length, mB: stat(Bq.map(s => s.R)).m, nB: Bq.length, gross: L.length ? +(L.reduce((a, s) => a + s.Rg, 0)/L.length).toFixed(3) : 0}); });
  const base = stat([].concat(...R.map(r => r.base)));
  const years = all.length ? (all[all.length - 1].t - all[0].t)/(365.25*DAYMS) : 0;
  // per market, with the same calendar split as the pool (first 60 % of the pooled trades' time / the rest)
  const perSym = R.map(r => { const L = r.sigs.filter(s => !s.open), st = stat(L.map(s => s.R)), f = stat(L.filter(SETS[5].f).map(s => s.R)), dd = stat(L.filter(SETS[1].f).map(s => s.R));
    const a = stat(L.filter(s => s.t < cutT).map(s => s.R)), b = stat(L.filter(s => s.t >= cutT).map(s => s.R));
    return {sym: r.sym, n: st.n, m: st.m, ci: st.ci, wr: st.wr, nF: f.n, mF: f.m, nD: dd.n, mD: dd.m, nA: a.n, mA: a.m || 0, nB: b.n, mB: b.m || 0, from: r.from, to: r.to}; });
  // the example year of the method (USD/JPY, 2022): number of trades and pips with the bare rule
  const ex = (() => { const r = R.find(x => x.sym === 'USD/JPY'); if(!r) return null; const y0 = Date.UTC(2022, 0, 1), y1 = Date.UTC(2023, 0, 7);
    const L = r.sigs.filter(s => s.t >= y0 && s.t < y1 && !s.open); if(!L.length) return null; const pip = 0.01;
    return {n: L.length, wins: L.filter(s => s.res === 'win').length, pips: Math.round(L.reduce((a, s) => a + s.R*s.risk/pip, 0)), avgSl: Math.round(L.reduce((a, s) => a + s.risk/pip, 0)/L.length)}; })();
  return {at: Date.now(), tf: R[0].tf, syms: R.map(r => r.sym), years: +years.toFixed(1), perYear: years > 0 ? +(all.length/years).toFixed(1) : 0, cutT, sets, base, perSym, ex, rules: {SLK: C.SLK, RR: C.RR, MINT: C.MINT, K: C.K, TOL: C.TOL, WIN: C.WIN}};
}
function verdict(s, base){
  if(!s || s.n < 30) return 'цөөн — дүгнэхэд эрт';
  const pos = s.mA > 0 && s.mB > 0;
  if(s.m - s.ci > 0 && pos) return '✓ эерэг — хоёр хугацааны хэсэгт ижил, статистикийн хувьд итгэлтэй';
  if(s.m - s.ci > 0) return '≈ эерэг, гэхдээ хугацааны хэсэг бүрт биш';
  if(s.m + s.ci < 0) return '✕ алдагдалтай — батлагдсан';
  return s.m > 0 ? '≈ эерэг талдаа — батлагдаагүй' : '≈ тэгтэй ойролцоо / сөрөг — давуу тал алга';
}

// ---------- live: the state of one market now ----------
// lines near price, the last break, the method checklist and today's plan
function now(sym, F, spread, tfIn){
  F = dropWeekend(F, sym);
  const tf = TFS[tfIn] ? tfIn : '4h', BAR = TFS[tf].ms, {B, D, W} = frames(F, sym, tf), A = atrS(B);
  if(B.length < 120 || D.length < 30) return {sym, tf, error: 'түүх хангалтгүй'};
  const n = B.length, last = B[n - 1], lastClosed = Date.now() >= last.t + BAR ? n - 1 : n - 2;   // the bar still forming is not used
  const Bc = B.slice(0, lastClosed + 1), Ac = A.slice(0, lastClosed + 1);
  const LB = lineBreaks(Bc, Ac), a = Ac[Ac.length - 1], px = F[F.length - 1].c, i = Bc.length - 1, end = Bc[i].t + BAR;
  const XD = htf(D, C.KD), XW = htf(W, C.KD), cd = htfAt(XD, Date.now(), DAYMS), cw = htfAt(XW, Date.now(), 7*DAYMS);
  const val = (ln, k) => ln.p1 + ln.s*(k - ln.i1);
  const lines = LB.active.filter(ln => ln.n >= C.MINT).map(ln => ({t: ln.t, n: ln.n, v: val(ln, i), dist: +((val(ln, i) - px)/a).toFixed(2), s: ln.s, i1: ln.i1, t1: Bc[ln.i1].t, tl: Bc[ln.last].t}))
    .sort((x, y) => Math.abs(x.dist) - Math.abs(y.dist))
    // near-copies of one line (other swing pairs on the same edge): keep the one with the most touches
    .reduce((acc, l) => { const dup = acc.findIndex(m => m.t === l.t && Math.abs(m.dist - l.dist) < 0.4 && Math.abs(m.s - l.s) < 0.25*a); if(dup < 0) acc.push(l); else if(l.n > acc[dup].n) acc[dup] = l; return acc; }, []);
  const near = {up: lines.find(l => l.t === 'H' && l.dist >= 0) || null, dn: lines.find(l => l.t === 'L' && l.dist <= 0) || null};
  const lb = LB.breaks.length ? LB.breaks[LB.breaks.length - 1] : null;
  const fresh = lb && lb.i === i ? lb : null;
  // volume only when the 21 bars come from one data source (the long history and the live feed count volume differently)
  const vAvg = (() => { let s = 0, k = 0; for(let q = Math.max(0, i - 20); q < i; q++){ if(Bc[q].s !== Bc[i].s || Bc[q].s === 'm') return 0; s += Bc[q].v; k++; } return k ? s/k : 0; })();
  const dD = cd ? cd.dow : 0, fD = cd ? cd.fork : 0, dW = cw ? cw.dow : 0;
  const plan = d => { const e = px, risk = C.SLK*a; return {d, e, sl: e - d*risk, tp: e + d*C.RR*risk, risk}; };
  const sig = fresh ? Object.assign(plan(fresh.d), {e: Bc[i].c, sl: Bc[i].c - fresh.d*C.SLK*a, tp: Bc[i].c + fresh.d*C.RR*C.SLK*a, n: fresh.n, t: end,
    f: {dD: dD*fresh.d, fD: fD*fresh.d, dW: dW*fresh.d, vol: vAvg > 0 ? +(Bc[i].v/vAvg).toFixed(2) : null}}) : null;
  // the D pitchfork now: where price is against its median
  let fork = null; if(cd && cd.forkObj){ const fk = cd.forkObj, jd = D.length - 1, med = fk.at(jd); fork = {dir: fk.dir, med, pos: Math.sign(px - med), A: fk.A.p, B: fk.B.p, C: fk.C.p, dist: +((px - med)/(XD.A[jd] || a)).toFixed(2)}; }
  // 4H Dow (is the 4H in a correction against D? — the «rest» the method waits for)
  const P4 = pivots(Bc, C.K).filter(p => p.at <= i), d4 = dowOf(P4);
  // a small picture: the last 150 closed 4H bars and the strongest lines near price (as two end points)
  const z0 = Math.max(0, i - 149), chart = {t0: Bc[z0].t, bars: Bc.slice(z0).map(b => [b.t, b.o, b.h, b.l, b.c]),
    lines: [near.up, near.dn, ...lines.filter(l => l !== near.up && l !== near.dn && l.n >= 4).slice(0, 1)].filter(Boolean).map(l => { const s0 = Math.max(z0, l.i1); return {t: l.t, n: l.n, x0: s0 - z0, y0: l.v - l.s*(i - s0), x1: i - z0, y1: l.v}; })};
  return {sym, tf, tfl: TFS[tf].lbl, at: Date.now(), px, atr4: a, bar4: Bc[i].t, dD, dW, fD, d4, fork, lines: lines.slice(0, 6), near, sig, chart, lastBreak: lb ? {t: Bc[lb.i].t + BAR, d: lb.d, n: lb.n, ago: i - lb.i} : null, spread, rules: {SLK: C.SLK, RR: C.RR}};
}
return {run, report, verdict, now, stat, resolve, TFS, SETS, C, agg, pivots, lineBreaks, dowOf, forkOf, fromTd, merge, dropWeekend};
})();
const spreadOf = TR.spreadOf, CONTRACT = TR.CONTRACT;   // typical spread and lot size (from the trend module)
const SWING_FILE = path.join(DATA, 'swing.json'), SWING_LIVE = path.join(DATA, 'swing-live.json'), SWING_NOW = path.join(DATA, 'swing-now.json');
let SWING = null, SWNOW = null, swingBusy = false;
const SW_TFS = ['1h', '4h', '1day'], swTfl = tf => (SW.TFS[tf] || SW.TFS['4h']).lbl;
// stored test: {byTf: {'1h': {R, sigs}, …}}; a 1.9 file (one 4H test) is read as 4H
function swTest(tf){ const S = swingGet(); if(!S) return null; if(S.byTf) return S.byTf[tf] || null; return tf === '4h' ? S : null; }
function swingGet(){ if(!SWING){ try{ SWING = JSON.parse(fs.readFileSync(SWING_FILE, 'utf8')); }catch(e){} } return SWING; }
function swingLive(){ try{ return JSON.parse(fs.readFileSync(SWING_LIVE, 'utf8')); }catch(e){ return []; } }
function swingNowAll(){ if(!SWNOW){ try{ SWNOW = JSON.parse(fs.readFileSync(SWING_NOW, 'utf8')); }catch(e){ SWNOW = {}; } } return SWNOW; }
const swingAcct = () => ST.swAcct || ST.trendAcct || CFG.trendAcct;
// 1H bars of a market: the long (Dukascopy) history, then the Twelve Data candles the station keeps
function sw1h(sym, lim){
  const Hh = hist(); let a = [];
  if(Hh){ try{ const cov = Hh.coverage().find(c => c.symbol === sym); if(cov && cov.verified) a = SW.fromTd(Hh.bars(sym, '1h', lim || 0)).map(b => Object.assign(b, {s: 'd'})); }catch(e){} }
  let b = [];
  try{ const e = csGet(csKey(sym, '1h')); if(e && e.rows.size) b = [...e.rows.entries()].map(([d, r]) => ({t: Date.parse(String(d).replace(' ', 'T') + 'Z'), o: +r[0], h: +r[1], l: +r[2], c: +r[3], v: +(r[4] || 0), s: 't'})).filter(x => isFinite(x.t) && x.c > 0 && x.h >= x.l).sort((x, y) => x.t - y.t); }catch(e){}
  return SW.merge(a, b);
}
// last known price of a market (for lot sizes of crosses)
function swPx(sym){ const A = swingNowAll()[sym], N = A && (A['4h'] || A['1h'] || A.px && A); if(N && N.px) return N.px; for(const iv of ['1h', '15min']){ const r = tdStoreRows(sym, iv); if(r.length) return r[r.length - 1].c; } return null; }
// USD value of a 1.0 price move on one unit
function swQuoteUsd(sym){
  const [b, q] = String(sym).toUpperCase().split('/'); if(q === 'USD') return 1;
  if(b === 'USD'){ const p = swPx(sym); return p ? 1/p : null; }
  const p1 = swPx('USD/' + q); if(p1) return 1/p1; const p2 = swPx(q + '/USD'); if(p2) return p2; return null;
}
// lots for a stop distance at 1 % of the account
function swLots(sym, risk, acct){ const qu = swQuoteUsd(sym); if(!qu || !(risk > 0)) return null; const l = acct*0.01/(risk*qu*CONTRACT(sym)); return +l.toFixed(2); }
// the history test over every market with a verified long history
async function swingCompute(why){
  if(swingBusy) return null; const Hh = hist(); if(!Hh) return null; swingBusy = true;
  try{
    const syms = Hh.coverage().filter(c => c.verified && (CFG.histSymbols.includes(c.symbol) || CFG.trendSymbols.includes(c.symbol))).map(c => c.symbol);
    if(!syms.length) return null;
    const runs = {}; SW_TFS.forEach(tf => { runs[tf] = []; });
    for(const s of syms){ let F; try{ F = sw1h(s); }catch(e){ log('Swing тест:', s, e.message); continue; }
      for(const tf of SW_TFS){ try{ runs[tf].push(SW.run(s, F, spreadOf(s), {tf})); }catch(e){ log('Swing тест:', s, tf, e.message); } }
      F = null; await sleep(50); }
    const byTf = {};
    for(const tf of SW_TFS){ const R = SW.report(runs[tf]); if(R.error){ log('Swing тест', tf, R.error); continue; }
      const sigs = [].concat(...runs[tf].filter(Boolean).map(r => r.sigs)).sort((a, b) => b.t - a.t).slice(0, 400).map(s => ({sym: s.sym, t: s.t, d: s.d, e: s.e, sl: s.sl, tp: s.tp, n: s.n, res: s.res, R: s.R, days: s.days, f: s.f}));
      byTf[tf] = {R, sigs}; }
    if(!Object.keys(byTf).length) return null;
    const out = {at: Date.now(), byTf}; writeAtomic(SWING_FILE, JSON.stringify(out)); SWING = out;
    log('Swing систем тестлэгдлээ (' + why + '): ' + Object.entries(byTf).map(([tf, x]) => `${swTfl(tf)} ${x.R.sets[0].n} арилжаа ${x.R.sets[0].m}R`).join(' · '));
    return out;
  }catch(e){ log('Swing тестийн алдаа:', e.message); return null; } finally{ swingBusy = false; }
}
const swDir = d => d > 0 ? 'LONG' : 'SHORT', swArr = d => d > 0 ? '▲ өсөх' : d < 0 ? '▼ буурах' : '· тодорхойгүй';
const swF = (x, s) => { const v = +x, a = Math.abs(v), dec = a >= 1000 ? 1 : a >= 50 ? 2 : a >= 5 ? 3 : 5; return (s && v > 0 ? '+' : '') + v.toFixed(dec); };
const swR = x => (x >= 0 ? '+' : '') + (+x).toFixed(2) + 'R';
// confirmations of one signal: ✓ / ✕ / —
function swConf(f){
  const m = v => v > 0 ? '✓' : v < 0 ? '✕' : '—';
  const L = [`D Доу ${m(f.dD)}`, `D сэрээ ${m(f.fD)}`, `W Доу ${m(f.dW)}`, `volume ${f.vol == null ? '—' : f.vol.toFixed(1) + '× ' + (f.vol >= 1 ? '✓' : '✕')}`];
  const ok = [f.dD > 0, f.fD > 0, f.dW > 0, f.vol != null && f.vol >= 1].filter(Boolean).length;
  return {txt: L.join(' · '), ok};
}
function swTestLine(R, k){ const s = R && R.sets ? R.sets.find(x => x.k === k) : null; if(!s || !s.n) return 'тест хийгдээгүй'; return `${s.n} арилжаа · ${swR(s.m)} (±${s.ci}) — ${SW.verdict(s, R.base)}`; }
// the history test as text
function swingTestText(tf){
  tf = tf || '4h'; const S = swTest(tf); if(!S || !S.R) return `📏 Swing систем (${swTfl(tf)}): тест хараахан хийгдээгүй — урт түүх татагдсаны дараа автоматаар тооцогдоно.`;
  const R = S.R, d = t => new Date(t).toISOString().slice(0, 10), pc = x => Math.round(x*100) + '%';
  const L = [`📏 Swing систем «3 шүргэлт» · ${swTfl(tf)} · түүхэн тест`, `${R.syms.length} хэрэгсэл · ${R.years} жил · жилд ${R.perYear} арилжаа (бүгдэд) · ${swTfl(tf)}, SL ${R.rules.SLK}×ATR, TP 1:${R.rules.RR}, зардал хассан`, ''];
  R.sets.forEach(s => L.push(`${s.k === 'all' ? '▸' : ' •'} ${s.name}: ${s.n ? `${s.n} · ялалт ${pc(s.wr)} · ${swR(s.m)} (±${s.ci}) · 60/40: ${swR(s.mA)} / ${swR(s.mB)}` : 'дохио алга'}${s.n ? ' — ' + SW.verdict(s, R.base) : ''}`));
  L.push('', `Санамсаргүй орсон бол (ижил SL/TP): ${R.base.n ? swR(R.base.m) : '—'} — давуу тал энэнээс дээш байх ёстой.`);
  if(R.ex) L.push(`Жишээ жил (USD/JPY 2022): ${R.ex.n} арилжаа, ${R.ex.wins} нь TP, нийт ${R.ex.pips >= 0 ? '+' : ''}${R.ex.pips} пип (SL дунджаар ${R.ex.avgSl} пип).`);
  const ps = R.perSym.filter(x => x.n).sort((a, b) => b.m - a.m);
  if(ps.length){ const tag = x => x.mA == null || x.nA < 15 || x.nB < 10 ? 'цөөн' : x.mA > 0 && x.mB > 0 ? (x.m - (x.ci || 0) > 0 ? '✓ хоёр хэсэгт эерэг, батлагдсан' : '≈ хоёр хэсэгт эерэг') : x.mA < 0 && x.mB < 0 ? '✕ хоёр хэсэгт сөрөг' : '↕ хэсэг бүрт зөрүүтэй';
    L.push('', 'Хэрэгсэл тус бүр (үндсэн дүрэм) · эхний 60% / сүүлийн 40% хугацаа · D Доугийн дагуу:');
    ps.forEach(x => L.push(` • ${x.sym}: ${swR(x.m)} ±${(x.ci || 0).toFixed(2)} (${x.n}) · ${x.nA != null ? swR(x.mA) + ' / ' + swR(x.mB) : '—'} · Доу ${x.nD ? swR(x.mD) + ' (' + x.nD + ')' : '—'} — ${tag(x)}`)); }
  const o = SW_TFS.filter(x => x !== tf).map(x => { const T = swTest(x); return T && T.R ? `${swTfl(x)} ${swR(T.R.sets[0].m)} (${T.R.sets[0].n})` : null; }).filter(Boolean);
  if(o.length) L.push('', 'Бусад цаг (үндсэн дүрэм): ' + o.join(' · ') + ' — /swing test 1h | 4h | d');
  return L.join('\n');
}
// the checklist of one market
function swingCheck(N, acct){
  if(!N || N.error) return {verdict: 'ӨГӨГДӨЛ АЛГА', why: N ? N.error : 'тооцоо хийгдээгүй', items: []};
  const a = N.atr4, it = [], dD = N.dD, TL = N.tfl || '4H';
  it.push({ok: dD !== 0 ? 1 : 0, t: `① Том цаг (D Доу): ${swArr(dD)} · W Доу: ${swArr(N.dW)}`});
  if(N.fork) it.push({ok: N.fork.dir === dD && dD ? 1 : N.fork.dir === -dD && dD ? -1 : 0, t: `② D сэрээ: ${swArr(N.fork.dir)} · үнэ медианаас ${N.fork.pos > 0 ? 'дээр' : 'доор'} (${N.fork.dist} D-ATR)`});
  else it.push({ok: 0, t: '② D сэрээ: хангалттай swing алга'});
  const corr = dD && N.d4 === -dD, imp = dD && N.d4 === dD;
  it.push({ok: corr ? 1 : 0, t: `③ ${TL} бүтэц: ${corr ? 'засвар (амралт) — том трендийн эсрэг паттерн үүсч байна' : imp ? 'үндсэн хөдөлгөөн том трендийн дагуу явж байна' : 'хажуугийн / тодорхойгүй'}`});
  const want = dD > 0 ? N.near.up : dD < 0 ? N.near.dn : null, other = dD > 0 ? N.near.dn : dD < 0 ? N.near.up : null;
  if(want) it.push({ok: Math.abs(want.dist) <= 1.5 ? 1 : 0, t: `④ ${want.t === 'H' ? 'Эсэргүүцлийн' : 'Дэмжлэгийн'} шугам ${want.n} шүргэлттэй · ${swF(want.v)} (${Math.abs(want.dist)} ATR зайтай) — ${dD > 0 ? 'дээш' : 'доош'} ${TL} хаалтаар эвдрэхийг хүлээ`});
  else it.push({ok: 0, t: '④ Трендийн чиглэлд 3+ шүргэлттэй шугам алга'});
  if(other) it.push({ok: 0, t: `   эсрэг талд: ${other.n} шүргэлттэй шугам ${swF(other.v)} (${Math.abs(other.dist)} ATR) — ${dD ? 'энэ эвдэрвэл том трендийн эсрэг — арга барилаар орохгүй' : ''}`});
  let verdict, why, plan = null;
  if(N.sig){ const s = N.sig, c = swConf(s.f), agree = s.f.dD > 0;
    plan = {d: s.d, e: s.e, sl: s.sl, tp: s.tp, risk: Math.abs(s.e - s.sl), lots: swLots(N.sym, Math.abs(s.e - s.sl), acct)};
    verdict = agree ? `ОРОХ — ${swDir(s.d)}` : s.f.dD < 0 ? 'ДҮРЭМ БИЕЛСЭН Ч ТОМ ЦАГИЙН ЭСРЭГ' : 'ДҮРЭМ БИЕЛСЭН Ч ТОМ ЦАГИЙН ТРЕНД ТОДОРХОЙГҮЙ';
    why = `Сүүлийн ${TL} лаа ${s.n} шүргэлттэй шугамыг эвдэж хаагдлаа. Баталгаа: ${c.txt} (${c.ok}/4).${agree ? '' : ' Арга барил зөвхөн том цагийн трендийн дагуу орно.'}`;
  } else if(want && Math.abs(want.dist) <= 1.5){ const d = dD, e = want.v + d*0.1*a;
    plan = {d, e, sl: e - d*N.rules.SLK*a, tp: e + d*N.rules.RR*N.rules.SLK*a, risk: N.rules.SLK*a, lots: swLots(N.sym, N.rules.SLK*a, acct), pending: true};
    verdict = `ХҮЛЭЭХ — ${swDir(d)} бэлтгэл`; why = `${swF(want.v)}-ийн ${d > 0 ? 'дээгүүр' : 'доогуур'} ${TL} лаа хаагдвал орно. Түүнээс өмнө орохгүй (хуурамч эвдрэлээс сэргийлж хаалтыг хүлээнэ).`;
  } else { verdict = 'ОРОХГҮЙ'; why = dD ? 'Том трендийн чиглэлд ойрхон 3 шүргэлттэй шугам алга — тэвчээртэй хүлээ.' : 'Том цагийн тренд тодорхойгүй — арга барилын дагуу арилжаа хийхгүй.'; }
  return {verdict, why, items: it, plan};
}
function swingCheckText(N, acct){
  const K = swingCheck(N, acct), L = [`📏 ${N ? N.sym : ''} · ${N && N.tfl || ''} · Swing шалгах хуудас`, ...K.items.map(x => `${x.ok > 0 ? '✅' : x.ok < 0 ? '❌' : '▫️'} ${x.t}`), '', `→ ${K.verdict}`, K.why];
  if(K.plan){ const p = K.plan; L.push('', `${p.pending ? 'Төлөвлөгөө (эвдрэвэл)' : 'Төлөвлөгөө'}: ${swDir(p.d)} ≈ ${swF(p.e)} · SL ${swF(p.sl)} · TP ${swF(p.tp)} (1:${N.rules.RR})`, `Лот: $${acct} дансны 1% эрсдэл → ${p.lots != null ? p.lots.toFixed(2) + ' лот' + (p.lots < 0.01 ? ' (0.01-ээс бага — данс бага)' : '') : '—'}`); }
  L.push('', `Түүхэн тест (${N && N.tfl || ''}, үндсэн дүрэм): ${swTestLine((swTest(N && N.tf || '4h') || {}).R, 'all')}`, 'Санхүүгийн зөвлөгөө биш. Эхлээд демо данс дээр.');
  return L.join('\n');
}
// every hour: the state of the live markets, new signals (once), and open trades followed to SL / TP
async function swingTick(){
  const acct = swingAcct(), now = swingNowAll(), live = swingLive(); let changed = false;
  for(const sym of CFG.histSymbols){
    let F; try{ F = sw1h(sym, 9000); }catch(e){ continue; } if(F.length < 600) continue;
    const A = now[sym] && !now[sym].px ? now[sym] : {}; now[sym] = A;
    for(const tf of SW_TFS){
    const N = SW.now(sym, F, spreadOf(sym), tf); A[tf] = N; const key = sym + '|' + tf, TL = swTfl(tf);
    // one open trade per market and timeframe: a new break while one is open is not taken
    const busy = live.some(x => x.status === 'open' && x.sym === sym && (x.tf || '4h') === tf);
    if(N.sig && !(ST.swSent && ST.swSent[key] >= N.sig.t) && !(tf === '4h' && ST.swSent && ST.swSent[sym] >= N.sig.t)){
      ST.swSent = Object.assign(ST.swSent || {}, {[key]: N.sig.t}); stSave();
      if(busy) continue;
      const s = N.sig, c = swConf(s.f), risk = Math.abs(s.e - s.sl), lots = swLots(sym, risk, acct), agree = s.f.dD > 0;
      live.push({id: key + '|' + s.t, sym, tf, t: s.t, d: s.d, e: s.e, sl: s.sl, tp: s.tp, risk, n: s.n, f: s.f, agree, status: 'open'}); changed = true;
      if(!ST.swMute && !(ST.swMuteTf || []).includes(tf)) tgSend([`📏 3 шүргэлт · ${sym} · ${TL} · ${swDir(s.d)}${agree ? '' : s.f.dD < 0 ? ' (том цагийн эсрэг — арга барилаар орохгүй)' : ' (том цагийн тренд тодорхойгүй — арга барилаар орохгүй)'}`,
        `${TL} хаалтаар ${s.n} шүргэлттэй ${s.d > 0 ? 'эсэргүүцлийн' : 'дэмжлэгийн'} шугам эвдэрлээ.`,
        `Орох ≈ ${swF(s.e)} · SL ${swF(s.sl)} · TP ${swF(s.tp)} (1:${SW.C.RR})`,
        `Лот: $${acct} дансны 1% → ${lots != null ? lots.toFixed(2) : '—'} лот`,
        `Баталгаа: ${c.txt} → ${c.ok}/4`,
        `Түүхэн тест (${TL}): ${swTestLine((swTest(tf) || {}).R, agree ? 'dD' : s.f.dD < 0 ? 'anti' : 'all')}`,
        'SL/TP-г хөдөлгөхгүй, давхар арилжаа нээхгүй. Туршилт — демо данс дээр.'].join('\n'));
    }
    }
  }
  // follow open live trades on 1H bars
  for(const L of live){ if(L.status !== 'open') continue; let F; try{ F = sw1h(L.sym, 5000); }catch(e){ continue; }
    const r = SW.resolve(F, L.t, {d: L.d, e: L.e, sl: L.sl, tp: L.tp, risk: L.risk}, (SW.TFS[L.tf || '4h'] || SW.TFS['4h']).maxDays*864e5); if(r.open) continue;
    const days = Math.max(0, (r.t - L.t)/864e5), g = (r.px - L.e)*L.d/L.risk, cost = 1.2*spreadOf(L.sym)/L.risk + SW.C.FIN*L.e*days/365/L.risk;
    Object.assign(L, {status: r.res, R: +(g - cost).toFixed(3), closedAt: r.t, days: +days.toFixed(1)}); changed = true;
    if(!ST.swMute) tgSend(`📏 3 шүргэлт · ${L.sym} · ${swTfl(L.tf || '4h')} ${swDir(L.d)} хаагдлаа: ${r.res === 'win' ? 'TP ✅' : r.res === 'loss' ? 'SL ❌' : 'хугацаа дууссан'} ${swR(g - cost)} · ${Math.round(days)} хоног`); }
  SWNOW = now; try{ writeAtomic(SWING_NOW, JSON.stringify(now)); }catch(e){}
  if(changed) writeAtomic(SWING_LIVE, JSON.stringify(live.slice(-1000)));
}
function swingLiveText(){
  const L = swingLive(), done = L.filter(x => x.status !== 'open'), op = L.filter(x => x.status === 'open'), ag = done.filter(x => x.agree);
  const st = A => { const s = SW.stat(A.map(x => x.R)); return s.n ? `${s.n} · ялалт ${Math.round(s.wr*100)}% · ${swR(s.m)} · нийт ${swR(s.sum)}` : '—'; };
  return [`Бодит (ирээдүйн) бүртгэл: бүгд ${st(done)} · том цагийн дагуу ${st(ag)}`, ...op.map(x => ` ⏳ ${x.sym} ${swTfl(x.tf || '4h')} ${swDir(x.d)} ${swF(x.e)} (SL ${swF(x.sl)} · TP ${swF(x.tp)})${x.agree ? '' : ' · эсрэг'}`)].join('\n');
}

// ---------------------------------------------------------------- v1.11 economic calendar
// high-impact news times for the coach's «news» step (the app reads /api/cal).
// Source: the public weekly calendar feed (override with CAL_URL; CAL_OFF=1 turns it off).
const CAL_URL = ENV.CAL_URL || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json';
let calBusy = false;
async function calFetch(why){
  if(calBusy || ENV.CAL_OFF === '1') return; calBusy = true;
  try{
    const r = await fetch(CAL_URL, {signal: AbortSignal.timeout(30000), headers: {'User-Agent': 'mp-server/' + VERSION}});
    if(!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json(); if(!Array.isArray(j)) throw new Error('хариуны хэлбэр буруу');
    const imp = v => /high/i.test(v) ? 3 : /medium/i.test(v) ? 2 : /low/i.test(v) ? 1 : 0;
    const ev = j.map(e => ({ts: Date.parse(e.date), cur: String(e.country || '').toUpperCase().slice(0, 4), title: String(e.title || '').slice(0, 90), imp: imp(e.impact)})).filter(e => isFinite(e.ts) && e.imp >= 2 && e.title);
    if(!ev.length && j.length) throw new Error('мэдээ уншигдсангүй');
    const keep = ((ST.cal && ST.cal.ev) || []).filter(e => e.ts > Date.now() - 2*864e5 && !ev.some(x => x.ts === e.ts && x.title === e.title));
    ST.cal = {at: Date.now(), ev: keep.concat(ev).sort((a, b) => a.ts - b.ts).slice(-500), err: null}; ST.calWarned = 0; stSave();
    log(`Хуанли: ${ev.length} мэдээ татлаа (${why})`);
  }catch(e){
    ST.cal = Object.assign({ev: []}, ST.cal || {}, {err: e.message, errAt: Date.now()}); stSave(); logThrottled('cal', 'Хуанли татаж чадсангүй: ' + e.message);
    if(!ST.calWarned){ ST.calWarned = 1; stSave(); tgSend(`⚠ Эдийн засгийн хуанли татаж чадсангүй (${e.message}). Багшийн «мэдээ» алхам «тодорхойгүй» горимоор ажиллана (оноонд орохгүй). Дараагийн оролдлого 4 цагийн дараа.`); }
  }finally{ calBusy = false; }
}
function calText(){
  const C = ST.cal || {}, now = Date.now(), fmt = ts => new Date(ts).toLocaleString('mn-MN', {timeZone: CFG.tz, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false});
  const L = (C.ev || []).filter(e => e.imp >= 3 && e.ts > now - 30*60e3 && e.ts < now + 3*864e5);
  if(!C.at) return '📅 Хуанли хараахан татагдаагүй' + (C.err ? ` (алдаа: ${C.err})` : '') + '.';
  return [`📅 Ойрын 3 хоногийн ЧУХАЛ мэдээ (${CFG.tz} цагаар):`, ...(L.length ? L.slice(0, 40).map(e => ` • ${fmt(e.ts)} ${e.cur} — ${e.title}`) : [' (алга)']), '', `Татсан: ${fmt(C.at)}${C.err ? ' · сүүлийн алдаа: ' + C.err : ''}`].join('\n');
}
const TREND_FILE = path.join(DATA, 'trend.json'), TREND_LIVE = path.join(DATA, 'trend-live.json');
let TREND = null;
const trendAcct = () => ST.trendAcct || CFG.trendAcct;
function trendGet(){ if(!TREND){ try{ TREND = JSON.parse(fs.readFileSync(TREND_FILE, 'utf8')); }catch(e){} } return TREND; }
function trendLive(){ try{ return JSON.parse(fs.readFileSync(TREND_LIVE, 'utf8')); }catch(e){ return []; } }
// forward test: every weekly snapshot is kept; the P/L from one snapshot to the next is the system's real out-of-sample result
function trendLiveText(){ const L = trendLive(); if(L.length < 2) return '\n\nБодит (ирээдүйн) туршилт: ' + (L.length ? `${new Date(L[0].asOf).toISOString().slice(0, 10)}-нээс эхэлсэн, эхний долоо хоног дуусаагүй.` : 'долоо хоногийн анхны тайлангаас эхэлнэ.');
  let eq = 1; for(let i = 1; i < L.length; i++){ const a = L[i-1], b = L[i]; let p = 0; a.now.forEach(x => { const y = b.now.find(z => z.sym === x.sym); if(y && x.price > 0) p += x.w*(y.price/x.price - 1); }); eq *= 1 + p; }
  return `\n\nБодит (ирээдүйн) туршилт: ${L.length - 1} долоо хоног · ${eq >= 1 ? '+' : ''}${((eq - 1)*100).toFixed(1)}% (зардалгүй, ${new Date(L[0].asOf).toISOString().slice(0, 10)}-нээс).`; }
// TD candles to verify a symbol's long history against (1 credit, only for symbols the scan never loads)
async function tdPrime(){
  const Hh = hist(); if(!Hh || !CFG.tdKey) return;
  for(const s of CFG.trendSymbols){
    const c = Hh.coverage().find(x => x.symbol === s); if(c && c.verified) continue;
    if(tdStoreRows(s, '1h').length >= 60 || tdStoreRows(s, '15min').length >= 60) continue;
    if(credits().used >= CFG.creditCap*0.8) return;
    try{ creditUse(1);
      const r = await fetch(`${CFG.tdBase}/time_series?timezone=UTC&symbol=${encodeURIComponent(s)}&interval=1h&outputsize=2000&apikey=${encodeURIComponent(CFG.tdKey)}`, {signal: AbortSignal.timeout(45000)});
      const t = await r.text(); let j = null; try{ j = JSON.parse(t); }catch(e){}
      if(j && j.status === 'error'){ log('Тренд: Twelve Data', s, j.message); ST.trendNoTd = Object.assign(ST.trendNoTd || {}, {[s]: String(j.message).slice(0, 120)}); stSave(); }
      else csPut(t, '?timezone=UTC&'); }catch(e){ log('Тренд: Twelve Data-аас лаа авч чадсангүй', s, e.message); }
    await sleep(9000); }
  csFlush();
}
let trendBusy = false;
async function trendCompute(why){
  if(!CFG.trendOn || trendBusy) return null; const Hh = hist(); if(!Hh) return null; trendBusy = true;
  try{ const ok = Hh.coverage().filter(c => c.verified && CFG.trendSymbols.includes(c.symbol)).map(c => c.symbol);
    if(ok.length < 2) return null;
    const R = TR.run(Hh, ok); if(!R || R.error){ log('Тренд систем:', R && R.error); return null; }
    writeAtomic(TREND_FILE, JSON.stringify(R)); TREND = R; log(`Тренд систем тооцогдлоо (${why}): ${R.syms.length} хэрэгсэл, Sharpe ${R.stats.sharpe}`); return R;
  }catch(e){ log('Тренд системийн алдаа:', e.message); return null; } finally{ trendBusy = false; }
}
// weekly signal: Sunday after the night's history update — the positions to hold from Monday's open
async function trendWeekly(){
  const R = await trendCompute('долоо хоногийн тайлан') || trendGet(); if(!R || R.error) return;
  const prev = (ST.trendLast || {}).now || null;
  tgSend(TR.text(R, trendAcct(), prev) + trendLiveText());
  const L = trendLive(); if(!L.length || L[L.length - 1].asOf !== R.asOf){ L.push({asOf: R.asOf, now: R.now.map(x => ({sym: x.sym, w: x.w, price: x.price}))}); writeAtomic(TREND_LIVE, JSON.stringify(L.slice(-520))); }
  ST.trendLast = {asOf: R.asOf, now: R.now.map(x => ({sym: x.sym, w: x.w}))}; ST.trendWeek = ymd(); stSave();
}
// v1.5 «/chart [XAU] [1h]» — a picture of a symbol's chart with its most advanced entry setup
let chartBusy = false;
async function chartCmd(arg){
  if(histTestBusy) return tgSend('Түүхэн тест явж байгаа үед график солихгүй — дууссаны дараа дахин оролдоорой.');
  if(chartBusy) return; chartBusy = true;
  try{
    const parts = String(arg || '').toUpperCase().split(/\s+/).filter(Boolean);
    const ivA = parts.find(p => /^(\d+)(MIN|M|H|D)$/.test(p)), symA = parts.find(p => p !== ivA);
    const ivMap = x => { const m = /^(\d+)(MIN|M|H|D)$/.exec(x); if(!m) return null; return m[2] === 'H' ? m[1] + 'h' : m[2] === 'D' ? m[1] + 'day' : m[1] + 'min'; };
    const syms = (CFG.histSymbols && CFG.histSymbols.length ? CFG.histSymbols : [CFG.sym]);
    const sym = symA ? (syms.find(s => s.replace(/[^A-Z]/g, '').includes(symA.replace(/[^A-Z]/g, ''))) || null) : CFG.sym;
    const iv = ivA ? ivMap(ivA) : CFG.iv;
    if(!sym) return tgSend(`«${symA}» хослол олдсонгүй. Жишээ: /chart XAU 1h`);
    const moved = sym !== CFG.sym || iv !== CFG.iv;
    if(moved){ await station.eval(([s, i]) => window.__MP.select(s, i), [sym, iv]); await sleep(9000); }
    const P = await station.eval(() => window.__MP.chartPic && window.__MP.chartPic());
    if(moved) await station.eval(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]);
    if(!P || !P.img){ tgSend('График зурж чадсангүй' + (P && P.error ? ': ' + P.error : '.')); return; }
    tgSend(P.caption, {photo: Buffer.from(P.img.slice(P.img.indexOf(',') + 1), 'base64')});
  }finally{ chartBusy = false; }
}
function histPick(arg){
  const Hh = hist(), cov = Hh ? Hh.coverage() : [], ok = cov.filter(c => c.verified && CFG.histSymbols.includes(c.symbol)).map(c => c.symbol);
  const a = String(arg || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if(a && a !== 'ALL'){ const m = cov.filter(c => c.code.includes(a)).map(c => c.symbol); return m.length ? m : [CFG.sym]; }
  return ok.length ? ok : [CFG.sym];
}
async function histTest(reason, syms){
  if(histTestBusy || !station.alive) return null; histTestBusy = true;
  const out = []; syms = (syms && syms.length ? syms : [CFG.sym]);
  const Hh = hist(), cov = Hh ? Hh.coverage() : [], unver = syms.filter(s => { const c = cov.find(x => x.symbol === s); return c && !c.verified; });
  try{
    tgSend(`🧪 Түүхэн тест эхэллээ (${reason}) — ${syms.join(', ')} · ${CFG.histTestIvs.join(', ')}. ${syms.length*CFG.histTestIvs.length} тест, ойролцоогоор ${Math.round(syms.length*20)} мин.${unver.length ? `\n⚠ ${unver.join(', ')}: урт түүх хараахан шалгагдаагүй тул Twelve Data-гийн богино түүхээр тестлэнэ.` : ''}`);
    for(const sym of syms) for(const iv of CFG.histTestIvs){
      await station.eval(([s, i]) => window.__MP.select(s, i), [sym, iv]);
      let ok = false; for(let k = 0; k < 36 && !ok; k++){ await sleep(5000); const p = await station.eval(() => window.__MP.ping()); ok = !!(p && p.sym === sym && p.iv === iv && p.n > 300); }
      if(!ok){ log('Түүхэн тест: график ачаалагдсангүй', sym, iv); tgSend(`⚠ Түүхэн тест: ${sym} ${iv} график ачаалагдсангүй — алгаслаа.`); continue; }
      const t0 = Date.now(); let R = null;
      try{ R = await station.page.evaluate(() => window.__MP.histRun()); }catch(e){ log('Түүхэн тестийн алдаа:', e.message); }
      if(R){ out.push(R); log(`Түүхэн тест ${sym} ${iv}: ${Math.round((Date.now() - t0)/1000)} сек`); tgSend(histTestText(R)); }
    }
    // pooled over everything this station has tested (all symbols/timeframes)
    const D = await station.eval(() => window.__MP.diagText && window.__MP.diagText());
    if(D) tgSend(D);
    const LC = await station.eval(() => window.__MP.lcText && window.__MP.lcText());   // v77 pattern lifecycle
    if(LC) tgSend(LC);
  }finally{
    await station.eval(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]);
    histTestBusy = false; ST.lastHistTest = Date.now(); stSave();
    backupNow(false).catch(() => {});
  }
  return out;
}
function histTestText(R){
  const L = [`🧪 Түүхэн тест · ${R.sym} ${R.iv} · ${Math.round(R.sec/60)} мин`];
  if(R.bt){
    L.push(`${R.bt.src === 'dukascopy' ? 'Урт түүх (Dukascopy)' : 'Twelve Data'}: ${String(R.bt.from).slice(0, 10)} → ${String(R.bt.to).slice(0, 10)} · ${R.bt.n} лаа · ${R.bt.sig} дохио`);
    R.bt.rows.forEach(r => L.push(` • ${r.name}: ${r.n} · TP ${pc(r.wr)} · ${rr(r.exp)}${r.gross != null ? ` (зардалгүй ${rr(r.gross)})` : ''} — ${r.verdict}`));
  } else L.push('Арилжааны төлөвлөгөөний тест хийгдсэнгүй.');
  if(R.dowTxt) L.push(R.dowTxt);
  if(R.fq && R.fq.length){
    L.push('', `Таамгийн нарийвчлал (${R.fqInfo && R.fqInfo.long ? 'урт түүхээр' : 'богино түүхээр'}, ${R.fqInfo ? R.fqInfo.pts : '—'} цэг):`);
    R.fq.forEach(f => L.push(` • ${f.name}: ${f.calls ? pc(f.hr) + ` (${f.calls} таамаг, суурь ${pc(f.naive)})` : '—'} — ${f.lbl}`));
  }
  return L.join('\n');
}

function csList(){
  return fs.readdirSync(DIRS.candles).filter(f => f.endsWith('.json')).map(f => { const k = f.slice(0, -5), e = csGet(k), ds = [...e.rows.keys()].sort(); return {key: k, symbol: e.meta && e.meta.symbol, interval: e.meta && e.meta.interval, n: ds.length, from: ds[0] || null, to: ds[ds.length - 1] || null}; });
}

// ---------------------------------------------------------------- the station (headless app)
const sleep = ms => new Promise(r => setTimeout(r, ms));
let SHUTTING = false;
const station = {
  ctx: null, page: null, alive: false, starting: false, since: 0, restarts: 0, fails: 0, last: null,
  async start(){
    if(this.starting) return; this.starting = true;
    try{
      const {chromium} = require('playwright');
      this.ctx = await chromium.launchPersistentContext(DIRS.profile, {
        headless: true, viewport: {width: 1280, height: 900}, deviceScaleFactor: 1, locale: 'mn-MN', timezoneId: CFG.tz,
        args: ['--disable-dev-shm-usage', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows'],
      });
      this.ctx.on('close', () => { if(this.alive && !SHUTTING){ this.alive = false; log('Chromium хаагдлаа'); this.schedule('браузер хаагдсан'); } });
      await this.ctx.exposeBinding('__mpNotify', (src, title, body, img) => onAppNotify(title, body, img));
      await this.ctx.exposeBinding('__mpBigSave', (src, key, val) => bigSave(key, val));
      await this.ctx.addInitScript(INIT_SCRIPT());
      await this.ctx.route(/api\.twelvedata\.com/, tdRoute);
      await this.ctx.route(/api\.telegram\.org/, r => r.fulfill({status: 200, contentType: 'application/json', body: '{"ok":true}'}));   // the server sends Telegram itself
      const page = this.ctx.pages()[0] || await this.ctx.newPage(); this.page = page;
      page.on('crash', () => { log('Станцын хуудас унасан (crash)'); this.schedule('хуудас унасан'); });
      page.on('pageerror', e => logThrottled('pageerror', 'App JS алдаа: ' + String(e.message).slice(0, 300)));
      await page.goto(`http://127.0.0.1:${CFG.port}/`, {waitUntil: 'load', timeout: 120000});
      await page.waitForFunction(() => window.__MP && window.__MP.ping, null, {timeout: 60000});
      this.alive = true; this.since = Date.now(); this.fails = 0;
      log('✓ Станц ачаалагдлаа');
      // chart symbol / timeframe, then the forward test
      await sleep(8000);
      const p = await page.evaluate(() => window.__MP.ping());
      if(CFG.sym && (p.sym !== CFG.sym || p.iv !== CFG.iv)){ await page.evaluate(([s, i]) => window.__MP.select(s, i), [CFG.sym, CFG.iv]); await sleep(8000); }
      if(CFG.autoStation){ const F = await page.evaluate(() => window.__MP.startStation()); log('Станц:', F && F.on ? `ажиллаж байна (${(F.syms || []).join(', ')})` : 'асаагүй'); }
    }catch(e){ log('Станц эхлүүлэхэд алдаа:', String(e && e.message || e)); this.alive = false; this.schedule('эхлүүлж чадсангүй'); }
    finally{ this.starting = false; }
  },
  async stop(){ this.alive = false; try{ if(this.ctx) await this.ctx.close(); }catch(e){} this.ctx = null; this.page = null; },
  async restart(why){ log('Станцыг дахин эхлүүлж байна:', why); this.restarts++; await this.stop(); await sleep(3000); await this.start(); },
  schedule(why){
    if(this.timer) return;
    const wait = Math.min(5*60e3, 15e3*Math.pow(2, Math.min(this.fails++, 4)));
    tgSend(`⚠ Станц дахин эхэлж байна: ${why}`, {dedupe: 'restart', every: 30*60e3});
    this.timer = setTimeout(async () => { this.timer = null; await this.restart(why); }, wait);
  },
  async eval(fn, arg){ if(!this.alive || !this.page) return null; try{ return await this.page.evaluate(fn, arg); }catch(e){ return null; } },
};
function INIT_SCRIPT(){
  // runs in the page before the app: marks the server mode, gives the app
  // its API key / settings, and turns browser notifications into Telegram
  return `(() => {
    window.__MP_SERVER = true; window.__MP_TOKEN = ${JSON.stringify(CFG.token)};
    try{
      const set = (k, v) => { if(localStorage.getItem(k) !== v) localStorage.setItem(k, v); };
      set('eud_twelvedata_apikey', ${JSON.stringify(CFG.tdKey)});
      set('eud_autorefresh_secs', ${JSON.stringify(CFG.refreshSec)});
      if(!localStorage.getItem('eud_disc_v1')) localStorage.setItem('eud_disc_v1', '1');
      localStorage.setItem('eud_bull', '0');
    }catch(e){}
    const N = function(title, opt){ try{ window.__mpNotify(String(title || ''), String((opt && opt.body) || ''), (opt && typeof opt.image === 'string' && opt.image.startsWith('data:image/png;base64,')) ? opt.image : null); }catch(e){} this.close = () => {}; };
    N.permission = 'granted'; N.requestPermission = () => Promise.resolve('granted');
    try{ Object.defineProperty(window, 'Notification', {value: N, configurable: true, writable: true}); }catch(e){ window.Notification = N; }
  })();`;
}
const logT = new Map();
function logThrottled(k, msg){ const t = logT.get(k) || 0; if(Date.now() - t < 10*60e3) return; logT.set(k, Date.now()); log(msg); }
// the same message is not repeated within 6 h — also across restarts (the
// app re-announces a still-standing setup after every reload)
function onAppNotify(title, body, img){
  const h = crypto.createHash('sha1').update(title + '\n' + body).digest('hex').slice(0, 16), now = Date.now();
  ST.seen = ST.seen || {}; Object.keys(ST.seen).forEach(k => { if(now - ST.seen[k] > 6*36e5) delete ST.seen[k]; });
  if(ST.seen[h]){ log('Мэдэгдэл (давтагдсан — илгээгээгүй):', title); return; }
  ST.seen[h] = now; stSave(); log('Мэдэгдэл:', title + (img ? ' (зурагтай)' : ''));
  // v1.5: an entry signal comes with its chart picture (the app draws it)
  let photo = null; if(img){ try{ photo = Buffer.from(img.slice(img.indexOf(',') + 1), 'base64'); if(photo.length < 1000 || photo.length > 9e6) photo = null; }catch(e){ photo = null; } }
  if(ST.coachMute && /^🎓/.test(title)){ log('Мэдэгдэл (Багш чимээгүй):', title); return; }
  const text = `🔔 ${title}\n${body}`;
  if(photo && text.length <= 1000) tgSend(text, {photo}); else { tgSend(text); if(photo) tgSend('📈 ' + title, {photo}); }
}
// every Twelve Data request of the station passes here: count the credit,
// keep the server's daily cap, and store the candles that came back
async function tdRoute(route){
  const url = route.request().url();
  if(/apikey=probe/.test(url)) return route.fulfill({status: 200, contentType: 'application/json', body: '{"code":401,"message":"probe","status":"error"}'});
  const C = credits();
  if(C.used >= CFG.creditCap) return route.fulfill({status: 200, contentType: 'application/json', body: JSON.stringify({code: 429, status: 'error', message: `You have run out of API credits for the day. ${C.used} API credits were used, with the current limit being ${CFG.creditCap} (mp-server cap).`})});
  const m = /[?&]symbol=([^&]+)/.exec(url); creditUse(m ? Math.max(1, decodeURIComponent(m[1]).split(',').length) : 1);
  try{
    // candle times always in UTC (an app older than v76 does not ask for it)
    let path0 = url.replace(/^https?:\/\/api\.twelvedata\.com/, '');
    if(/^\/time_series\?/.test(path0) && !/[?&]timezone=/i.test(path0)) path0 = path0.replace('?', '?timezone=UTC&');
    const up = CFG.tdBase + path0;
    const resp = await route.fetch({url: up, timeout: 45000});
    const body = await resp.text();
    if(/\/time_series/.test(url)) csPut(body, path0);
    await route.fulfill({status: resp.status(), headers: {'content-type': 'application/json', 'access-control-allow-origin': '*'}, body});
  }catch(e){ logThrottled('tdnet', 'Twelve Data-д холбогдож чадсангүй: ' + e.message); try{ await route.abort('failed'); }catch(x){} }
}
async function shot(){ if(!station.alive || !station.page) return null; try{ return await station.page.screenshot({type: 'png'}); }catch(e){ return null; } }

// ---------------------------------------------------------------- backups
let lastBackup = 0;
async function backupNow(daily){
  const B = await station.eval(() => window.__MP.backup());
  if(!B || !B.keys) return false;
  const txt = JSON.stringify(B);
  try{
    writeAtomic(path.join(DIRS.backups, 'latest.json'), txt);
    if(daily) writeAtomic(path.join(DIRS.backups, `station-${ymd()}.json`), txt);
    if(daily && CFG.backupCopy){ try{ fs.mkdirSync(CFG.backupCopy, {recursive: true}); fs.copyFileSync(path.join(DIRS.backups, 'latest.json'), path.join(CFG.backupCopy, `station-${ymd()}.json`)); }catch(e){ log('Нөөцийг BACKUP_COPY_DIR руу хуулж чадсангүй:', e.message); } }
    pruneDir(DIRS.backups, /^station-\d{4}-\d\d-\d\d\.json$/, CFG.backupKeep);
    lastBackup = Date.now(); return true;
  }catch(e){ log('Нөөц бичиж чадсангүй:', e.message); return false; }
}
function latestBackup(){ try{ return fs.readFileSync(path.join(DIRS.backups, 'latest.json'), 'utf8'); }catch(e){ return null; } }
// the daily backup also goes to the owner's Telegram chat — a copy that
// survives even if this machine (or the cloud account) is lost
function backupToTelegram(caption){
  const b = latestBackup(); if(!b) return false;
  const buf = Buffer.from(b, 'utf8'); if(buf.length > 45*1024*1024){ tgSend('⚠ Нөөц файл Telegram-д хэт том байна (' + Math.round(buf.length/1e6) + ' MB).'); return false; }
  let n = 0; try{ n = Object.keys(JSON.parse(b).keys || {}).length; }catch(e){}
  tgSend(`${caption} · ${ymd()} · ${n} хэсэг · ${Math.round(buf.length/1024)} KB\nСэргээх: апп → 🧪 Үр дүнгийн нотолгоо → 📂 Файлаас сэргээх`, {doc: buf, docName: `station-${ymd()}.json`});
  return true;
}

// ---------------------------------------------------------------- price alarms (compatible with the phone's «Сервер сэрүүлэг»)
async function alarmsRun(){
  const live = ST.alarms.filter(a => !ST.fired.includes(a.id)); if(!live.length) return;
  const syms = [...new Set(live.map(a => String(a.sym).split(':')[0]))];
  if(credits().used + syms.length > CFG.creditCap) return;
  creditUse(syms.length);
  let j; try{ const r = await fetch(`${CFG.tdBase}/price?symbol=${encodeURIComponent(syms.join(','))}&apikey=${encodeURIComponent(CFG.tdKey)}`, {signal: AbortSignal.timeout(30000)}); j = await r.json(); }catch(e){ return; }
  const px = s => syms.length === 1 ? parseFloat(j.price) : parseFloat((j[s] || {}).price);
  for(const a of live){
    const p = px(String(a.sym).split(':')[0]); if(!isFinite(p)) continue;
    const hit = a.kind === 'above' ? p >= a.level : a.kind === 'below' ? p <= a.level : a.kind === 'zone' ? (p >= a.lo && p <= a.hi) : false;
    if(hit){ tgSend(`🔔 ${a.text}\n${a.sym} одоо ${p}`); ST.fired.push(a.id); stSave(); log('Сэрүүлэг:', a.text); }
  }
}

// ---------------------------------------------------------------- report text
const pc = x => x == null || !isFinite(x) ? '—' : Math.round(x*100) + '%';
const rr = x => x == null || !isFinite(x) ? '—' : (x >= 0 ? '+' : '') + (+x).toFixed(2) + 'R';
function fmtPx(p){ p = +p; return !isFinite(p) ? '—' : p.toFixed(p >= 1000 ? 2 : p >= 10 ? 3 : 5); }
function dur(ms){ const h = Math.floor(ms/36e5), d = Math.floor(h/24); return d ? `${d} хоног ${h % 24} цаг` : `${h} цаг ${Math.floor(ms/6e4) % 60} мин`; }
async function reportText(full){
  const S = await station.eval(() => window.__MP.summary());
  const C = credits(), mem = 1 - os.freemem()/os.totalmem();
  const L = [];
  L.push(`${full ? '📊 Өдрийн тайлан' : '🖥 Серверийн байдал'} · ${new Date().toLocaleString('sv-SE').slice(0, 16)}`);
  L.push(`Сервер: ${dur(process.uptime()*1000)} ажиллаж байна · RAM ${Math.round(mem*100)}% · станц ${station.alive ? 'ачаалагдсан' : '⚠ ачаалагдаагүй'}${station.restarts ? ` · ${station.restarts} удаа дахин эхэлсэн` : ''}`);
  L.push(`API: сервер өнөөдөр ${C.used}/${CFG.creditCap} кредит (Twelve Data хязгаар 800 — утсан дээрх хэрэглээ үүнд орохгүй)`);
  if(!S){ L.push('Станцын өгөгдөл одоогоор уншигдсангүй.'); return L.join('\n'); }
  const F = S.fwd, J = S.journal;
  L.push(F && F.on ? `Бодит туршилт: ● ажиллаж байна · ${((Date.now() - F.since)/DAY).toFixed(1)} хоног · ${(F.syms || []).join(', ')} · ${S.scanCfg.every || '—'} мин тутам` : 'Бодит туршилт: ⏸ зогссон');
  L.push(`График: ${S.sym} ${S.iv} · ${S.ping && S.ping.price != null ? fmtPx(S.ping.price) : '—'} · ${S.verdict ? S.verdict.action : '—'}`);
  const nToday = ST.lastJr && ST.lastJr.day !== ymd() ? J.total - ST.lastJr.n : null;
  L.push(`Журнал: ${J.total} дохио (эхэлснээс +${J.sinceStart}${nToday != null ? `, сүүлийн тайлангаас +${nToday}` : ''}) · дууссан ${J.done} · нээлттэй ${J.open} · цэвэр ${rr(J.netR)}`);
  if(full){
    L.push('', 'Аргууд (100 дууссан дохионоос дүгнэнэ):');
    S.methods.forEach(m => L.push(` • ${m.name}: ${m.n || 0} дууссан · ${m.n ? pc(m.wr) : '—'} · ${m.n ? rr(m.exp) : '—'} — ${m.lbl}`));
    if(S.fq && S.fq.length){ L.push('', `Таамгийн нарийвчлал (${S.sym} ${S.iv}):`); S.fq.forEach(f => L.push(` • ${f.name}: ${f.calls ? pc(f.hr) + ` (${f.calls} таамаг, энгийн суурь ${pc(f.naive)})` : '—'} — ${f.lbl}`)); }
    const sc = Object.entries(S.scan || {}); if(sc.length){ L.push('', 'Скан:'); sc.forEach(([k, x]) => L.push(` • ${k}: ${({confirmed: (x.dir > 0 ? '▲ LONG' : '▼ SHORT') + ' бүрдсэн', setup: 'бэлтгэл', trend: 'тренд', none: 'дохиогүй', nodata: 'өгөгдөлгүй', paid: 'төлбөртэй', err: 'алдаа'})[x.status] || x.status}`)); }
  }
  return L.join('\n');
}

// ---------------------------------------------------------------- HTTP
const okTok = t => { const a = Buffer.from(String(t || '')), b = Buffer.from(CFG.token); return a.length === b.length && crypto.timingSafeEqual(a, b); };
function authed(req){
  if(okTok(req.headers['x-secret'])) return true;
  const ck = /(?:^|;\s*)mp_t=([^;]+)/.exec(req.headers.cookie || ''); if(ck && okTok(decodeURIComponent(ck[1]))) return true;
  return false;
}
const CORS = {'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,X-Secret', 'Access-Control-Max-Age': '600'};
function send(res, code, body, type = 'application/json; charset=utf-8', extra = {}){
  res.writeHead(code, Object.assign({'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}, CORS, extra));
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function readBody(req, max = 512*1024){ return new Promise((ok, no) => { let n = 0; const ch = []; req.on('data', c => { n += c.length; if(n > max){ no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch).toString('utf8'))); req.on('error', no); }); }
function readRaw(req, max){ return new Promise((ok, no) => { let n = 0; const ch = []; req.on('data', c => { n += c.length; if(n > max){ no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', no); }); }
// ---------------------------------------------------------------- self-update: mp-server.zip uploaded on the /status page
// (no SSH needed): unpack to a temp folder, check every file (syntax, version, app), keep the
// current files in data/update-prev, copy the new ones in, npm install only if dependencies changed,
// then exit — systemd (or run.bat) starts the new version.
const execFileP = (cmd, args, opt = {}) => new Promise((ok, no) => require('child_process').execFile(cmd, args, Object.assign({timeout: 10*60e3, maxBuffer: 8*1024*1024}, opt), (e, so, se) => e ? no(Object.assign(e, {stderr: String(se || '')})) : ok(String(so || ''))));
const UPD_FILES = ['server.js', 'hist.js', 'lzma.js', 'trend.js', 'package.json', 'config.example.env', 'README.txt', 'install.sh', 'mpctl', 'install.bat', 'check.bat', 'test-run.bat', 'run.bat', 'restart.bat', 'stop.bat', 'setup-windows.ps1'];
async function selfUpdate(buf){
  if(!buf || buf.length < 1000 || buf[0] !== 0x50 || buf[1] !== 0x4b) throw new Error('Энэ mp-server.zip файл биш байна.');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mpupd-')), x = path.join(tmp, 'x');
  try{
    const zf = path.join(tmp, 'u.zip'); fs.writeFileSync(zf, buf); fs.mkdirSync(x);
    if(process.platform === 'win32') await execFileP('powershell', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -Force -LiteralPath '${zf.replace(/'/g, "''")}' -DestinationPath '${x.replace(/'/g, "''")}'`]);
    else await execFileP('unzip', ['-q', '-o', zf, '-d', x]).catch(e => { throw new Error('unzip ажилласангүй: ' + (e.stderr || e.message).slice(0, 200)); });
    const top = [x].concat(fs.readdirSync(x).map(d => path.join(x, d))).find(d => fs.existsSync(path.join(d, 'server.js')) && fs.existsSync(path.join(d, 'package.json')));
    if(!top) throw new Error('zip дотор mp-server (server.js, package.json) олдсонгүй.');
    const need = ['server.js', 'hist.js', 'lzma.js', 'package.json', path.join('app', 'index.html')].filter(f => !fs.existsSync(path.join(top, f)));
    if(need.length) throw new Error('zip-д дутуу файл: ' + need.join(', '));
    const src = fs.readFileSync(path.join(top, 'server.js'), 'utf8'), to = (/const VERSION = '([^']+)'/.exec(src) || [])[1];
    if(!to || !/^mp-server /.test(to)) throw new Error('server.js-ийн хувилбар танигдсангүй.');
    for(const f of ['server.js', 'hist.js', 'lzma.js']) await execFileP(process.execPath, ['--check', path.join(top, f)]).catch(e => { throw new Error(`${f} алдаатай: ${(e.stderr || e.message).split('\n').slice(0, 3).join(' ')}`); });
    try{ JSON.parse(fs.readFileSync(path.join(top, 'package.json'), 'utf8')); }catch(e){ throw new Error('package.json алдаатай.'); }
    const app = fs.readFileSync(path.join(top, 'app', 'index.html'), 'utf8');
    if(!/market-pattern-dashboard/.test(app) || !/__MP_SERVER/.test(app) || app.length < 100000) throw new Error('zip доторх app/index.html Market Pattern апп биш байна.');
    // keep the running version for a manual roll-back
    const prev = path.join(DATA, 'update-prev'); fs.mkdirSync(path.join(prev, 'app'), {recursive: true});
    UPD_FILES.concat([path.join('app', 'index.html')]).forEach(f => { try{ if(fs.existsSync(path.join(ROOT, f))) fs.copyFileSync(path.join(ROOT, f), path.join(prev, f)); }catch(e){} });
    const depsOld = (() => { try{ return JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).dependencies || {}); }catch(e){ return ''; } })();
    const depsNew = JSON.stringify(JSON.parse(fs.readFileSync(path.join(top, 'package.json'), 'utf8')).dependencies || {});
    UPD_FILES.forEach(f => { const a = path.join(top, f); if(fs.existsSync(a)){ const b = path.join(ROOT, f); fs.copyFileSync(a, b + '.new'); fs.renameSync(b + '.new', b); } });
    try{ fs.copyFileSync(APP_FILE, path.join(ROOT, 'app', 'index.prev.html')); }catch(e){}
    fs.copyFileSync(path.join(top, 'app', 'index.html'), APP_FILE + '.new'); fs.renameSync(APP_FILE + '.new', APP_FILE);
    let npm = false;
    if(depsOld !== depsNew){ npm = true; await execFileP(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], {cwd: ROOT}); }
    return {from: VERSION, to, npm, app: (/ver: 'v(\d+)'/.exec(app) || [])[1] || null};
  }finally{ try{ fs.rmSync(tmp, {recursive: true, force: true}); }catch(e){} }
}
let appHtml = null, appMtime = 0;
function appPage(){
  const st = fs.statSync(APP_FILE);
  if(!appHtml || st.mtimeMs !== appMtime){ appHtml = fs.readFileSync(APP_FILE, 'utf8').replace(/<head([^>]*)>/i, m => m + '<script>window.__MP_SERVED=1;</script>'); appMtime = st.mtimeMs; }
  return appHtml;
}
async function handle(req, res){
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  if(req.method === 'OPTIONS') return send(res, 204, '');
  if(p === '/' || p === '/index.html') return send(res, 200, appPage(), 'text/html; charset=utf-8', {'Cache-Control': 'no-cache'});
  if(p === '/favicon.ico') return send(res, 204, '');
  if(p === '/status'){
    const t = u.searchParams.get('t');
    if(t && okTok(t)) return send(res, 302, '', 'text/plain', {'Location': '/status', 'Set-Cookie': `mp_t=${encodeURIComponent(t)}; Path=/; HttpOnly; SameSite=Strict; Secure; Max-Age=${180*86400}`});
    if(!authed(req)) return send(res, 403, LOGIN_HTML, 'text/html; charset=utf-8');
    return send(res, 200, await statusHtml(), 'text/html; charset=utf-8');
  }
  if(!authed(req)) return send(res, 403, {ok: false, error: 'forbidden'});
  // worker-compatible alarm API (phone: Alert → «Сервер сэрүүлэг»)
  if(p === '/sync' && req.method === 'POST'){
    let b; try{ b = JSON.parse(await readBody(req)); }catch(e){ return send(res, 400, {ok: false}); }
    const alarms = (Array.isArray(b.alarms) ? b.alarms : []).slice(0, 80).filter(a => a && a.id && a.sym && (isFinite(a.level) || (isFinite(a.lo) && isFinite(a.hi)))).map(a => ({id: String(a.id).slice(0, 80), sym: String(a.sym).slice(0, 30), kind: a.kind, level: +a.level, lo: a.lo != null ? +a.lo : undefined, hi: a.hi != null ? +a.hi : undefined, text: String(a.text || '').slice(0, 300)}));
    const ids = new Set(alarms.map(a => a.id)); ST.alarms = alarms; ST.fired = ST.fired.filter(id => ids.has(id)); stSave();
    return send(res, 200, {ok: true, n: alarms.length, fired: ST.fired.length});
  }
  if(p === '/test'){ tgSend('✅ Сервер холбогдлоо. Утас унтраалттай байсан ч энд мэдэгдэл ирнэ.'); return send(res, 200, {ok: true}); }
  if(p === '/api/status'){ const S = await station.eval(() => window.__MP.summary()); return send(res, 200, {ok: true, server: VERSION, host: os.hostname(), uptime: Math.round(process.uptime()), alive: station.alive, since: station.since, restarts: station.restarts, credits: credits(), cap: CFG.creditCap, mem: {free: os.freemem(), total: os.totalmem()}, lastBackup, alarms: ST.alarms.length, station: S}); }
  if(p === '/api/swing'){ const qa = parseFloat(u.searchParams.get('acct') || ''); if(isFinite(qa) && qa >= 100 && qa <= 1e8){ ST.swAcct = Math.round(qa); stSave(); }
    const a = swingAcct(), N = swingNowAll(), S = swingGet();
    const now = CFG.histSymbols.map(x => { const A = N[x] && !N[x].px ? N[x] : {}; return {sym: x, tf: Object.fromEntries(SW_TFS.map(tf => [tf, A[tf] ? Object.assign({}, A[tf], {check: swingCheck(A[tf], a)}) : {sym: x, tf, tfl: swTfl(tf), error: 'тооцоо хийгдээгүй'}]))}; });
    return send(res, 200, {ok: true, v: 2, test: S && S.byTf ? S : S ? {byTf: {'4h': S}} : null, now, live: swingLive().slice(-300), acct: a, mute: !!ST.swMute, muteTf: ST.swMuteTf || [], rules: SW.C}); }
  if(p === '/api/cal'){ const C = ST.cal || {}; return send(res, 200, {ok: !!C.at, at: C.at || 0, err: C.err || null, ev: (C.ev || []).filter(e => e.ts > Date.now() - 864e5)}); }
  if(p === '/api/trend'){ const R = trendGet(); return send(res, 200, {ok: !!R, R, acct: trendAcct(), live: trendLive(), last: ST.trendLast || null, hist: hist() ? hist().coverage().filter(c => CFG.trendSymbols.includes(c.symbol)) : []}); }
  if(p === '/api/bigstore'){ const body = JSON.stringify(bigAll());
    if(/\bgzip\b/.test(req.headers['accept-encoding'] || '')) return send(res, 200, require('zlib').gzipSync(body, {level: 6}), 'application/json; charset=utf-8', {'Content-Encoding': 'gzip'});
    return send(res, 200, body); }
  if(p === '/api/backup'){
    if(station.alive && Date.now() - lastBackup > 60e3) await backupNow(false);
    const b = latestBackup(); return b ? send(res, 200, b) : send(res, 404, {ok: false, error: 'нөөц алга'});
  }
  if(p === '/api/shot'){ const png = await shot(); return png ? send(res, 200, png, 'image/png') : send(res, 503, {ok: false}); }
  if(p === '/api/history'){
    const Hh = hist(); if(!Hh) return send(res, 404, {status: 'error', code: 404, message: 'history disabled'});
    const sym = u.searchParams.get('symbol'), iv = u.searchParams.get('interval'), lim = Math.min(400000, Math.max(100, +u.searchParams.get('bars') || 50000));
    if(!sym || !iv) return send(res, 200, {ok: true, coverage: Hh.coverage(), busy: Hh.busy, prog: Hh.prog});
    if(!CFG.histSymbols.includes(sym)) return send(res, 404, {status: 'error', code: 404, message: 'symbol not in HISTORY_SYMBOLS'});
    const r = Hh.bars(sym, iv, lim);
    return r.error ? send(res, 404, {status: 'error', code: 404, message: r.note}) : send(res, 200, JSON.stringify(r));
  }
  if(p === '/api/histtest' && req.method === 'POST'){ if(histTestBusy) return send(res, 409, {ok: false, error: 'busy'}); histTest('/status хуудас', histPick(u.searchParams.get('symbol') || '')); return send(res, 200, {ok: true}); }
  if(p === '/api/candles'){
    const sym = u.searchParams.get('symbol'), iv = u.searchParams.get('interval');
    if(!sym || !iv){ return send(res, 200, {ok: true, sets: csList()}); }
    const e = csGet(csKey(sym, iv)); const ds = [...e.rows.keys()].sort();
    if(u.searchParams.get('format') === 'csv') return send(res, 200, 'datetime,open,high,low,close,volume\n' + ds.map(d => [d, ...e.rows.get(d)].join(',')).join('\n'), 'text/csv; charset=utf-8', {'Content-Disposition': `attachment; filename="${csKey(sym, iv)}.csv"`});
    return send(res, 200, {ok: true, meta: e.meta, n: ds.length, bars: ds.map(d => [d, ...e.rows.get(d)])});
  }
  if(p === '/api/app' && req.method === 'POST'){
    let html; try{ html = await readBody(req, 30*1024*1024); }catch(e){ return send(res, 413, {ok: false, error: 'файл хэт том'}); }
    if(!/market-pattern-dashboard/.test(html) || !/__MP_SERVER/.test(html) || html.length < 100000) return send(res, 400, {ok: false, error: 'Энэ Market Pattern апп-ын (v72+) файл биш байна.'});
    const ver = (/>v(\d+)</.exec(html) || /ver: 'v(\d+)'/.exec(html) || [])[1];
    try{ fs.copyFileSync(APP_FILE, path.join(ROOT, 'app', 'index.prev.html')); }catch(e){}
    writeAtomic(APP_FILE, html); log('Апп шинэчлэгдлээ (upload):', ver ? 'v' + ver : '?');
    return send(res, 200, {ok: true, ver: ver ? 'v' + ver : null});
  }
  if(p === '/api/update' && req.method === 'POST'){
    let buf; try{ buf = await readRaw(req, 40*1024*1024); }catch(e){ return send(res, 413, {ok: false, error: 'файл хэт том'}); }
    let R; try{ R = await selfUpdate(buf); }catch(e){ log('Шинэчлэл амжилтгүй:', e.message); return send(res, 400, {ok: false, error: e.message}); }
    log('Сервер шинэчлэгдлээ:', R.from, '→', R.to, R.npm ? '(npm install хийсэн)' : '');
    send(res, 200, Object.assign({ok: true}, R));
    setTimeout(async () => { SHUTTING = true; ST.exit = {at: Date.now(), why: `шинэчлэгдсэн: ${R.from} → ${R.to}`}; try{ csFlush(); await backupNow(false); writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); }, 1200);
    return;
  }
  if(p === '/api/env' && req.method === 'POST'){
    let b; try{ b = JSON.parse(await readBody(req)); }catch(e){ return send(res, 400, {ok: false}); }
    const ALLOW = {TD_API_KEY: /^[A-Za-z0-9]{8,80}$/, TG_TOKEN: /^\d{5,15}:[A-Za-z0-9_-]{20,80}$/, CHART_SYMBOL: /^[A-Z0-9]{2,10}\/[A-Z0-9]{2,10}$/, CHART_INTERVAL: /^(1min|5min|15min|30min|45min|1h|2h|4h|1day)$/, CREDIT_CAP: /^\d{2,5}$/, REPORT_HOUR: /^([01]?\d|2[0-3])$/, ALARM_EVERY_MIN: /^\d{1,3}$/, HISTORY_TEST_INTERVALS: /^(15min|30min|1h|2h|4h|1day)(,(15min|30min|1h|2h|4h|1day)){0,4}$/};
    const vals = {}, bad = [];
    Object.keys(ALLOW).forEach(k => { const v = b[k] == null ? '' : String(b[k]).trim(); if(!v) return; if(ALLOW[k].test(v)) vals[k] = v; else bad.push(k); });
    if(bad.length) return send(res, 400, {ok: false, error: 'Буруу утга: ' + bad.join(', ')});
    if(!Object.keys(vals).length) return send(res, 400, {ok: false, error: 'Өөрчлөх утга алга'});
    if(vals.TG_TOKEN && vals.TG_TOKEN !== CFG.tgToken){ vals.TG_CHAT = ''; ST.tgOffset = 0; stSave(); }
    envSet(vals); log('Тохиргоо өөрчлөгдлөө:', Object.keys(vals).join(', '));
    send(res, 200, {ok: true, restart: true});
    setTimeout(async () => { SHUTTING = true; ST.exit = {at: Date.now(), why: 'тохиргоо өөрчлөгдсөн'}; try{ csFlush(); await backupNow(false); writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); }, 800);
    return;
  }
  if(p === '/api/restart' && req.method === 'POST'){ station.restart('/api/restart'); return send(res, 200, {ok: true}); }
  return send(res, 404, {ok: false});
}
const LOGIN_HTML = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Station</title><body style="background:#131722;color:#EEF1F6;font-family:system-ui;padding:24px"><h3>Нууц үг хэрэгтэй</h3><form method="get" action="/status"><input name="t" type="password" placeholder="STATION_TOKEN" style="width:100%;max-width:360px;height:40px;border-radius:8px;border:1px solid #2F3440;background:#1B2130;color:#fff;padding:0 10px"><br><br><button style="height:40px;padding:0 18px;border-radius:8px;border:0;background:#E2B04A;color:#131722;font-weight:600">Нэвтрэх</button></form></body>`;
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'})[c]);
async function statusHtml(){
  const txt = await reportText(true), sets = csList();
  return `<!doctype html><html lang="mn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="120"><title>Станц</title>
<style>:root{--bg:#131722;--card:#1B2130;--line:#2F3440;--tx:#EEF1F6;--mut:#8A909C;--gold:#E2B04A}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:760px;margin:0 auto;padding:16px}
h1{font-size:19px;margin:4px 0 12px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin:0 0 12px}pre{white-space:pre-wrap;margin:0;font:14px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}
a.b,button{display:inline-block;height:38px;line-height:38px;padding:0 14px;border-radius:8px;border:0;background:var(--gold);color:#131722;font-weight:600;text-decoration:none;margin:4px 6px 4px 0;font-size:14px;cursor:pointer}
img{width:100%;border-radius:8px;border:1px solid var(--line)}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:4px 6px;border-bottom:1px solid var(--line);text-align:left}small{color:var(--mut)}</style></head>
<body><main><h1>🖥 Market Pattern · Станц</h1>
${!CFG.tgToken ? `<div class="card"><b>Telegram холбогдоогүй</b><br><small>Доорх «Тохиргоо» хэсэгт бот token-оо оруулна уу.</small></div>` : !CFG.tgChat ? `<div class="card" style="border-color:var(--gold)"><b>Telegram-аа холбох</b><br>Ботдоо дараах кодыг бичиж илгээнэ үү:<div style="font:600 30px/1.4 ui-monospace,monospace;letter-spacing:6px;color:var(--gold);margin:6px 0">${PAIR_CODE}</div><small>Код сервер дахин асах бүрт солигдоно.</small></div>` : ''}
<div class="card"><pre>${esc(txt)}</pre></div>
<div class="card"><a class="b" href="/">Апп нээх</a><a class="b" href="/api/backup" download="station-latest.json">💾 Нөөц татах</a><button onclick="fetch('/api/restart',{method:'POST'}).then(()=>alert('Дахин ачаалж байна'))">🔄 Станцыг дахин ачаалах</button></div>
<div class="card"><b>Апп шинэчлэх</b> <small>(Claude-оос авсан market-pattern-dashboard_NN.html)</small><br><br><input type="file" id="up" accept=".html,text/html" style="color:#EEF1F6;max-width:100%"><br><button onclick="(async()=>{const f=document.getElementById('up').files[0];if(!f)return alert('Файлаа сонгоно уу');const r=await fetch('/api/app',{method:'POST',headers:{'Content-Type':'text/html'},body:await f.text()});const j=await r.json().catch(()=>({}));alert(j.ok?('✓ '+(j.ver||'')+' суулаа — станц 10 секундэд дахин ачаалагдана'):('✕ '+(j.error||r.status)))})()">⬆ Суулгах</button></div>
<div class="card"><b>Сервер шинэчлэх</b> <small>(Claude-оос авсан mp-server.zip — апп ч хамт шинэчлэгдэнэ; SSH хэрэггүй)</small><br><br><input type="file" id="upz" accept=".zip,application/zip" style="color:#EEF1F6;max-width:100%"><br><button onclick="(async()=>{const f=document.getElementById('upz').files[0];if(!f)return alert('mp-server.zip-ээ сонгоно уу');this.disabled=true;this.textContent='⏳ Шалгаж, суулгаж байна…';const r=await fetch('/api/update',{method:'POST',headers:{'Content-Type':'application/zip'},body:f});const j=await r.json().catch(()=>({}));if(j.ok){alert('✓ '+j.from+' → '+j.to+(j.app?' (апп v'+j.app+')':'')+' суулаа. Сервер 1 минутын дотор шинэ хувилбараар асна.');setTimeout(()=>location.reload(),60000)}else{alert('✕ '+(j.error||r.status));this.disabled=false;this.textContent='⬆ Сервер шинэчлэх'}})()">⬆ Сервер шинэчлэх</button></div>
<div class="card"><b>Станцын дэлгэц</b> <small>(дарахад шинэчлэгдэнэ)</small><br><br><img id="sh" src="/api/shot?ts=${Date.now()}" alt="" onclick="this.src='/api/shot?ts='+Date.now()"></div>
<div class="card"><pre>${esc(histText())}</pre><br><button onclick="fetch('/api/histtest',{method:'POST'}).then(r=>alert(r.ok?'Түүхэн тест эхэллээ — дүн Telegram-аар ирнэ':'Аль хэдийн явж байна'))">🧪 Урт түүхээр тест хийх</button></div>
<div class="card"><b>Хуримтлагдсан лаа</b><table><tr><th>Хослол</th><th>Цаг</th><th>Лаа</th><th>Хугацаа</th><th></th></tr>${sets.map(x => `<tr><td>${esc(x.symbol)}</td><td>${esc(x.interval)}</td><td>${x.n}</td><td><small>${esc((x.from || '').slice(0, 10))} → ${esc((x.to || '').slice(0, 10))}</small></td><td><a href="/api/candles?symbol=${encodeURIComponent(x.symbol || '')}&interval=${encodeURIComponent(x.interval || '')}&format=csv">CSV</a></td></tr>`).join('') || '<tr><td colspan="5"><small>одоогоор алга</small></td></tr>'}</table></div>
<div class="card"><details><summary><b>⚙ Тохиргоо</b> <small>(хоосон талбар өөрчлөгдөхгүй)</small></summary><br>
<form id="envf" onsubmit="event.preventDefault();(async()=>{const o={};new FormData(this).forEach((v,k)=>{if(String(v).trim())o[k]=String(v).trim()});const r=await fetch('/api/env',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});const j=await r.json().catch(()=>({}));if(j.ok){alert('✓ Хадгаллаа — сервер 30 секундэд дахин асна');setTimeout(()=>location.reload(),30000)}else alert('✕ '+(j.error||r.status))})()">
${[['TD_API_KEY', 'Twelve Data API түлхүүр', CFG.tdKey ? '•••• ' + CFG.tdKey.slice(-4) : 'хоосон'], ['TG_TOKEN', 'Telegram бот token', CFG.tgToken ? '•••• ' + CFG.tgToken.slice(-4) : 'хоосон'], ['CHART_SYMBOL', 'Үндсэн хослол', CFG.sym], ['CHART_INTERVAL', 'Цаг (15min, 1h…)', CFG.iv], ['CREDIT_CAP', 'Өдрийн кредитийн хязгаар', CFG.creditCap], ['ALARM_EVERY_MIN', 'Сэрүүлэг шалгах (мин)', CFG.alarmEvery], ['REPORT_HOUR', 'Тайлангийн цаг (0–23)', CFG.reportHour]].map(([k, l, ph]) => `<label style="display:block;margin:0 0 8px"><small>${l}</small><br><input name="${k}" placeholder="${esc(ph)}" autocomplete="off" style="width:100%;height:38px;border-radius:8px;border:1px solid var(--line);background:#131722;color:var(--tx);padding:0 10px;box-sizing:border-box"></label>`).join('')}
<button type="submit">💾 Хадгалаад дахин асаах</button></form></details></div>
<small>${VERSION} · ${esc(os.hostname())}</small></main></body></html>`;
}

// ---------------------------------------------------------------- check mode
async function check(){
  let ok = true; const say = (good, t) => { console.log((good ? '  ✓ ' : '  ✕ ') + t); if(!good) ok = false; };
  console.log('Тохиргоог шалгаж байна…');
  say(fs.existsSync(ENV_FILE), '.env файл');
  say(!!CFG.tdKey, 'TD_API_KEY бичигдсэн');
  say(CFG.token.length >= 16, 'STATION_TOKEN (16+ тэмдэгт)');
  say(fs.existsSync(APP_FILE), 'app/index.html');
  try{ require.resolve('playwright'); say(true, 'playwright суусан'); }catch(e){ say(false, 'playwright суугаагүй — install.bat-ийг ажиллуулна уу'); }
  if(CFG.tdKey){ try{ const r = await fetch(`${CFG.tdBase}/api_usage?apikey=${encodeURIComponent(CFG.tdKey)}`); const j = await r.json(); say(j && j.status !== 'error', 'Twelve Data түлхүүр ' + (j && j.status !== 'error' ? `ажиллаж байна (өнөөдөр ${j.daily_usage}/${j.plan_daily_limit})` : '— ' + (j && j.message))); }catch(e){ say(false, 'Twelve Data-д холбогдсонгүй: ' + e.message); } }
  if(CFG.tgToken){ try{ const r = await fetch(`${CFG.tgBase}/bot${CFG.tgToken}/getMe`); const j = await r.json(); say(j && j.ok, 'Telegram бот ' + (j && j.ok ? '@' + j.result.username : '— token буруу')); }catch(e){ say(false, 'Telegram-д холбогдсонгүй: ' + e.message); } }
  else console.log('  · TG_TOKEN хоосон — Telegram ашиглахгүй');
  if(CFG.tgToken && !CFG.tgChat) console.log('  · TG_CHAT хоосон — серверийг асаагаад ботод дурын мессеж бичвэл chat ID-гаа хариу авна');
  console.log(ok ? (process.platform === 'win32' ? '\nБүгд зөв. Одоо test-run.bat-ээр туршиж үзээрэй.' : '\nБүгд зөв. Одоо: sudo mpctl restart') : '\nДээрх ✕ зүйлсийг засна уу.');
  return ok;
}

// ---------------------------------------------------------------- start / stop reasons
// why did the previous run end? written on every graceful stop; missing = it was killed
function exitMark(why){ try{ ST.exit = {at: Date.now(), why}; writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} }
function bootNotice(){
  const E = ST.exit, now = Date.now(), up = os.uptime(), verChanged = ST.ver && ST.ver !== VERSION;
  let why = E && now - E.at < 30*60e3 ? E.why : up < 600 ? 'сервер машин дахин ачаалагдсан' : verChanged ? `шинэчлэгдсэн: ${ST.ver} → ${VERSION}` : ST_FRESH ? 'анх удаа асав' : !ST.ver ? `шинэчлэгдсэн → ${VERSION}` : 'гэнэт зогссон (санах ой дүүрсэн эсвэл алдаа — /status-ийн логийг харна)';
  ST.ver = VERSION;
  if(up < 600 && E && /SIGTERM/.test(E.why)) why = 'сервер машин дахин ачаалагдсан';
  delete ST.exit;
  // several restarts in a row (e.g. Ubuntu's morning security updates restart the service once per package) → one message
  const B = ST.boot = ST.boot || {at: 0, sup: 0, why: []};
  if(now - B.at < 10*60e3 && !/шинэчлэгдсэн/.test(why)){ B.sup++;   // an update is always reported at once
     B.why.push(why); B.why = B.why.slice(-6); stSave(); }
  else{ B.at = now; B.sup = 0; B.why = []; stSave(); tgSend(`🟢 Сервер асаалаа (${os.hostname()}) — өмнөх зогсолт: ${why}. /status гэж бичвэл байдлыг хэлнэ.`); }
  setTimeout(() => { const b = ST.boot; if(b && b.sup > 0){ const n = b.sup, w = Array.from(new Set(b.why)); b.sup = 0; b.why = []; b.at = Date.now(); stSave();
    tgSend(`ℹ Сүүлийн хэдэн минутад сервер дахиад ${n} удаа дахин асав (${w.join('; ')}). Одоо 10 минут тогтвортой ажиллаж байна — өгөгдөл алдагдаагүй.`); } }, 10*60e3);
}
const SIG_WHY = {SIGTERM: 'систем зогсоосон (SIGTERM) — ихэвчлэн Ubuntu-гийн автомат аюулгүй байдлын шинэчлэл эсвэл mpctl restart', SIGINT: 'гараар зогсоосон (SIGINT)'};

// ---------------------------------------------------------------- main
async function main(){
  log(`${VERSION} эхэлж байна · ${os.hostname()} · Node ${process.version}`);
  const srv = http.createServer((req, res) => { handle(req, res).catch(e => { log('HTTP алдаа:', e.message); try{ send(res, 500, {ok: false}); }catch(x){} }); });
  await new Promise((ok, no) => { srv.once('error', no); srv.listen(CFG.port, CFG.host, ok); }).catch(e => { log(`❌ ${CFG.port} порт эзэлсэн эсвэл нээгдсэнгүй: ${e.message}. Сервер өөр цонхонд ажиллаж байгаа эсэхийг шалгана уу.`); process.exit(3); });
  log(`✓ HTTP: http://${CFG.host}:${CFG.port}/`);
  await station.start();
  bootNotice();
  tgPoll();

  // health check: the page must answer; otherwise restart the browser
  setInterval(async () => {
    if(!station.alive || station.starting) return;
    const p = await station.eval(() => window.__MP && window.__MP.ping());
    if(p && p.ok){ station.fails = 0; station.last = p; return; }
    station.miss = (station.miss || 0) + 1;
    if(station.miss >= 3){ station.miss = 0; station.schedule('хуудас хариу өгөхгүй байна'); }
  }, 60e3);
  // memory guard + daily fresh reload at 04:30 (long-running pages slowly grow)
  setInterval(async () => {
    if(!station.alive || station.starting || histTestBusy) return;
    const d = new Date();
    if(d.getHours() === 4 && d.getMinutes() >= 30 && d.getMinutes() < 35 && Date.now() - station.since > 3*36e5){ await backupNow(false); return station.restart('өдөр бүрийн шинэчлэл'); }
    try{ const cdp = await station.page.context().newCDPSession(station.page); const m = await cdp.send('Performance.getMetrics').catch(() => null); await cdp.detach().catch(() => {});
      const heap = m && (m.metrics.find(x => x.name === 'JSHeapUsedSize') || {}).value; if(heap && heap > 1.5e9){ await backupNow(false); station.restart(`санах ой ${Math.round(heap/1e6)} MB`); } }catch(e){}
  }, 5*60e3);
  // backups every 30 min (+ a dated copy once a day), candle flush every 30 s
  setInterval(() => { backupNow(!fs.existsSync(path.join(DIRS.backups, `station-${ymd()}.json`))); }, 30*60e3);
  setTimeout(() => backupNow(!fs.existsSync(path.join(DIRS.backups, `station-${ymd()}.json`))), 3*60e3);
  setInterval(csFlush, 30e3);
  // v1.11 economic calendar: soon after start, then every 4 h
  setTimeout(() => calFetch('эхлэл'), 90e3); setInterval(() => calFetch('4 цаг тутам'), 4*36e5);
  // price alarms
  setInterval(() => { alarmsRun().catch(e => log('Сэрүүлэг шалгахад алдаа:', e.message)); }, CFG.alarmEvery*60e3);
  // long history: first download a few minutes after start, then every night at 01:30;
  // the long history test runs every Sunday 03:00 (markets closed, station idle)
  if(CFG.history){
    setTimeout(() => { tdPrime().catch(() => {}).then(() => hist().run('эхний таталт')).then(() => trendCompute('эхний таталт')).then(() => swingCompute('эхний таталт')).then(() => swingTick()).catch(e => log('Түүх татахад алдаа:', e.message)); }, num(ENV.HIST_START_DELAY_S, 240)*1000);
    setInterval(() => { const d = new Date();
      if(d.getHours() === 1 && d.getMinutes() >= 30 && d.getMinutes() < 31) tdPrime().catch(() => {}).then(() => hist().run('шөнийн шинэчлэл')).then(() => trendCompute('шөнийн шинэчлэл')).then(() => swingCompute('шөнийн шинэчлэл')).catch(e => log('Түүх татахад алдаа:', e.message));
      // Sunday 10:00 — the 01:30 update has brought Friday's close; positions apply from Monday's open (05:00 Ulaanbaatar)
      if(CFG.trendOn && d.getDay() === 0 && d.getHours() >= 10 && ST.trendWeek !== ymd(d)) trendWeekly().catch(e => log('Тренд тайлангийн алдаа:', e.message));
      // v1.9 swing system: a few minutes after every hour (1H bars close every hour, 4H at 00/04/08/12/16/20 UTC)
      if(d.getMinutes() === 7 && !ST.swOff) swingTick().catch(e => log('Swing шалгалтын алдаа:', e.message));
      // v1.9.2: a station that has never computed the swing test does it once its history is ready
      if(d.getMinutes() === 20 && !swingGet() && !swingBusy && hist() && !hist().busy) swingCompute('анхны тооцоо').then(() => swingTick()).catch(e => log('Swing тестийн алдаа:', e.message));
      if(d.getDay() === 0 && d.getHours() === 3 && d.getMinutes() < 1 && Date.now() - (ST.lastHistTest || 0) > 20*36e5) histTest('долоо хоног бүрийн', histPick('')).catch(e => log('Түүхэн тестийн алдаа:', e.message));
    }, 60e3);
  }
  // daily report
  setInterval(async () => {
    const d = new Date(), key = ymd(d);
    if(d.getHours() === CFG.reportHour && ST.lastReport !== key){
      ST.lastReport = key; tgSend(await reportText(true));
      if(CFG.backupTg && await backupNow(true)) backupToTelegram('💾 Өдрийн нөөц');
      const S = await station.eval(() => window.__MP.summary()); if(S) ST.lastJr = {day: key, n: S.journal.total}; stSave();
    }
  }, 60e3);
  // a new app/index.html (update) → reload the station with it
  let wt = null; fs.watchFile(APP_FILE, {interval: 5000}, () => { clearTimeout(wt); wt = setTimeout(() => { log('app/index.html шинэчлэгдсэн'); tgSend('⬆ Апп шинэчлэгдлээ — станц шинэ хувилбараар дахин ачаалагдаж байна.'); station.restart('апп шинэчлэгдсэн'); }, 4000); });
  // log housekeeping
  setInterval(() => pruneDir(DIRS.logs, /^server-.*\.log$/, 14), 6*36e5); pruneDir(DIRS.logs, /^server-.*\.log$/, 14);

  const bye = async sig => { if(SHUTTING) return; SHUTTING = true; log('Зогсож байна (' + sig + ')'); if(!ST.exit || Date.now() - ST.exit.at > 60e3) ST.exit = {at: Date.now(), why: SIG_WHY[sig] || sig};
    try{ csFlush(); await backupNow(false); }catch(e){} try{ writeAtomic(STATE_FILE, JSON.stringify(ST)); }catch(e){} await station.stop(); process.exit(0); };
  process.on('SIGINT', () => bye('SIGINT')); process.on('SIGTERM', () => bye('SIGTERM'));
  process.on('unhandledRejection', e => logThrottled('unh', 'unhandledRejection: ' + String(e && e.message || e)));
  process.on('uncaughtException', e => { const m = String(e && e.stack || e).slice(0, 600); log('❌ Барьж аваагүй алдаа:', m); exitMark('программын алдаа: ' + String(e && e.message || e).slice(0, 120)); setTimeout(() => process.exit(1), 300); });
}
