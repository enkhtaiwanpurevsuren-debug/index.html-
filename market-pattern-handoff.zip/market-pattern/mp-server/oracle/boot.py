#!/usr/bin/env python3
# Market Pattern — first-boot installer page (runs once on a fresh Oracle server).
# Reachable only from your own Tailscale devices. Upload mp-server.zip + keys from
# the phone; it installs the server, shows STATION_TOKEN, then hands port 8787 over.
import email, html, http.server, ipaddress, json, os, re, subprocess, threading, time, zipfile

PORT = 8787
BASE = os.environ.get('MP_BOOT_DIR', '/opt/mp-boot')
DST = os.environ.get('MP_DIR', '/opt/mp-server')
LOG = os.path.join(BASE, 'install.log')
S = {'phase': 'form', 'err': '', 'token': ''}
OK_NETS = [ipaddress.ip_network('127.0.0.0/8'), ipaddress.ip_network('100.64.0.0/10'), ipaddress.ip_network('::1/128'), ipaddress.ip_network('fd7a:115c:a1e0::/48')]

CSS = ('body{margin:0;background:#131722;color:#EEF1F6;font:16px/1.5 system-ui,-apple-system,sans-serif}'
       'main{max-width:560px;margin:0 auto;padding:18px}h1{font-size:20px}label{display:block;margin:14px 0 4px;color:#AEB8C6;font-size:14px}'
       'input{width:100%;box-sizing:border-box;height:44px;border-radius:10px;border:1px solid #2F3440;background:#1B2130;color:#fff;padding:0 12px;font-size:16px}'
       'input[type=file]{height:auto;padding:10px}button{margin-top:18px;width:100%;height:48px;border:0;border-radius:10px;background:#E2B04A;color:#131722;font-weight:700;font-size:17px}'
       '.card{background:#1B2130;border:1px solid #2F3440;border-radius:12px;padding:14px;margin:12px 0}pre{white-space:pre-wrap;font:12px/1.45 ui-monospace,monospace;color:#AEB8C6;max-height:50vh;overflow:auto}'
       '.tok{font:600 20px/1.4 ui-monospace,monospace;color:#E2B04A;word-break:break-all}small{color:#8A909C}.err{color:#F87171}')

def page(body, refresh=0):
    meta = f'<meta http-equiv="refresh" content="{refresh}">' if refresh else ''
    return (f'<!doctype html><html lang="mn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">{meta}'
            f'<title>Сервер суулгах</title><style>{CSS}</style></head><body><main><h1>Market Pattern · сервер суулгах</h1>{body}</main></body></html>')

def form(msg=''):
    return page((f'<div class="card err">{html.escape(msg)}</div>' if msg else '') +
        '<div class="card">Утсан дээрх <b>mp-server.zip</b> файлаа сонгоод түлхүүрүүдээ бичнэ үү. Суулгалт 5–15 минут үргэлжилнэ.</div>'
        '<form method="post" action="/install" enctype="multipart/form-data">'
        '<label>1. mp-server.zip</label><input type="file" name="zip" accept=".zip,application/zip" required>'
        '<label>2. Twelve Data API түлхүүр</label><input name="TD_API_KEY" autocomplete="off" required>'
        '<label>3. Telegram бот token <small>(хожим ч оруулж болно)</small></label><input name="TG_TOKEN" autocomplete="off">'
        '<button>Суулгах</button></form>')

def tail(n=40):
    try:
        with open(LOG, 'r', errors='replace') as f: lines = f.read().splitlines()
        return '\n'.join(re.sub(r'\x1b\[[0-9;]*m', '', l) for l in lines[-n:])
    except Exception: return ''

def env_set(path, vals):
    txt = open(path, encoding='utf-8').read()
    for k, v in vals.items():
        v = re.sub(r'[\r\n]', '', v).strip()
        if re.search(rf'^{k}=.*$', txt, re.M): txt = re.sub(rf'^{k}=.*$', lambda m: f'{k}={v}', txt, flags=re.M)
        else: txt = txt.rstrip() + f'\n{k}={v}\n'
    with open(path, 'w', encoding='utf-8') as f: f.write(txt)

def install(zbytes, td, tg):
    try:
        os.makedirs(BASE, exist_ok=True)
        src = os.path.join(BASE, 'src')
        subprocess.run(['rm', '-rf', src], check=False)
        zp = os.path.join(BASE, 'mp-server.zip')
        with open(zp, 'wb') as f: f.write(zbytes)
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            if not any(n.endswith('install.sh') for n in names) or not any(n.endswith('server.js') for n in names):
                raise RuntimeError('Энэ zip дотор mp-server алга (install.sh, server.js хайсан).')
            z.extractall(src)
        top = next((os.path.join(src, d) for d in os.listdir(src) if os.path.isfile(os.path.join(src, d, 'install.sh'))), src)
        os.chmod(os.path.join(top, 'mpctl'), 0o755) if os.path.exists(os.path.join(top, 'mpctl')) else None
        with open(LOG, 'w') as lf:
            rc = subprocess.run(['bash', 'install.sh'], cwd=top, stdout=lf, stderr=subprocess.STDOUT, env=dict(os.environ, SKIP_START='1')).returncode
        if rc != 0: raise RuntimeError(f'install.sh алдаатай дууслаа (код {rc}). Доорх логийг Claude-д илгээнэ үү.')
        envf = os.path.join(DST, '.env')
        vals = {'TD_API_KEY': td}
        if tg: vals['TG_TOKEN'] = tg
        env_set(envf, vals)
        m = re.search(r'^STATION_TOKEN=(.+)$', open(envf, encoding='utf-8').read(), re.M)
        S['token'] = m.group(1).strip() if m else ''
        S['phase'] = 'done'
    except Exception as e:
        S['err'] = str(e); S['phase'] = 'error'

def handover():
    cmd = 'sleep 2; systemctl disable --now mp-boot; systemctl restart mp-server'
    try: subprocess.Popen(['systemd-run', '--unit=mp-handover', '--collect', 'bash', '-c', cmd])
    except Exception: subprocess.Popen(['bash', '-c', cmd], start_new_session=True)

class H(http.server.BaseHTTPRequestHandler):
    def allowed(self):
        try: ip = ipaddress.ip_address(self.client_address[0])
        except Exception: return False
        return any(ip in n for n in OK_NETS)
    def out(self, code, body, ctype='text/html; charset=utf-8'):
        b = body.encode('utf-8'); self.send_response(code); self.send_header('Content-Type', ctype)
        self.send_header('Cache-Control', 'no-store'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass
    def do_GET(self):
        if not self.allowed(): return self.out(403, 'forbidden', 'text/plain')
        ph = S['phase']
        if ph == 'form': return self.out(200, form())
        if ph == 'installing':
            return self.out(200, page('<div class="card">⏳ Суулгаж байна… Энэ хуудас 5 секунд тутам шинэчлэгдэнэ. Хаалгүй хүлээнэ үү (5–15 мин).</div>'
                                      f'<div class="card"><pre>{html.escape(tail())}</pre></div>', refresh=5))
        if ph == 'error':
            return self.out(200, form(S['err']).replace('</main>', f'<div class="card"><pre>{html.escape(tail(60))}</pre></div></main>'))
        if ph == 'done':
            return self.out(200, page('<div class="card">✅ Суулгалт амжилттай дууслаа.</div>'
                '<div class="card"><b>STATION_TOKEN</b> — апп болон /status хуудсанд нэвтрэх нууц үг. <b>Одоо хуулж, тэмдэглэлдээ хадгална уу:</b>'
                f'<div class="tok">{html.escape(S["token"])}</div></div>'
                '<form method="post" action="/finish"><button>Хадгалсан — серверийг асаах</button></form>'))
        if ph == 'finished':
            return self.out(200, page('<div class="card">🚀 Сервер асаж байна. 30–60 секундын дараа энэ хаягийн ард <b>/status</b> гэж нэмж нээгээд STATION_TOKEN-оо оруулна уу.</div>'))
        return self.out(200, form())
    def do_POST(self):
        if not self.allowed(): return self.out(403, 'forbidden', 'text/plain')
        if self.path == '/install' and S['phase'] in ('form', 'error'):
            n = int(self.headers.get('Content-Length') or 0)
            if n <= 0 or n > 20 * 1024 * 1024: return self.out(413, form('Файл хэт том эсвэл хоосон байна.'))
            body = self.rfile.read(n)
            msg = email.message_from_bytes(b'Content-Type: ' + self.headers.get('Content-Type', '').encode() + b'\r\n\r\n' + body)
            parts = {}
            for part in (msg.get_payload() if msg.is_multipart() else []):
                name = part.get_param('name', header='content-disposition')
                if name: parts[name] = part.get_payload(decode=True) or b''
            z = parts.get('zip', b''); td = parts.get('TD_API_KEY', b'').decode('utf-8', 'replace').strip(); tg = parts.get('TG_TOKEN', b'').decode('utf-8', 'replace').strip()
            if len(z) < 1000 or z[:2] != b'PK': return self.out(400, form('mp-server.zip файлаа сонгоно уу.'))
            if not re.fullmatch(r'[A-Za-z0-9]{8,80}', td): return self.out(400, form('Twelve Data түлхүүр буруу харагдаж байна.'))
            if tg and not re.fullmatch(r'\d{5,15}:[A-Za-z0-9_-]{20,80}', tg): return self.out(400, form('Telegram token буруу харагдаж байна (123456:ABC… хэлбэртэй).'))
            S['phase'] = 'installing'; S['err'] = ''
            threading.Thread(target=install, args=(z, td, tg), daemon=True).start()
            self.send_response(303); self.send_header('Location', '/'); self.end_headers(); return
        if self.path == '/finish' and S['phase'] == 'done':
            S['phase'] = 'finished'; self.out(200, page('<div class="card">🚀 Сервер асаж байна. 30–60 секундын дараа энэ хаягийн ард <b>/status</b> гэж нэмж нээнэ үү.</div>'))
            threading.Timer(1.0, handover).start(); return
        self.send_response(303); self.send_header('Location', '/'); self.end_headers()

# keep trying to publish the page over Tailscale HTTPS until it works
def serve_loop():
    for _ in range(240):
        try:
            st = subprocess.run(['tailscale', 'serve', 'status'], capture_output=True, text=True, timeout=20).stdout
            if '8787' in st: return
            subprocess.run(['timeout', '25', 'tailscale', 'serve', '--bg', str(PORT)], capture_output=True, timeout=30)
        except Exception: pass
        time.sleep(30)

if __name__ == '__main__':
    if os.environ.get('MP_BOOT_NOSERVE') != '1': threading.Thread(target=serve_loop, daemon=True).start()
    http.server.ThreadingHTTPServer(('0.0.0.0', PORT), H).serve_forever()
