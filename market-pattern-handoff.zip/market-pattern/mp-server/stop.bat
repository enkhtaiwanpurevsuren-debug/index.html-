@echo off
rem Stops the background server until the next restart of Windows (or restart.bat).
net session >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
schtasks /End /TN MarketPatternServer >nul 2>&1
taskkill /F /T /IM node.exe >nul 2>&1
echo Stopped.
pause
