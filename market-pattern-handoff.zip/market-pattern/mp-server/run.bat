@echo off
rem Started by Windows Task Scheduler (setup-windows.ps1). Restarts the server if it ever stops.
cd /d "%~dp0"
set PLAYWRIGHT_BROWSERS_PATH=%~dp0browsers
if not exist data\logs mkdir data\logs
set "NODE=node"
where node >nul 2>&1 || set "NODE=%ProgramFiles%\nodejs\node.exe"
:loop
if exist data\logs\console.log for %%F in (data\logs\console.log) do if %%~zF GTR 5000000 move /y data\logs\console.log data\logs\console.old.log >nul
"%NODE%" server.js >> data\logs\console.log 2>&1
if %ERRORLEVEL%==2 (ping -n 301 127.0.0.1 >nul) else (ping -n 16 127.0.0.1 >nul)
goto loop
