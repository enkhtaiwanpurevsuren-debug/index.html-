@echo off
cd /d "%~dp0"
echo ============================================
echo   Market Pattern server - INSTALL
echo ============================================
where node >nul 2>&1 || (echo [X] Node.js not found. Install the LTS version from https://nodejs.org and run this again. & pause & exit /b 1)
for /f "tokens=1 delims=v." %%a in ('node -v') do set NODEMAJ=%%a
if %NODEMAJ% LSS 20 (echo [X] Node.js 20 or newer is needed. Install the LTS version from https://nodejs.org & pause & exit /b 1)
echo [1/3] Installing packages...
set PLAYWRIGHT_BROWSERS_PATH=%~dp0browsers
call npm install --omit=dev --no-audit --no-fund || goto fail
echo [2/3] Downloading the browser (Chromium, ~150 MB)...
call npx playwright install chromium || goto fail
echo [3/3] Settings file...
if not exist .env node server.js --init-env
echo.
echo [OK] Done. Fill in .env (Notepad opens now), save it, then run check.bat
start "" notepad "%~dp0.env"
pause
exit /b 0
:fail
echo [X] Something failed. Check the internet connection and run install.bat again.
pause
exit /b 1
