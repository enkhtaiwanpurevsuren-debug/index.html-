@echo off
rem Restarts the background server (needed after editing .env). Asks for administrator rights.
net session >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
echo Restarting Market Pattern server...
schtasks /End /TN MarketPatternServer >nul 2>&1
taskkill /F /T /IM node.exe >nul 2>&1
ping -n 4 127.0.0.1 >nul
schtasks /Run /TN MarketPatternServer
echo Done. Status: http://127.0.0.1:8787/status
ping -n 4 127.0.0.1 >nul
