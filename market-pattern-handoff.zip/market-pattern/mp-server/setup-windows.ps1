﻿#Requires -RunAsAdministrator
# =====================================================================
#  Market Pattern сервер — Windows тохиргоо (нэг удаа ажиллуулна)
#   • Notebook унтахгүй, таг хаахад унтрахгүй, дэлгэц 3 минутын дараа унтарна
#   • Windows асахад сервер автоматаар (нэвтрэхгүйгээр) асна, унтарвал дахин асна
#  Устгах:  powershell -ExecutionPolicy Bypass -File setup-windows.ps1 -Remove
# =====================================================================
param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$dir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$name = 'MarketPatternServer'

if ($Remove) {
  Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
  Write-Host 'Автомат эхлэлтийг устгалаа.' -ForegroundColor Yellow
  exit 0
}
if (-not (Test-Path (Join-Path $dir '.env')))      { Write-Host '.env алга — эхлээд install.bat ажиллуулна уу.' -ForegroundColor Red; exit 1 }
if (-not (Test-Path (Join-Path $dir 'node_modules'))) { Write-Host 'node_modules алга — эхлээд install.bat ажиллуулна уу.' -ForegroundColor Red; exit 1 }

Write-Host '1/3  Тэжээлийн тохиргоо (цэнэглэгчид залгаатай үед)…' -ForegroundColor Cyan
powercfg /change standby-timeout-ac 0      | Out-Null   # унтахгүй
powercfg /change hibernate-timeout-ac 0    | Out-Null   # hibernate хийхгүй
powercfg /change monitor-timeout-ac 3      | Out-Null   # дэлгэц 3 минутад унтарна (сервер үргэлжилнэ)
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0 | Out-Null   # таг хаахад: юу ч хийхгүй
powercfg /setactive SCHEME_CURRENT         | Out-Null

Write-Host '2/3  Автомат эхлэлт (Task Scheduler)…' -ForegroundColor Cyan
$action    = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument ('/c "' + (Join-Path $dir 'run.bat') + '"') -WorkingDirectory $dir
$trigger   = New-ScheduledTaskTrigger -AtStartup
$trigger.Delay = 'PT1M'
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
             -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
  -Description 'Market Pattern notebook server (24/7 station)' -Force | Out-Null

Write-Host '3/3  Серверийг асааж байна…' -ForegroundColor Cyan
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-ScheduledTask -TaskName $name
Start-Sleep -Seconds 25
try {
  $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8787/status' -TimeoutSec 10
  Write-Host 'OK — сервер ажиллаж байна: http://127.0.0.1:8787/status' -ForegroundColor Green
} catch {
  if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 403) { Write-Host 'OK — сервер ажиллаж байна: http://127.0.0.1:8787/status' -ForegroundColor Green }
  else { Write-Host ('Сервер хараахан хариу өгөөгүй. 1 минутын дараа http://127.0.0.1:8787/status нээж шалгана уу. Лог: ' + (Join-Path $dir 'data\logs')) -ForegroundColor Yellow }
}
Write-Host ''
Write-Host 'Одоо Windows-оо дахин асаахад ч сервер өөрөө асна. Notebook-т нэвтрэх шаардлагагүй.'
